// ========== CONFIGURACIÓN ==========
const WORKER_URL = 'https://json.angulismotv.workers.dev'; // ⚠️ CAMBIA ESTA URL
let authToken = null;

// ========== DATOS EN MEMORIA ==========
let events = [];
let channelsData = [];
let templates = [];
let activityLog = [];
let presets = []; // Nuevo: Presets de canales por competencia
let editingEventId = null;
let editingChannelName = null;
let selectedChannels = new Set();
let bulkModeActive = false;
let selectedEvents = new Set();
let currentMonth = new Date();
let currentFilter = 'all';

// ========== ATAJOS DE TECLADO ==========
document.addEventListener('keydown', function(e) {
    // Ctrl+N - Nuevo evento rápido
    if (e.ctrlKey && e.key === 'n') {
        e.preventDefault();
        openQuickEventModal();
    }
    // Ctrl+S - Guardar (si está en formulario)
    if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        if (document.getElementById('events-tab').classList.contains('active')) {
            saveEvent();
        }
    }
    // Ctrl+D - Duplicar evento actual
    if (e.ctrlKey && e.key === 'd') {
        e.preventDefault();
        if (editingEventId) {
            duplicateCurrentEvent();
        }
    }
    // Ctrl+F - Enfocar búsqueda
    if (e.ctrlKey && e.key === 'f') {
        e.preventDefault();
        const searchInput = document.getElementById('event-search');
        if (searchInput) {
            searchInput.focus();
        }
    }
    // Escape - Cerrar modales
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal').forEach(modal => {
            if (modal.style.display === 'flex') {
                modal.style.display = 'none';
            }
        });
    }
});

// ========== SISTEMA DE LOGIN ==========
window.addEventListener('DOMContentLoaded', function() {
    const savedToken = localStorage.getItem('admin_token');
    
    if (savedToken) {
        authToken = savedToken;
        showMainPanel();
    } else {
        showLoginScreen();
    }

    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    updateThemeButton(savedTheme);
});

async function handleLogin(event) {
    event.preventDefault();
    
    const password = document.getElementById('password-input').value;
    const loginBtn = document.getElementById('login-btn');
    const errorDiv = document.getElementById('login-error');
    
    loginBtn.disabled = true;
    loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verificando...';
    errorDiv.style.display = 'none';
    
    try {
        const response = await fetch(`${WORKER_URL}/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ password: password })
        });
        
        const result = await response.json();
        
        if (result.success) {
            authToken = result.token;
            localStorage.setItem('admin_token', authToken);
            showMainPanel();
            document.getElementById('password-input').value = '';
            logActivity('Inicio de sesión exitoso', 'success');
        } else {
            showLoginError('Contraseña incorrecta');
            document.getElementById('password-input').value = '';
            document.getElementById('password-input').focus();
        }
        
    } catch (error) {
        console.error('Error de login:', error);
        showLoginError('Error de conexión. Verifica tu internet.');
    }
    
    loginBtn.disabled = false;
    loginBtn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Iniciar Sesión';
}

function showLoginError(message) {
    const errorDiv = document.getElementById('login-error');
    document.getElementById('error-message').textContent = message;
    errorDiv.style.display = 'block';
    
    setTimeout(() => {
        errorDiv.style.display = 'none';
    }, 3000);
}

function showLoginScreen() {
    document.getElementById('login-screen').style.display = 'flex';
    document.getElementById('main-container').style.display = 'none';
}

function showMainPanel() {
    document.getElementById('login-screen').style.display = 'none';
    document.getElementById('main-container').style.display = 'block';
    loadFromKV();
    loadFromStorage();
    updateAllCounts();
    showTab('dashboard');
    initializeDashboard();
    
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    
    if (document.getElementById('event-date')) {
        document.getElementById('event-date').value = `${year}-${month}-${day}T${hours}:${minutes}`;
    }
    if (document.getElementById('event-id')) {
        document.getElementById('event-id').value = getNextEventId();
    }
}

function logout() {
    if (confirm('¿Cerrar sesión?')) {
        localStorage.removeItem('admin_token');
        authToken = null;
        logActivity('Cierre de sesión', 'info');
        showLoginScreen();
    }
}

// ========== THEME TOGGLE ==========
function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    updateThemeButton(newTheme);
    logActivity(`Tema cambiado a ${newTheme === 'dark' ? 'oscuro' : 'claro'}`, 'info');
}

function updateThemeButton(theme) {
    const icon = document.getElementById('theme-icon');
    const text = document.getElementById('theme-text');
    
    if (theme === 'dark') {
        icon.className = 'fas fa-sun';
        text.textContent = 'Modo Claro';
    } else {
        icon.className = 'fas fa-moon';
        text.textContent = 'Modo Oscuro';
    }
}

// ========== FUNCIONES GENERALES ==========
function showTab(tabName) {
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    
    const activeTab = Array.from(document.querySelectorAll('.tab')).find(tab => 
        tab.getAttribute('onclick').includes(tabName)
    );
    if (activeTab) activeTab.classList.add('active');
    
    const activeContent = document.getElementById(`${tabName}-tab`);
    if (activeContent) activeContent.classList.add('active');

    if (tabName === 'calendar') {
        renderCalendar();
    } else if (tabName === 'dashboard') {
        initializeDashboard();
    } else if (tabName === 'activity') {
        renderActivityLog();
    } else if (tabName === 'templates') {
        renderTemplates();
    } else if (tabName === 'presets') {
        renderPresets();
    } else if (tabName === 'analytics') {
        renderAnalytics();
    }
}

function showAlert(elementId, message, type = 'success') {
    const alert = document.getElementById(elementId);
    alert.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'warning' ? 'exclamation-triangle' : type === 'danger' ? 'exclamation-circle' : 'info-circle'}"></i>
        ${message}
    `;
    alert.className = `alert alert-${type}`;
    alert.style.display = 'flex';
    
    setTimeout(() => {
        alert.style.display = 'none';
    }, 5000);
}

function closeModal(modalName) {
    document.getElementById(`${modalName}-modal`).style.display = 'none';
}

function importModal() {
    document.getElementById('import-json').value = '';
    document.getElementById('import-modal').style.display = 'flex';
}

// ========== GESTIÓN DE DATOS ==========
function loadFromStorage() {
    try {
        const savedEvents = localStorage.getItem('streamingEvents');
        const savedChannels = localStorage.getItem('streamingChannels');
        const savedTemplates = localStorage.getItem('streamingTemplates');
        const savedActivity = localStorage.getItem('activityLog');
        const savedPresets = localStorage.getItem('channelPresets');
        
        if (savedEvents) events = JSON.parse(savedEvents);
        if (savedChannels) channelsData = JSON.parse(savedChannels);
        if (savedTemplates) templates = JSON.parse(savedTemplates);
        if (savedActivity) activityLog = JSON.parse(savedActivity);
        if (savedPresets) presets = JSON.parse(savedPresets);
        
        renderEventsList();
        renderChannelsList();
        updateAllCounts();
    } catch (e) {
        console.error('Error cargando datos:', e);
    }
}

function saveToStorage() {
    localStorage.setItem('streamingEvents', JSON.stringify(events));
    localStorage.setItem('streamingChannels', JSON.stringify(channelsData));
    localStorage.setItem('streamingTemplates', JSON.stringify(templates));
    localStorage.setItem('activityLog', JSON.stringify(activityLog));
    localStorage.setItem('channelPresets', JSON.stringify(presets));
}

function updateAllCounts() {
    document.getElementById('events-count').textContent = `${events.length} eventos`;
    document.getElementById('total-events').textContent = events.length;
    
    document.getElementById('channels-total-count').textContent = `${channelsData.length} canales`;
    document.getElementById('total-channels').textContent = channelsData.length;
    
    const upcoming = getUpcomingEvents(7);
    document.getElementById('upcoming-count').textContent = upcoming.length;
    
    const competitions = [...new Set(events.map(e => e.competencia).filter(Boolean))];
    document.getElementById('competitions-count').textContent = competitions.length;
    
    document.getElementById('templates-count').textContent = `${templates.length} plantillas`;
    
    // Actualizar quick actions
    const today = getTodayEvents();
    const week = getWeekEvents();
    const noChannels = getEventsWithoutChannels();
    
    document.getElementById('today-count').textContent = today.length;
    document.getElementById('week-count').textContent = week.length;
    document.getElementById('no-channels-count').textContent = noChannels.length;
    
    updateCompetitionFilters();
}

function updateCompetitionFilters() {
    const competitionCounts = {};
    events.forEach(event => {
        const comp = event.competencia || 'otros';
        competitionCounts[comp] = (competitionCounts[comp] || 0) + 1;
    });
    
    document.getElementById('filter-all').textContent = events.length;
    
    ['lpf', 'f1', 'champions', 'libertadores'].forEach(comp => {
        const elem = document.getElementById(`filter-${comp}`);
        if (elem) {
            elem.textContent = competitionCounts[comp] || 0;
        }
    });
}

// ========== ACTIVITY LOG ==========
function logActivity(message, type = 'info') {
    const activity = {
        timestamp: new Date().toISOString(),
        message: message,
        type: type
    };
    
    activityLog.unshift(activity);
    
    if (activityLog.length > 100) {
        activityLog = activityLog.slice(0, 100);
    }
    
    saveToStorage();
}

function renderActivityLog() {
    const container = document.getElementById('activity-log');
    
    if (activityLog.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-history"></i>
                <h3>Sin actividad reciente</h3>
            </div>
        `;
        return;
    }
    
    container.innerHTML = activityLog.map(activity => {
        const date = new Date(activity.timestamp);
        const timeStr = date.toLocaleString('es-AR');
        
        return `
            <div class="activity-item">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span><i class="fas fa-${activity.type === 'success' ? 'check-circle' : activity.type === 'warning' ? 'exclamation-triangle' : activity.type === 'danger' ? 'times-circle' : 'info-circle'}"></i> ${activity.message}</span>
                    <span class="activity-time">${timeStr}</span>
                </div>
            </div>
        `;
    }).join('');
}

function clearActivityLog() {
    if (confirm('¿Borrar todo el historial de actividad?')) {
        activityLog = [];
        saveToStorage();
        renderActivityLog();
        showAlert('alert-event', 'Historial borrado', 'success');
    }
}

// ========== QUICK ACTIONS ==========
function getTodayEvents() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    return events.filter(event => {
        const eventDate = new Date(event.fecha);
        return eventDate >= today && eventDate < tomorrow;
    });
}

function getWeekEvents() {
    const now = new Date();
    const weekFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    
    return events.filter(event => {
        const eventDate = new Date(event.fecha);
        return eventDate >= now && eventDate <= weekFromNow;
    });
}

function getEventsWithoutChannels() {
    return events.filter(event => !event.canales || event.canales.length === 0);
}

function showTodayEvents() {
    const today = getTodayEvents();
    if (today.length === 0) {
        alert('No hay eventos programados para hoy');
        return;
    }
    
    currentFilter = 'all';
    document.getElementById('event-search').value = '';
    
    const todayStr = new Date().toISOString().split('T')[0];
    document.getElementById('event-search').value = todayStr;
    
    showTab('events');
    filterEvents();
}

function showWeekEvents() {
    currentFilter = 'all';
    document.getElementById('event-search').value = '';
    showTab('events');
    filterEvents();
}

function showEventsWithoutChannels() {
    const noChannels = getEventsWithoutChannels();
    if (noChannels.length === 0) {
        alert('¡Todos los eventos tienen canales asignados!');
        return;
    }
    
    alert(`Hay ${noChannels.length} eventos sin canales asignados`);
    showTab('events');
}

// ========== DASHBOARD ==========
function initializeDashboard() {
    updateAllCounts();
    renderUpcomingEvents();
    renderCompetitionsChart();
}

function getUpcomingEvents(days = 7) {
    const now = new Date();
    const future = new Date(now.getTime() + days * 24 * 60 * 60 * 1000);
    
    return events.filter(event => {
        const eventDate = new Date(event.fecha);
        return eventDate >= now && eventDate <= future;
    }).sort((a, b) => new Date(a.fecha) - new Date(b.fecha));
}

function renderUpcomingEvents() {
    const container = document.getElementById('upcoming-events-list');
    const upcoming = getUpcomingEvents(7);
    
    if (upcoming.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-calendar-times"></i>
                <h3>No hay eventos próximos</h3>
                <p>En los próximos 7 días</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = upcoming.map(event => {
        const date = new Date(event.fecha);
        const day = date.getDate();
        const month = date.toLocaleString('es-AR', { month: 'short' });
        const time = date.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' });
        
        return `
            <div class="upcoming-event-item" onclick="editEvent(${event.id})">
                <div class="upcoming-date">
                    <div class="upcoming-date-day">${day}</div>
                    <div class="upcoming-date-month">${month}</div>
                </div>
                <div style="flex: 1;">
                    <h4>${event.evento}</h4>
                    <p style="color: var(--gray); font-size: 0.9rem;">
                        <i class="fas fa-clock"></i> ${time} | 
                        <i class="fas fa-trophy"></i> ${event.competencia || 'Sin categoría'}
                    </p>
                </div>
                <div>
                    <span class="chip chip-primary">${event.canales.length} canales</span>
                </div>
            </div>
        `;
    }).join('');
}

function renderCompetitionsChart() {
    const container = document.getElementById('competitions-chart');
    
    const competitionCounts = {};
    events.forEach(event => {
        const comp = event.competencia || 'Otros';
        competitionCounts[comp] = (competitionCounts[comp] || 0) + 1;
    });
    
    const sorted = Object.entries(competitionCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10);
    
    if (sorted.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: var(--gray);">No hay datos para mostrar</p>';
        return;
    }
    
    const maxCount = Math.max(...sorted.map(([_, count]) => count));
    
    container.innerHTML = sorted.map(([comp, count]) => {
        const percentage = (count / maxCount) * 100;
        return `
            <div style="margin-bottom: 15px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                    <span style="font-weight: 600;">${comp}</span>
                    <span style="color: var(--gray);">${count} evento${count !== 1 ? 's' : ''}</span>
                </div>
                <div style="background: var(--border); height: 8px; border-radius: 4px; overflow: hidden;">
                    <div style="background: var(--primary); height: 100%; width: ${percentage}%; transition: width 0.3s;"></div>
                </div>
            </div>
        `;
    }).join('');
}

// ========== QUICK EVENT MODAL ==========
function openQuickEventModal() {
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = now.toTimeString().slice(0, 5);
    
    document.getElementById('quick-event-name').value = '';
    document.getElementById('quick-event-date').value = dateStr;
    document.getElementById('quick-event-time').value = timeStr;
    document.getElementById('quick-event-competition').value = '';
    document.getElementById('quick-use-preset').checked = false;
    
    document.getElementById('quick-event-modal').style.display = 'flex';
}

function toggleQuickPreset() {
    // No necesita hacer nada, solo activa/desactiva el checkbox
}

function saveQuickEvent() {
    const name = document.getElementById('quick-event-name').value.trim();
    const date = document.getElementById('quick-event-date').value;
    const time = document.getElementById('quick-event-time').value;
    const competition = document.getElementById('quick-event-competition').value;
    const usePreset = document.getElementById('quick-use-preset').checked;
    
    if (!name || !date || !time || !competition) {
        alert('❌ Completa todos los campos');
        return;
    }
    
    const formattedDate = `${date} ${time}:00`;
    
    const eventObj = {
        id: getNextEventId(),
        evento: name,
        fecha: formattedDate,
        competencia: competition,
        canales: []
    };
    
    // Si usa preset, buscar y aplicar canales del preset
    if (usePreset) {
        const preset = presets.find(p => p.competition === competition);
        if (preset && preset.channels) {
            preset.channels.forEach(channelName => {
                const channel = channelsData.find(c => c.name === channelName);
                if (channel) {
                    eventObj.canales.push({
                        name: channel.name,
                        options: channel.options
                    });
                }
            });
        }
    }
    
    events.push(eventObj);
    saveToStorage();
    renderEventsList();
    updateAllCounts();
    closeModal('quick-event');
    
    showAlert('alert-event', `✅ Evento creado rápidamente`, 'success');
    logActivity(`Evento rápido creado: ${name}`, 'success');
}

function openFullFormFromQuick() {
    const name = document.getElementById('quick-event-name').value.trim();
    const date = document.getElementById('quick-event-date').value;
    const time = document.getElementById('quick-event-time').value;
    const competition = document.getElementById('quick-event-competition').value;
    
    document.getElementById('event-name').value = name;
    document.getElementById('event-date').value = `${date}T${time}`;
    document.getElementById('event-competencia').value = competition;
    
    closeModal('quick-event');
    showTab('events');
    
    // Aplicar preset si existe
    const preset = presets.find(p => p.competition === competition);
    if (preset) {
        applyPresetToCurrentEvent(preset);
    }
}

// ========== DATE/TIME HELPERS ==========
function setEventDateTime(option) {
    const dateInput = document.getElementById('event-date');
    const now = new Date();
    
    let targetDate = new Date();
    
    switch(option) {
        case 'today':
            targetDate = now;
            break;
        case 'tomorrow':
            targetDate.setDate(now.getDate() + 1);
            break;
        case 'nextweek':
            targetDate.setDate(now.getDate() + 7);
            break;
    }
    
    const year = targetDate.getFullYear();
    const month = String(targetDate.getMonth() + 1).padStart(2, '0');
    const day = String(targetDate.getDate()).padStart(2, '0');
    const hours = String(targetDate.getHours()).padStart(2, '0');
    const minutes = String(targetDate.getMinutes()).padStart(2, '0');
    
    dateInput.value = `${year}-${month}-${day}T${hours}:${minutes}`;
}

// ========== FUNCIONES PARA EVENTOS ==========
function getNextEventId() {
    if (events.length === 0) return 1;
    return Math.max(...events.map(e => e.id)) + 1;
}

function getCompetenciaClass(competencia) {
    return `competencia-${competencia || 'default'}`;
}

function getCompetenciaLabel(competencia) {
    const labels = {
        'aviso': '🚨 AVISO',
        'lpf': '⚽ LPF',
        'f1': '🏎️ F1',
        'champions': '🏆 UCL',
        'libertadores': '🏆 CONMEBOL',
        'premier': '⚽ EPL',
        'brasileirao': '⚽ BRASILEIRÃO',
        'mls': '⚽ MLS'
    };
    return labels[competencia] || '📺';
}

// ========== PRESETS ==========
function renderPresets() {
    const container = document.getElementById('presets-list');
    
    if (presets.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-magic"></i>
                <h3>No hay presets configurados</h3>
                <p>Crea presets para aplicar canales automáticamente según la competencia</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = presets.map(preset => `
        <div class="item-card">
            <h3>${preset.competition.toUpperCase()}</h3>
            <div class="item-meta">
                <span><i class="fas fa-tv"></i> ${preset.channels.length} canal${preset.channels.length !== 1 ? 'es' : ''}</span>
            </div>
            <div style="margin: 10px 0;">
                ${preset.channels.map(ch => `<span class="chip chip-primary">${ch}</span>`).join('')}
            </div>
            <div class="item-actions">
                <button class="btn btn-danger btn-sm" onclick="deletePreset('${preset.competition}')">
                    <i class="fas fa-trash"></i> Eliminar
                </button>
            </div>
        </div>
    `).join('');
}

function openPresetModal() {
    document.getElementById('preset-competition').value = '';
    
    const container = document.getElementById('preset-channels-selector');
    container.innerHTML = '';
    
    channelsData.forEach(channel => {
        if (!channel.show) return;
        
        const channelEl = document.createElement('div');
        channelEl.className = 'channel-option';
        channelEl.innerHTML = `<strong>${channel.name}</strong>`;
        channelEl.dataset.channelName = channel.name;
        
        channelEl.onclick = function() {
            this.classList.toggle('selected');
        };
        
        container.appendChild(channelEl);
    });
    
    document.getElementById('preset-modal').style.display = 'flex';
}

function savePreset() {
    const competition = document.getElementById('preset-competition').value;
    
    if (!competition) {
        alert('❌ Selecciona una competencia');
        return;
    }
    
    const selectedOptions = document.querySelectorAll('#preset-channels-selector .channel-option.selected');
    const channels = Array.from(selectedOptions).map(opt => opt.dataset.channelName);
    
    if (channels.length === 0) {
        alert('❌ Selecciona al menos un canal');
        return;
    }
    
    // Eliminar preset anterior si existe
    presets = presets.filter(p => p.competition !== competition);
    
    // Agregar nuevo preset
    presets.push({
        competition: competition,
        channels: channels
    });
    
    saveToStorage();
    renderPresets();
    closeModal('preset');
    
    showAlert('alert-event', `✅ Preset para ${competition.toUpperCase()} guardado`, 'success');
    logActivity(`Preset creado para ${competition}`, 'success');
}

function deletePreset(competition) {
    if (confirm(`¿Eliminar preset para ${competition.toUpperCase()}?`)) {
        presets = presets.filter(p => p.competition !== competition);
        saveToStorage();
        renderPresets();
        logActivity(`Preset eliminado: ${competition}`, 'danger');
    }
}

function applyPresetChannels() {
    const competition = document.getElementById('event-competencia').value;
    
    if (!competition) {
        alert('⚠️ Primero selecciona una competencia');
        return;
    }
    
    const preset = presets.find(p => p.competition === competition);
    
    if (!preset) {
        alert(`⚠️ No hay preset configurado para ${competition.toUpperCase()}`);
        return;
    }
    
    applyPresetToCurrentEvent(preset);
}

function applyPresetToCurrentEvent(preset) {
    document.getElementById('event-channels-container').innerHTML = '';
    
    preset.channels.forEach(channelName => {
        const channel = channelsData.find(c => c.name === channelName);
        if (channel) {
            addChannelToEventUI(channel);
        }
    });
    
    updateChannelCount();
    showAlert('alert-event', `✅ Preset aplicado: ${preset.channels.length} canales`, 'success');
}

// Actualizar botón de preset cuando cambia la competencia
document.addEventListener('DOMContentLoaded', function() {
    const competenciaInput = document.getElementById('event-competencia');
    if (competenciaInput) {
        competenciaInput.addEventListener('input', function() {
            const competition = this.value;
            const presetBtn = document.getElementById('preset-channels-btn');
            
            if (presets.some(p => p.competition === competition)) {
                presetBtn.style.display = 'inline-flex';
            } else {
                presetBtn.style.display = 'none';
            }
        });
    }
});

// ========== CSV IMPORT ==========
function downloadCSVTemplate() {
    const template = `Fecha,Hora,Evento,Competencia,Canales
2024-12-25,20:00,Boca vs River,lpf,ESPN|TNT Sports
2024-12-26,18:00,Racing vs Independiente,lpf,ESPN
2024-12-27,15:00,F1: GP Abu Dhabi | Carrera,f1,ESPN|F1 TV`;
    
    const blob = new Blob([template], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'template-eventos.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    logActivity('Template CSV descargado', 'info');
}

function importCSV() {
    const csvText = document.getElementById('csv-input').value.trim();
    
    if (!csvText) {
        alert('❌ Pega el contenido CSV');
        return;
    }
    
    try {
        const lines = csvText.split('\n').filter(line => line.trim());
        
        // Skip header
        const dataLines = lines.slice(1);
        
        let imported = 0;
        let errors = [];
        
        dataLines.forEach((line, index) => {
            const parts = line.split(',').map(p => p.trim());
            
            if (parts.length < 4) {
                errors.push(`Línea ${index + 2}: Formato inválido`);
                return;
            }
            
            const [fecha, hora, evento, competencia, canales] = parts;
            
            if (!fecha || !hora || !evento || !competencia) {
                errors.push(`Línea ${index + 2}: Campos faltantes`);
                return;
            }
            
            const eventObj = {
                id: getNextEventId() + imported,
                evento: evento,
                fecha: `${fecha} ${hora}:00`,
                competencia: competencia,
                canales: []
            };
            
            // Procesar canales
            if (canales) {
                const channelNames = canales.split('|').map(c => c.trim());
                
                channelNames.forEach(channelName => {
                    const channel = channelsData.find(c => c.name === channelName);
                    if (channel) {
                        eventObj.canales.push({
                            name: channel.name,
                            options: channel.options
                        });
                    }
                });
            }
            
            events.push(eventObj);
            imported++;
        });
        
        saveToStorage();
        renderEventsList();
        updateAllCounts();
        
        let message = `✅ ${imported} eventos importados`;
        if (errors.length > 0) {
            message += `\n⚠️ ${errors.length} errores:\n` + errors.join('\n');
        }
        
        alert(message);
        logActivity(`CSV importado: ${imported} eventos`, 'success');
        
        // Limpiar
        document.getElementById('csv-input').value = '';
        
    } catch (error) {
        alert(`❌ Error procesando CSV: ${error.message}`);
    }
}

// ========== ANALYTICS ==========
function renderAnalytics() {
    // Total events
    document.getElementById('analytics-total-events').textContent = events.length;
    
    // Upcoming events
    const now = new Date();
    const upcoming = events.filter(e => new Date(e.fecha) >= now);
    document.getElementById('analytics-upcoming-events').textContent = upcoming.length;
    
    // Past events
    const past = events.filter(e => new Date(e.fecha) < now);
    document.getElementById('analytics-past-events').textContent = past.length;
    
    // Average channels per event
    const totalChannels = events.reduce((sum, e) => sum + e.canales.length, 0);
    const avgChannels = events.length > 0 ? (totalChannels / events.length).toFixed(1) : 0;
    document.getElementById('analytics-avg-channels').textContent = avgChannels;
    
    // Top competitions
    renderTopCompetitions();
    
    // Top channels
    renderTopChannels();
    
    // Common times
    renderCommonTimes();
}

function renderTopCompetitions() {
    const container = document.getElementById('top-competitions');
    
    const competitionCounts = {};
    events.forEach(event => {
        const comp = event.competencia || 'Sin categoría';
        competitionCounts[comp] = (competitionCounts[comp] || 0) + 1;
    });
    
    const sorted = Object.entries(competitionCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5);
    
    const maxCount = Math.max(...sorted.map(([_, count]) => count));
    
    container.innerHTML = sorted.map(([comp, count], index) => {
        const percentage = (count / maxCount) * 100;
        const medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣'];
        
        return `
            <div style="margin-bottom: 15px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                    <span style="font-weight: 600;">${medals[index]} ${comp}</span>
                    <span style="color: var(--gray);">${count} eventos</span>
                </div>
                <div style="background: var(--border); height: 10px; border-radius: 5px; overflow: hidden;">
                    <div style="background: var(--primary); height: 100%; width: ${percentage}%; transition: width 0.3s;"></div>
                </div>
            </div>
        `;
    }).join('');
}

function renderTopChannels() {
    const container = document.getElementById('top-channels');
    
    const channelCounts = {};
    events.forEach(event => {
        event.canales.forEach(channel => {
            channelCounts[channel.name] = (channelCounts[channel.name] || 0) + 1;
        });
    });
    
    const sorted = Object.entries(channelCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5);
    
    if (sorted.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: var(--gray);">No hay datos</p>';
        return;
    }
    
    const maxCount = Math.max(...sorted.map(([_, count]) => count));
    
    container.innerHTML = sorted.map(([channel, count], index) => {
        const percentage = (count / maxCount) * 100;
        const medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣'];
        
        return `
            <div style="margin-bottom: 15px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                    <span style="font-weight: 600;">${medals[index]} ${channel}</span>
                    <span style="color: var(--gray);">${count} veces usado</span>
                </div>
                <div style="background: var(--border); height: 10px; border-radius: 5px; overflow: hidden;">
                    <div style="background: var(--success); height: 100%; width: ${percentage}%; transition: width 0.3s;"></div>
                </div>
            </div>
        `;
    }).join('');
}

function renderCommonTimes() {
    const container = document.getElementById('common-times');
    
    const timeCounts = {};
    events.forEach(event => {
        const time = event.fecha.split(' ')[1]?.slice(0, 5); // HH:MM
        if (time) {
            timeCounts[time] = (timeCounts[time] || 0) + 1;
        }
    });
    
    const sorted = Object.entries(timeCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5);
    
    if (sorted.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: var(--gray);">No hay datos</p>';
        return;
    }
    
    const maxCount = Math.max(...sorted.map(([_, count]) => count));
    
    container.innerHTML = sorted.map(([time, count], index) => {
        const percentage = (count / maxCount) * 100;
        const medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣'];
        
        return `
            <div style="margin-bottom: 15px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                    <span style="font-weight: 600;">${medals[index]} ${time} hs</span>
                    <span style="color: var(--gray);">${count} eventos</span>
                </div>
                <div style="background: var(--border); height: 10px; border-radius: 5px; overflow: hidden;">
                    <div style="background: var(--warning); height: 100%; width: ${percentage}%; transition: width 0.3s;"></div>
                </div>
            </div>
        `;
    }).join('');
}


// ========== CHANNEL SELECTOR ==========
function showChannelSelector() {
    selectedChannels.clear();
    const container = document.getElementById('channel-selector-list');
    container.innerHTML = '';
    
    channelsData.forEach(channel => {
        if (!channel.show) return;
        
        const channelEl = document.createElement('div');
        channelEl.className = 'channel-option';
        channelEl.innerHTML = `
            <strong>${channel.name}</strong>
            <div style="font-size: 0.8rem; color: var(--gray); margin-top: 5px;">
                ${channel.options.length} opciones
            </div>
        `;
        
        channelEl.onclick = function() {
            this.classList.toggle('selected');
            const channelName = this.querySelector('strong').textContent;
            
            if (this.classList.contains('selected')) {
                selectedChannels.add(channelName);
            } else {
                selectedChannels.delete(channelName);
            }
        };
        
        container.appendChild(channelEl);
    });
    
    document.getElementById('channel-selector-modal').style.display = 'flex';
}

function addSelectedChannels() {
    selectedChannels.forEach(channelName => {
        const channel = channelsData.find(c => c.name === channelName);
        if (channel) {
            addChannelToEventUI(channel);
        }
    });
    
    closeModal('channel-selector');
    updateChannelCount();
}

function addCustomChannel() {
    const container = document.getElementById('event-channels-container');
    const index = container.children.length;
    
    const channelItem = document.createElement('div');
    channelItem.className = 'array-item';
    channelItem.innerHTML = `
        <div class="array-item-header">
            <h4 class="array-item-title">
                <i class="fas fa-satellite-dish"></i> Canal Personalizado ${index + 1}
            </h4>
            <button class="btn btn-danger btn-sm" onclick="this.parentElement.parentElement.remove(); updateChannelCount();">
                <i class="fas fa-trash"></i> Eliminar
            </button>
        </div>
        <div class="form-grid">
            <div class="form-group">
                <label>Nombre del Canal *</label>
                <input type="text" class="event-channel-name" placeholder="Nombre del canal">
            </div>
        </div>
        <div class="form-group">
            <label>Opciones de Stream (una por línea, formato: Nombre|URL)</label>
            <textarea class="event-channel-options" placeholder="Opción 1|https://...\nOpción 2|https://..."></textarea>
            <small style="color: var(--gray); margin-top: 5px;">Usa | para separar nombre de URL</small>
        </div>
    `;
    
    container.appendChild(channelItem);
    updateChannelCount();
}

function addChannelToEventUI(channel) {
    const container = document.getElementById('event-channels-container');
    
    const existingChannels = Array.from(container.querySelectorAll('.event-channel-name'))
        .map(input => input.value);
    
    if (existingChannels.includes(channel.name)) {
        showAlert('alert-event', `⚠️ El canal "${channel.name}" ya está agregado`, 'warning');
        return;
    }
    
    const channelItem = document.createElement('div');
    channelItem.className = 'array-item';
    channelItem.innerHTML = `
        <div class="array-item-header">
            <h4 class="array-item-title">
                <i class="fas fa-grip-vertical drag-handle"></i>
                <i class="fas fa-satellite-dish"></i> ${channel.name}
            </h4>
            <button class="btn btn-danger btn-sm" onclick="this.closest('.array-item').remove(); updateChannelCount();">
                <i class="fas fa-trash"></i> Eliminar Canal
            </button>
        </div>
        <div class="channel-preview" style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-top: 15px; border-left: 4px solid var(--secondary);">
            <h4 style="margin-bottom: 10px; color: var(--dark);">Opciones de stream (editables):</h4>
            <div id="options-list-${channel.name.replace(/\s/g, '-')}" style="display: flex; flex-direction: column; gap: 8px;">
                ${channel.options.map((opt, optIndex) => `
                    <div class="option-item-editable" data-option-index="${optIndex}" style="display: flex; justify-content: space-between; padding: 8px 12px; background: white; margin-bottom: 5px; border-radius: 4px; border: 1px solid #eee;">
                        <div style="flex: 1;">
                            <input type="text" class="option-name-input" value="${opt.name}" placeholder="Nombre" style="width: 100%; margin-bottom: 5px; padding: 8px; border: 1px solid var(--border); border-radius: 4px;">
                            <input type="text" class="option-url-input" value="${opt.iframe}" placeholder="URL" style="width: 100%; padding: 8px; border: 1px solid var(--border); border-radius: 4px;">
                        </div>
                        <button class="btn btn-danger btn-sm" onclick="deleteEventChannelOption(this)" style="margin-left: 10px; align-self: center;">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                `).join('')}
            </div>
            <button class="btn btn-secondary btn-sm" onclick="addNewOptionToEventChannel(this, '${channel.name.replace(/'/g, "\\'")}', '')" style="margin-top: 10px;">
                <i class="fas fa-plus"></i> Agregar opción
            </button>
        </div>
        <input type="hidden" class="event-channel-name" value="${channel.name}">
    `;
    
    container.appendChild(channelItem);
    
    if (window.Sortable) {
        new Sortable(container, {
            animation: 150,
            handle: '.drag-handle',
            ghostClass: 'sortable-ghost'
        });
    }
}

function addNewOptionToEventChannel(button, channelName, channelLogo) {
    const channelItem = button.closest('.array-item');
    const optionsList = channelItem.querySelector(`#options-list-${channelName.replace(/\s/g, '-')}`);
    
    const newIndex = optionsList.children.length;
    
    const newOption = document.createElement('div');
    newOption.className = 'option-item-editable';
    newOption.setAttribute('data-option-index', newIndex);
    newOption.style.cssText = 'display: flex; justify-content: space-between; padding: 8px 12px; background: white; margin-bottom: 5px; border-radius: 4px; border: 1px solid #eee;';
    newOption.innerHTML = `
        <div style="flex: 1;">
            <input type="text" class="option-name-input" value="Opción ${newIndex + 1}" placeholder="Nombre" style="width: 100%; margin-bottom: 5px; padding: 8px; border: 1px solid var(--border); border-radius: 4px;">
            <input type="text" class="option-url-input" value="" placeholder="URL del iframe" style="width: 100%; padding: 8px; border: 1px solid var(--border); border-radius: 4px;">
        </div>
        <button class="btn btn-danger btn-sm" onclick="deleteEventChannelOption(this)" style="margin-left: 10px; align-self: center;">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    optionsList.appendChild(newOption);
}

function deleteEventChannelOption(button) {
    const optionItem = button.closest('.option-item-editable');
    const optionsList = optionItem.parentElement;
    
    if (optionsList.children.length <= 1) {
        showAlert('alert-event', '⚠️ No puedes eliminar la última opción', 'warning');
        return;
    }
    
    optionItem.remove();
}

function updateChannelCount() {
    const count = document.getElementById('event-channels-container').children.length;
    document.getElementById('channel-count').textContent = `${count} canal${count !== 1 ? 'es' : ''}`;
}

// ========== GUARDAR EVENTO ==========
function saveEvent() {
    const eventName = document.getElementById('event-name').value.trim();
    const eventDate = document.getElementById('event-date').value;
    const eventCompetencia = document.getElementById('event-competencia').value;
    
    if (!eventName || !eventDate) {
        showAlert('alert-event', '❌ Completa nombre y fecha', 'warning');
        return;
    }
    
    if (!editingEventId) {
        const now = new Date();
        const selectedDate = new Date(eventDate);
        if (selectedDate < now) {
            if (!confirm('La fecha es del pasado. ¿Continuar?')) {
                return;
            }
        }
    }
    
    const formattedDate = eventDate.replace('T', ' ') + ':00';
    
    const eventObj = {
        id: editingEventId || getNextEventId(),
        evento: eventName,
        fecha: formattedDate,
        competencia: eventCompetencia,
        canales: []
    };
    
    const channelElements = document.querySelectorAll('#event-channels-container .array-item');
    
    channelElements.forEach(channelEl => {
        const name = channelEl.querySelector('.event-channel-name').value.trim();
        
        const optionItems = channelEl.querySelectorAll('.option-item-editable');
        const options = [];
        
        optionItems.forEach(item => {
            const optName = item.querySelector('.option-name-input').value.trim();
            const optUrl = item.querySelector('.option-url-input').value.trim();
            
            if (optName && optUrl) {
                options.push({
                    name: optName,
                    iframe: optUrl
                });
            }
        });
        
        if (options.length === 0) {
            const optionsText = channelEl.querySelector('.event-channel-options')?.value.trim();
            if (optionsText) {
                optionsText.split('\n').forEach(line => {
                    const parts = line.split('|');
                    if (parts.length >= 2 && parts[0].trim() && parts[1].trim()) {
                        options.push({
                            name: parts[0].trim(),
                            iframe: parts[1].trim()
                        });
                    }
                });
            }
        }
        
        if (name && options.length > 0) {
            eventObj.canales.push({
                name: name,
                options: options
            });
        }
    });
    
    if (editingEventId) {
        const index = events.findIndex(e => e.id === editingEventId);
        if (index !== -1) {
            events[index] = eventObj;
            showAlert('alert-event', `✅ Evento actualizado`, 'success');
            logActivity(`Evento editado: ${eventName}`, 'success');
        }
    } else {
        events.push(eventObj);
        showAlert('alert-event', `✅ Evento creado`, 'success');
        logActivity(`Evento creado: ${eventName}`, 'success');
    }
    
    saveToStorage();
    renderEventsList();
    updateAllCounts();
    resetEventForm();
}

function renderEventsList() {
    const container = document.getElementById('events-list');
    
    if (events.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-calendar-times"></i>
                <h3>No hay eventos</h3>
                <p>Crea tu primer evento usando el formulario superior</p>
            </div>
        `;
        return;
    }
    
    let filteredEvents = [...events];
    
    const searchTerm = document.getElementById('event-search')?.value.toLowerCase() || '';
    if (searchTerm) {
        filteredEvents = filteredEvents.filter(event => 
            event.evento.toLowerCase().includes(searchTerm) ||
            event.fecha.toLowerCase().includes(searchTerm) ||
            (event.competencia && event.competencia.toLowerCase().includes(searchTerm))
        );
    }
    
    if (currentFilter !== 'all') {
        filteredEvents = filteredEvents.filter(event => event.competencia === currentFilter);
    }
    
    const sortValue = document.getElementById('sort-events')?.value || 'date-asc';
    filteredEvents.sort((a, b) => {
        switch(sortValue) {
            case 'date-asc':
                return new Date(a.fecha) - new Date(b.fecha);
            case 'date-desc':
                return new Date(b.fecha) - new Date(a.fecha);
            case 'name-asc':
                return a.evento.localeCompare(b.evento);
            case 'name-desc':
                return b.evento.localeCompare(a.evento);
            default:
                return 0;
        }
    });
    
    container.innerHTML = filteredEvents.map(event => `
        <div class="item-card ${selectedEvents.has(event.id) ? 'selected' : ''}" data-event-id="${event.id}">
            ${bulkModeActive ? `
                <div class="checkbox-item">
                    <input type="checkbox" ${selectedEvents.has(event.id) ? 'checked' : ''} onchange="toggleEventSelection(${event.id})">
                </div>
            ` : ''}
            <span class="competencia-badge ${getCompetenciaClass(event.competencia)}">
                ${getCompetenciaLabel(event.competencia)}
            </span>
            <h3>${event.evento}</h3>
            <div class="item-meta">
                <span><i class="fas fa-calendar"></i> ${event.fecha}</span>
                <span><i class="fas fa-tv"></i> ${event.canales.length} canal${event.canales.length !== 1 ? 'es' : ''}</span>
            </div>
            <div class="item-actions">
                <button class="btn btn-primary btn-sm" onclick="editEvent(${event.id})">
                    <i class="fas fa-edit"></i> Editar
                </button>
                <button class="btn btn-info btn-sm" onclick="duplicateEvent(${event.id})">
                    <i class="fas fa-copy"></i> Duplicar
                </button>
                <button class="btn btn-danger btn-sm" onclick="deleteEvent(${event.id})">
                    <i class="fas fa-trash"></i> Eliminar
                </button>
            </div>
        </div>
    `).join('');
}

function editEvent(id) {
    const event = events.find(e => e.id === id);
    if (!event) return;
    
    editingEventId = id;
    document.getElementById('event-id').value = event.id;
    document.getElementById('event-name').value = event.evento;
    
    const dateObj = new Date(event.fecha);
    const year = dateObj.getFullYear();
    const month = String(dateObj.getMonth() + 1).padStart(2, '0');
    const day = String(dateObj.getDate()).padStart(2, '0');
    const hours = String(dateObj.getHours()).padStart(2, '0');
    const minutes = String(dateObj.getMinutes()).padStart(2, '0');
    
    document.getElementById('event-date').value = `${year}-${month}-${day}T${hours}:${minutes}`;
    document.getElementById('event-competencia').value = event.competencia || '';
    
    document.getElementById('event-channels-container').innerHTML = '';
    event.canales.forEach(channel => {
        addChannelToEventUI(channel);
    });
    
    updateChannelCount();
    document.getElementById('form-event-title').textContent = 'Editar Evento';
    showTab('events');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function deleteEvent(id) {
    const eventIndex = events.findIndex(e => e.id === id);
    if (eventIndex !== -1) {
        const eventName = events[eventIndex].evento;
        events.splice(eventIndex, 1);
        saveToStorage();
        renderEventsList();
        updateAllCounts();
        logActivity(`Evento eliminado: ${eventName}`, 'danger');
        
        if (editingEventId === id) {
            resetEventForm();
        }
    }
}

function duplicateEvent(id) {
    const event = events.find(e => e.id === id);
    if (!event) return;
    
    const newEvent = {
        ...event,
        id: getNextEventId(),
        evento: `${event.evento} (Copia)`,
        canales: JSON.parse(JSON.stringify(event.canales))
    };
    
    events.push(newEvent);
    saveToStorage();
    renderEventsList();
    updateAllCounts();
    showAlert('alert-event', `✅ Evento duplicado`, 'success');
    logActivity(`Evento duplicado: ${event.evento}`, 'info');
}

function duplicateCurrentEvent() {
    if (editingEventId) {
        duplicateEvent(editingEventId);
    } else {
        showAlert('alert-event', '⚠️ No hay evento seleccionado para duplicar', 'warning');
    }
}

function resetEventForm() {
    editingEventId = null;
    document.getElementById('event-id').value = getNextEventId();
    document.getElementById('event-name').value = '';
    
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    
    document.getElementById('event-date').value = `${year}-${month}-${day}T${hours}:${minutes}`;
    document.getElementById('event-competencia').value = '';
    document.getElementById('event-channels-container').innerHTML = '';
    document.getElementById('form-event-title').textContent = 'Agregar Nuevo Evento';
    updateChannelCount();
}

// ========== FILTROS Y BÚSQUEDA ==========
function filterEvents() {
    renderEventsList();
}

function filterByCompetition(competition, evt) {
    currentFilter = competition;
    
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    if (evt && evt.currentTarget) {
        evt.currentTarget.classList.add('active');
    }
    
    renderEventsList();
}

function sortEvents(sortValue) {
    renderEventsList();
}

function filterChannels() {
    const searchTerm = document.getElementById('channel-search').value.toLowerCase();
    
    const filtered = channelsData.filter(channel => 
        channel.name.toLowerCase().includes(searchTerm)
    );
    
    const container = document.getElementById('channels-list');
    
    if (filtered.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-search"></i>
                <h3>Sin resultados</h3>
                <p>No se encontraron canales con "${searchTerm}"</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = filtered.map(channel => `
        <div class="item-card">
            <h3>${channel.name}</h3>
            <div class="item-meta">
                <span><i class="fas fa-play-circle"></i> ${channel.options.length} opción${channel.options.length !== 1 ? 'es' : ''}</span>
                <span><i class="fas fa-eye${channel.show ? '' : '-slash'}"></i> ${channel.show ? 'Visible' : 'Oculto'}</span>
            </div>
            <div class="item-actions">
                <button class="btn btn-primary btn-sm" onclick="editChannel('${channel.name.replace(/'/g, "\\'")}')">
                    <i class="fas fa-edit"></i> Editar
                </button>
                <button class="btn btn-danger btn-sm" onclick="deleteChannel('${channel.name.replace(/'/g, "\\'")}')">
                    <i class="fas fa-trash"></i> Eliminar
                </button>
            </div>
        </div>
    `).join('');
}


// ========== BULK ACTIONS ==========
function toggleBulkMode() {
    bulkModeActive = !bulkModeActive;
    selectedEvents.clear();
    
    if (bulkModeActive) {
        document.getElementById('bulk-actions-bar').classList.add('show');
    } else {
        document.getElementById('bulk-actions-bar').classList.remove('show');
    }
    
    renderEventsList();
    updateBulkCount();
}

function toggleEventSelection(id) {
    if (selectedEvents.has(id)) {
        selectedEvents.delete(id);
    } else {
        selectedEvents.add(id);
    }
    updateBulkCount();
    renderEventsList();
}

function updateBulkCount() {
    document.getElementById('selected-count').textContent = `${selectedEvents.size} seleccionado${selectedEvents.size !== 1 ? 's' : ''}`;
}

function bulkDelete() {
    if (selectedEvents.size === 0) {
        showAlert('alert-event', '⚠️ No hay eventos seleccionados', 'warning');
        return;
    }
    
    if (!confirm(`¿Eliminar ${selectedEvents.size} eventos?`)) return;
    
    events = events.filter(event => !selectedEvents.has(event.id));
    
    const count = selectedEvents.size;
    selectedEvents.clear();
    
    saveToStorage();
    renderEventsList();
    updateAllCounts();
    updateBulkCount();
    
    showAlert('alert-event', `✅ ${count} eventos eliminados`, 'success');
    logActivity(`${count} eventos eliminados en lote`, 'danger');
}

function bulkChangeCompetition() {
    if (selectedEvents.size === 0) {
        showAlert('alert-event', '⚠️ No hay eventos seleccionados', 'warning');
        return;
    }
    
    document.getElementById('bulk-competition-modal').style.display = 'flex';
}

function applyBulkCompetition() {
    const newComp = document.getElementById('bulk-competition-input').value.trim();
    
    if (!newComp) {
        showAlert('alert-event', '⚠️ Ingresa una competencia', 'warning');
        return;
    }
    
    events.forEach(event => {
        if (selectedEvents.has(event.id)) {
            event.competencia = newComp;
        }
    });
    
    const count = selectedEvents.size;
    selectedEvents.clear();
    
    saveToStorage();
    renderEventsList();
    updateAllCounts();
    closeModal('bulk-competition');
    
    showAlert('alert-event', `✅ Competencia actualizada en ${count} eventos`, 'success');
    logActivity(`Competencia cambiada a "${newComp}" en ${count} eventos`, 'info');
}

function deselectAll() {
    selectedEvents.clear();
    bulkModeActive = false;
    document.getElementById('bulk-actions-bar').classList.remove('show');
    renderEventsList();
}

// ========== FUNCIONES PARA CANALES CON LOGO ==========
function previewChannelLogo() {
    const logoUrl = document.getElementById('channel-logo').value.trim();
    const previewContainer = document.getElementById('logo-preview-container');
    const previewImg = document.getElementById('channel-logo-preview');
    
    if (logoUrl) {
        previewImg.src = logoUrl;
        previewImg.onerror = function() {
            previewContainer.style.display = 'none';
            showAlert('alert-channel', '⚠️ No se pudo cargar la imagen', 'warning');
        };
        previewImg.onload = function() {
            previewContainer.style.display = 'block';
        };
    } else {
        previewContainer.style.display = 'none';
    }
}

function addOption() {
    const container = document.getElementById('channel-options-container');
    const index = container.children.length + 1;
    
    const optionItem = document.createElement('div');
    optionItem.className = 'array-item';
    optionItem.innerHTML = `
        <div class="array-item-header">
            <h4 class="array-item-title">
                <i class="fas fa-stream"></i> Opción ${index}
            </h4>
            <button class="btn btn-danger btn-sm" onclick="this.parentElement.parentElement.remove(); updateOptionsCount();">
                <i class="fas fa-trash"></i> Eliminar
            </button>
        </div>
        <div class="form-grid">
            <div class="form-group">
                <label>Nombre de la opción *</label>
                <input type="text" class="option-name" placeholder="Opción ${index}" value="Opción ${index}">
            </div>
            <div class="form-group">
                <label>URL del iframe *</label>
                <input type="text" class="option-iframe" placeholder="https://streaming.com/embed/...">
            </div>
        </div>
    `;
    
    container.appendChild(optionItem);
    updateOptionsCount();
}

function updateOptionsCount() {
    const count = document.querySelectorAll('#channel-options-container .array-item').length;
    document.getElementById('options-count').textContent = `${count} opción${count !== 1 ? 'es' : ''}`;
}

function saveChannel() {
    const channelName = document.getElementById('channel-name').value.trim();
    const channelLogo = document.getElementById('channel-logo').value.trim();
    
    if (!channelName) {
        showAlert('alert-channel', '❌ Ingresa el nombre del canal', 'warning');
        return;
    }
    
    const options = [];
    document.querySelectorAll('#channel-options-container .array-item').forEach(item => {
        const name = item.querySelector('.option-name').value.trim();
        const iframe = item.querySelector('.option-iframe').value.trim();
        
        if (name && iframe) {
            options.push({ name, iframe });
        }
    });
    
    if (options.length === 0) {
        showAlert('alert-channel', '❌ El canal debe tener al menos una opción', 'warning');
        return;
    }
    
    const channelObj = {
        name: channelName,
        logo: channelLogo || '',
        options: options,
        show: document.getElementById('channel-show').checked
    };
    
    if (editingChannelName) {
        const index = channelsData.findIndex(c => c.name === editingChannelName);
        if (index !== -1) {
            channelsData[index] = channelObj;
            showAlert('alert-channel', `✅ Canal actualizado`, 'success');
            logActivity(`Canal editado: ${channelName}`, 'success');
        }
    } else {
        if (channelsData.some(c => c.name === channelName)) {
            showAlert('alert-channel', '⚠️ Ya existe un canal con ese nombre', 'warning');
            return;
        }
        channelsData.push(channelObj);
        showAlert('alert-channel', `✅ Canal creado`, 'success');
        logActivity(`Canal creado: ${channelName}`, 'success');
    }
    
    saveToStorage();
    renderChannelsList();
    updateAllCounts();
    resetChannelForm();
}

function renderChannelsList() {
    const container = document.getElementById('channels-list');
    
    if (channelsData.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-tv-slash"></i>
                <h3>No hay canales</h3>
                <p>Crea tu primer canal usando el formulario superior</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = channelsData.map(channel => `
        <div class="item-card">
            ${channel.logo ? `<img src="${channel.logo}" class="channel-logo-preview" alt="${channel.name}" style="max-width: 80px; margin-bottom: 10px;">` : ''}
            <h3>${channel.name}</h3>
            <div class="item-meta">
                <span><i class="fas fa-play-circle"></i> ${channel.options.length} opción${channel.options.length !== 1 ? 'es' : ''}</span>
                <span><i class="fas fa-eye${channel.show ? '' : '-slash'}"></i> ${channel.show ? 'Visible' : 'Oculto'}</span>
            </div>
            <div class="item-actions">
                <button class="btn btn-primary btn-sm" onclick="editChannel('${channel.name.replace(/'/g, "\\'")}')">
                    <i class="fas fa-edit"></i> Editar
                </button>
                <button class="btn btn-danger btn-sm" onclick="deleteChannel('${channel.name.replace(/'/g, "\\'")}')">
                    <i class="fas fa-trash"></i> Eliminar
                </button>
            </div>
        </div>
    `).join('');
}

function editChannel(name) {
    const channel = channelsData.find(c => c.name === name);
    if (!channel) return;
    
    editingChannelName = name;
    document.getElementById('channel-name').value = channel.name;
    document.getElementById('channel-logo').value = channel.logo || '';
    document.getElementById('channel-show').checked = channel.show;
    
    if (channel.logo) {
        previewChannelLogo();
    }
    
    document.getElementById('channel-options-container').innerHTML = '';
    channel.options.forEach((option, index) => {
        const optionItem = document.createElement('div');
        optionItem.className = 'array-item';
        optionItem.innerHTML = `
            <div class="array-item-header">
                <h4 class="array-item-title">
                    <i class="fas fa-stream"></i> Opción ${index + 1}
                </h4>
                <button class="btn btn-danger btn-sm" onclick="this.parentElement.parentElement.remove(); updateOptionsCount();">
                    <i class="fas fa-trash"></i> Eliminar
                </button>
            </div>
            <div class="form-grid">
                <div class="form-group">
                    <label>Nombre de la opción *</label>
                    <input type="text" class="option-name" value="${option.name}">
                </div>
                <div class="form-group">
                    <label>URL del iframe *</label>
                    <input type="text" class="option-iframe" value="${option.iframe}">
                </div>
            </div>
        `;
        document.getElementById('channel-options-container').appendChild(optionItem);
    });
    
    updateOptionsCount();
    document.getElementById('form-channel-title').textContent = 'Editar Canal';
    showTab('channels');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function deleteChannel(name) {
    const channelIndex = channelsData.findIndex(c => c.name === name);
    if (channelIndex !== -1) {
        channelsData.splice(channelIndex, 1);
        saveToStorage();
        renderChannelsList();
        updateAllCounts();
        logActivity(`Canal eliminado: ${name}`, 'danger');
        
        if (editingChannelName === name) {
            resetChannelForm();
        }
    }
}

function deleteCurrentChannel() {
    if (!editingChannelName) {
        showAlert('alert-channel', '❌ No hay canal seleccionado', 'warning');
        return;
    }
    deleteChannel(editingChannelName);
}

function resetChannelForm() {
    editingChannelName = null;
    document.getElementById('channel-name').value = '';
    document.getElementById('channel-logo').value = '';
    document.getElementById('channel-show').checked = true;
    document.getElementById('channel-options-container').innerHTML = '';
    document.getElementById('form-channel-title').textContent = 'Agregar Nuevo Canal';
    document.getElementById('logo-preview-container').style.display = 'none';
    updateOptionsCount();
    addOption();
}

// ========== CALENDARIO ==========
function renderCalendar() {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    
    document.getElementById('current-month').textContent = 
        currentMonth.toLocaleString('es-AR', { month: 'long', year: 'numeric' });
    
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();
    
    const container = document.getElementById('calendar-view');
    
    let html = '<div class="calendar-grid">';
    
    ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'].forEach(day => {
        html += `<div style="text-align: center; font-weight: 600; padding: 10px;">${day}</div>`;
    });
    
    for (let i = 0; i < startingDayOfWeek; i++) {
        html += '<div></div>';
    }
    
    for (let day = 1; day <= daysInMonth; day++) {
        const date = new Date(year, month, day);
        const dateStr = date.toISOString().split('T')[0];
        
        const dayEvents = events.filter(event => {
            const eventDate = new Date(event.fecha);
            return eventDate.toISOString().split('T')[0] === dateStr;
        });
        
        html += `
            <div class="calendar-day ${dayEvents.length > 0 ? 'has-event' : ''}" 
                 onclick="showDayEvents('${dateStr}')">
                <div class="calendar-day-number">${day}</div>
                ${dayEvents.length > 0 ? `
                    <div style="margin-top: 5px;">
                        ${dayEvents.map(() => '<span class="calendar-event-dot"></span>').join('')}
                    </div>
                ` : ''}
            </div>
        `;
    }
    
    html += '</div>';
    container.innerHTML = html;
}

function changeMonth(delta) {
    currentMonth.setMonth(currentMonth.getMonth() + delta);
    renderCalendar();
}

function showDayEvents(dateStr) {
    const dayEvents = events.filter(event => {
        const eventDate = new Date(event.fecha);
        return eventDate.toISOString().split('T')[0] === dateStr;
    });
    
    if (dayEvents.length === 0) return;
    
    alert(`Eventos del ${dateStr}:\n\n${dayEvents.map(e => `• ${e.evento} - ${e.fecha.split(' ')[1]}`).join('\n')}`);
}

// ========== PLANTILLAS ==========
function saveAsTemplate() {
    const eventName = document.getElementById('event-name').value.trim();
    
    if (!eventName) {
        showAlert('alert-event', '⚠️ Completa el evento antes de guardar como plantilla', 'warning');
        return;
    }
    
    const templateName = prompt('Nombre de la plantilla:');
    if (!templateName) return;
    
    const channelElements = document.querySelectorAll('#event-channels-container .array-item');
    const canales = [];
    
    channelElements.forEach(channelEl => {
        const name = channelEl.querySelector('.event-channel-name').value.trim();
        
        const optionItems = channelEl.querySelectorAll('.option-item-editable');
        const options = [];
        
        optionItems.forEach(item => {
            const optName = item.querySelector('.option-name-input').value.trim();
            const optUrl = item.querySelector('.option-url-input').value.trim();
            
            if (optName && optUrl) {
                options.push({ name: optName, iframe: optUrl });
            }
        });
        
        if (name && options.length > 0) {
            canales.push({ name, options });
        }
    });
    
    const template = {
        id: templates.length + 1,
        name: templateName,
        competencia: document.getElementById('event-competencia').value,
        canales: canales
    };
    
    templates.push(template);
    saveToStorage();
    renderTemplates();
    updateAllCounts();
    
    showAlert('alert-event', `✅ Plantilla "${templateName}" guardada`, 'success');
    logActivity(`Plantilla creada: ${templateName}`, 'success');
}

function renderTemplates() {
    const container = document.getElementById('templates-list');
    
    if (templates.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-layer-group"></i>
                <h3>No hay plantillas</h3>
                <p>Guarda eventos como plantillas para reutilizar</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = templates.map(template => `
        <div class="item-card">
            <h3>${template.name}</h3>
            <div class="item-meta">
                <span><i class="fas fa-trophy"></i> ${template.competencia || 'Sin competencia'}</span>
                <span><i class="fas fa-tv"></i> ${template.canales.length} canal${template.canales.length !== 1 ? 'es' : ''}</span>
            </div>
            <div class="item-actions">
                <button class="btn btn-success btn-sm" onclick="useTemplate(${template.id})">
                    <i class="fas fa-magic"></i> Usar
                </button>
                <button class="btn btn-danger btn-sm" onclick="deleteTemplate(${template.id})">
                    <i class="fas fa-trash"></i> Eliminar
                </button>
            </div>
        </div>
    `).join('');
}

function useTemplate(id) {
    const template = templates.find(t => t.id === id);
    if (!template) return;
    
    document.getElementById('event-competencia').value = template.competencia || '';
    
    document.getElementById('event-channels-container').innerHTML = '';
    template.canales.forEach(channel => {
        addChannelToEventUI(channel);
    });
    
    updateChannelCount();
    showTab('events');
    showAlert('alert-event', `✅ Plantilla "${template.name}" cargada`, 'success');
}

function deleteTemplate(id) {
    if (!confirm('¿Eliminar esta plantilla?')) return;
    
    const index = templates.findIndex(t => t.id === id);
    if (index !== -1) {
        const name = templates[index].name;
        templates.splice(index, 1);
        saveToStorage();
        renderTemplates();
        updateAllCounts();
        logActivity(`Plantilla eliminada: ${name}`, 'danger');
    }
}


// ========== IMPORT/EXPORT ==========
function exportData() {
    const data = {
        events: events,
        channels: { channels: channelsData }
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `streaming-data-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    logActivity('Datos exportados a JSON', 'info');
}

function exportWorkerCode() {
    const workerCode = generateWorkerCode();
    document.getElementById('worker-code-output').textContent = workerCode;
    document.getElementById('worker-export-modal').style.display = 'flex';
}

function generateWorkerCode() {
    const eventsStr = JSON.stringify(events, null, 2);
    const channelsWrapper = { channels: channelsData };
    const channelsStr = JSON.stringify(channelsWrapper, null, 2);
    
    return `const events = ${eventsStr};

const channels = ${channelsStr};

export default {
 async fetch(request, env, ctx) {
   const url = new URL(request.url);

   if (url.pathname === "/euents") {
     return new Response(JSON.stringify(events), {
       headers: {
         "Content-Type": "application/json",
         "Access-Control-Allow-Origin": "*",
       },
     });
   }

   if (url.pathname === "/channeIs") {
     return new Response(JSON.stringify(channels), {
       headers: {
         "Content-Type": "application/json",
         "Access-Control-Allow-Origin": "*",
       },
     });
   }

   return new Response(JSON.stringify({ error: "Not found" }), {
     status: 404,
     headers: { "Content-Type": "application/json" },
   });
 },
};`;
}

function copyWorkerCode() {
    const code = generateWorkerCode();
    navigator.clipboard.writeText(code).then(() => {
        alert('✅ Código copiado al portapapeles');
    });
}

function downloadWorkerCode() {
    const code = generateWorkerCode();
    const blob = new Blob([code], { type: 'text/javascript' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cloudflare-worker-${new Date().toISOString().split('T')[0]}.js`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function importJSON() {
    let jsonText = document.getElementById('import-json').value;
    if (!jsonText) {
        alert('Por favor ingresa un JSON');
        return;
    }
    
    try {
        const data = JSON.parse(jsonText);
        
        if (data.events && Array.isArray(data.events)) {
            events = data.events;
        }
        
        if (data.channels && Array.isArray(data.channels)) {
            channelsData = data.channels;
        }
        
        saveToStorage();
        renderEventsList();
        renderChannelsList();
        updateAllCounts();
        closeModal('import');
        alert(`✅ Importados ${events.length} eventos y ${channelsData.length} canales`);
        logActivity(`Datos importados: ${events.length} eventos, ${channelsData.length} canales`, 'success');
        
    } catch (e) {
        alert(`❌ Error: ${e.message}`);
    }
}

function showEventsJSON() {
    document.getElementById('json-output').textContent = JSON.stringify(events, null, 2);
}

function showChannelsJSON() {
    document.getElementById('json-output').textContent = JSON.stringify(channelsData, null, 2);
}

function showFullJSON() {
    document.getElementById('json-output').textContent = JSON.stringify({
        events: events,
        channels: channelsData
    }, null, 2);
}

function copyJSON() {
    const json = JSON.stringify({ events: events, channels: channelsData }, null, 2);
    navigator.clipboard.writeText(json).then(() => {
        alert('✅ JSON copiado');
    });
}

// ========== SINCRONIZACIÓN CON KV ==========
async function syncToKV() {
    if (!authToken) {
        alert('Sesión expirada. Por favor inicia sesión nuevamente.');
        logout();
        return;
    }
    
    try {
        const response = await fetch(`${WORKER_URL}/sync`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({
                events: events,
                channels: { channels: channelsData }
            })
        });
        
        if (response.status === 401) {
            alert('Sesión expirada. Por favor inicia sesión nuevamente.');
            logout();
            return;
        }
        
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        
        const result = await response.json();
        alert(`✅ Sincronizado: ${result.events} eventos, ${result.channels} canales`);
        logActivity('Datos sincronizados a KV', 'success');
        
    } catch (error) {
        console.error('Error:', error);
        alert(`❌ Error: ${error.message}`);
    }
}

async function loadFromKV() {
    try {
        const [eventsRes, channelsRes] = await Promise.all([
            fetch(`${WORKER_URL}/euents`),
            fetch(`${WORKER_URL}/channeIs`)
        ]);
        
        if (eventsRes.ok) {
            const eventsData = await eventsRes.json();
            if (Array.isArray(eventsData)) {
                events = eventsData;
            }
        }
        
        if (channelsRes.ok) {
            const channelsDataRaw = await channelsRes.json();
            if (channelsDataRaw.channels) {
                channelsData = channelsDataRaw.channels;
            }
        }
        
        saveToStorage();
        renderEventsList();
        renderChannelsList();
        updateAllCounts();
        alert('✅ Datos cargados desde KV');
        logActivity('Datos cargados desde KV', 'success');
        
    } catch (error) {
        console.error('Error:', error);
    }
}