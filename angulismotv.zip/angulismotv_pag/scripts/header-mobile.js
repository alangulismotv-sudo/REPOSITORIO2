// ========================================
// HEADER MÓVIL - VERSIÓN ACTUALIZADA
// Compatible con nueva estructura
// ========================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('📱 Header móvil cargando...');
    
    const siteHeader = document.querySelector('.site-header');
    const menuToggle = document.querySelector('.menu-toggle');
    const desktopNav = document.querySelector('.site-header > .header-container > nav');
    
    if (!menuToggle || !siteHeader) {
        console.error('❌ Elementos del header no encontrados');
        return;
    }
    
    console.log('✅ Botón menú encontrado');
    
    // ========================================
    // CREAR MENÚ MÓVIL SI NO EXISTE
    // ========================================
    
    let mobileNav = document.querySelector('.mobile-nav');
    
    if (!mobileNav) {
        mobileNav = document.createElement('nav');
        mobileNav.className = 'mobile-nav';
        mobileNav.setAttribute('aria-label', 'Navegación móvil');
        
        // Copiar enlaces de navegación desktop si existe
        if (desktopNav) {
            const links = desktopNav.querySelectorAll('a');
            links.forEach(link => {
                const clonedLink = link.cloneNode(true);
                mobileNav.appendChild(clonedLink);
            });
        } else {
            // Si no hay nav desktop, crear enlaces manualmente
            mobileNav.innerHTML = `
                <a href="index.html#channelsSection">📺 Canales</a>
                <a href="#agendaFrame">📅 Agenda</a>
                <a href="multicam.html">🎥 Multicam</a>
                <a href="https://nowevents.xyz" target="_blank" rel="noopener">🎮 Entretenimiento</a>
                <a href="https://nowstats.netlify.app" target="_blank" rel="noopener">📊 Estadísticas</a>
                <a href="foro.html" class="active">💬 Foro</a>
            `;
        }
        
        document.body.appendChild(mobileNav);
        console.log('✅ Menú móvil creado');
    }
    
    // ========================================
    // CREAR OVERLAY SI NO EXISTE
    // ========================================
    
    let navOverlay = document.querySelector('.nav-overlay');
    
    if (!navOverlay) {
        navOverlay = document.createElement('div');
        navOverlay.className = 'nav-overlay';
        document.body.appendChild(navOverlay);
        console.log('✅ Overlay creado');
    }
    
    // ========================================
    // FUNCIONES DE CONTROL DEL MENÚ
    // ========================================
    
    function openMenu() {
        mobileNav.classList.add('active');
        navOverlay.classList.add('active');
        siteHeader.classList.add('mobile-nav-active');
        menuToggle.setAttribute('aria-expanded', 'true');
        document.body.style.overflow = 'hidden';
        console.log('📂 Menú abierto');
    }
    
    function closeMenu() {
        mobileNav.classList.remove('active');
        navOverlay.classList.remove('active');
        siteHeader.classList.remove('mobile-nav-active');
        menuToggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
        console.log('📁 Menú cerrado');
    }
    
    function toggleMenu() {
        const isOpen = mobileNav.classList.contains('active');
        if (isOpen) {
            closeMenu();
        } else {
            openMenu();
        }
    }
    
    // ========================================
    // EVENT LISTENERS
    // ========================================
    
    // Toggle al hacer clic en hamburguesa
    menuToggle.addEventListener('click', function(e) {
        e.stopPropagation();
        toggleMenu();
    });
    
    // Cerrar al hacer clic en overlay
    navOverlay.addEventListener('click', function() {
        closeMenu();
    });
    
    // Cerrar al hacer clic en un enlace del menú
    mobileNav.addEventListener('click', function(e) {
        if (e.target.tagName === 'A') {
            closeMenu();
        }
    });
    
    // Cerrar con tecla ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && mobileNav.classList.contains('active')) {
            closeMenu();
        }
    });
    
    // Cerrar al redimensionar a desktop
    window.addEventListener('resize', function() {
        if (window.innerWidth > 768 && mobileNav.classList.contains('active')) {
            closeMenu();
        }
    });
    
    // ========================================
    // EXPORTAR FUNCIONES GLOBALES
    // ========================================
    
    window.toggleMobileMenu = toggleMenu;
    window.closeMobileMenu = closeMenu;
    window.openMobileMenu = openMenu;
    
    console.log('✅ Header móvil inicializado');
});