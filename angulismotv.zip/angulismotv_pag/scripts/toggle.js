/* ==================================================================================
   VIEW-TOGGLE.JS - Funcionalidad del botón de cambio de vista
   Toggle entre vista Grid y Lista
   Funciona con: .movies-section > .peliculas-grid
   ================================================================================== */

(function() {
    'use strict';
    
    // Elementos del DOM
    const viewToggle = document.querySelector('.view-toggle');
    const peliculasGrid = document.querySelector('.peliculas-grid');
    
    // Verificar que existan los elementos
    if (!viewToggle || !peliculasGrid) {
        console.warn('View Toggle: Elementos no encontrados');
        return;
    }
    
    // Obtener vista guardada del localStorage o usar 'grid' por defecto
    let currentView = localStorage.getItem('ghibli-view-mode') || 'grid';
    
    // Iconos SVG para grid y list
    const gridIcon = `
        <svg class="grid-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="7" height="7"></rect>
            <rect x="14" y="3" width="7" height="7"></rect>
            <rect x="14" y="14" width="7" height="7"></rect>
            <rect x="3" y="14" width="7" height="7"></rect>
        </svg>
    `;
    
    const listIcon = `
        <svg class="list-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="8" y1="6" x2="21" y2="6"></line>
            <line x1="8" y1="12" x2="21" y2="12"></line>
            <line x1="8" y1="18" x2="21" y2="18"></line>
            <line x1="3" y1="6" x2="3.01" y2="6"></line>
            <line x1="3" y1="12" x2="3.01" y2="12"></line>
            <line x1="3" y1="18" x2="3.01" y2="18"></line>
        </svg>
    `;
    
    /**
     * Aplica la vista actual al grid de películas
     */
    function applyView(view) {
        // Aplicar clases al grid de películas
        if (view === 'list') {
            peliculasGrid.classList.add('list-view');
            peliculasGrid.classList.remove('grid-view');
            viewToggle.innerHTML = gridIcon;
            viewToggle.setAttribute('data-view', 'list');
            viewToggle.setAttribute('aria-label', 'Cambiar a vista de cuadrícula');
        } else {
            peliculasGrid.classList.add('grid-view');
            peliculasGrid.classList.remove('list-view');
            viewToggle.innerHTML = listIcon;
            viewToggle.setAttribute('data-view', 'grid');
            viewToggle.setAttribute('aria-label', 'Cambiar a vista de lista');
        }
        
        // Guardar en localStorage
        localStorage.setItem('ghibli-view-mode', view);
        currentView = view;
        
        // Dispatch evento personalizado para que otros scripts sepan del cambio
        window.dispatchEvent(new CustomEvent('viewChanged', { detail: { view } }));
        
        console.log(`Vista cambiada a: ${view}`);
    }
    
    /**
     * Toggle entre vistas
     */
    function toggleView() {
        const newView = currentView === 'grid' ? 'list' : 'grid';
        applyView(newView);
        
        // Animación del botón
        viewToggle.style.transform = 'scale(0.9)';
        setTimeout(() => {
            viewToggle.style.transform = 'scale(1)';
        }, 150);
    }
    
    // Event listener del botón
    viewToggle.addEventListener('click', toggleView);
    
    // Aplicar vista inicial
    applyView(currentView);
    
    // Transición suave para el botón
    viewToggle.style.transition = 'transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
    
    // Hacer disponible globalmente para debugging
    window.viewToggle = {
        getCurrentView: () => currentView,
        setView: (view) => {
            if (view === 'grid' || view === 'list') {
                applyView(view);
            }
        },
        toggle: toggleView
    };
    
    console.log('View Toggle inicializado. Vista actual:', currentView);
    
})();

// Exportar para uso en módulos si es necesario
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { initViewToggle };
}