/**
 * AngulismoTV - Player Controller 

 */

(function() {
  'use strict';

  // ==================== 🗜️ COMPRESIÓN LZ (Debe ser idéntica a main.js) ====================
  const LZString = {
    compress(str) {
      if (!str) return '';
      const dict = {};
      const data = (str + '').split('');
      const out = [];
      let phrase = data[0];
      let code = 256;
      
      for (let i = 1; i < data.length; i++) {
        const curr = data[i];
        if (dict[phrase + curr] != null) {
          phrase += curr;
        } else {
          out.push(phrase.length > 1 ? dict[phrase] : phrase.charCodeAt(0));
          dict[phrase + curr] = code;
          code++;
          phrase = curr;
        }
      }
      out.push(phrase.length > 1 ? dict[phrase] : phrase.charCodeAt(0));
      
      const compressed = String.fromCharCode.apply(null, out);
      return btoa(compressed)
        .replace(/=/g, '')
        .replace(/\+/g, '-')
        .replace(/\//g, '_');
    },
    
    decompress(str) {
      if (!str) return '';
      try {
        let base64 = str.replace(/-/g, '+').replace(/_/g, '/');
        const padding = base64.length % 4;
        if (padding) base64 += '='.repeat(4 - padding);
        
        const compressed = atob(base64);
        const dict = {};
        const data = compressed.split('').map(c => c.charCodeAt(0));
        let curr = String.fromCharCode(data[0]);
        let old = curr;
        const out = [curr];
        let code = 256;
        
        for (let i = 1; i < data.length; i++) {
          const currCode = data[i];
          if (currCode < 256) {
            curr = String.fromCharCode(currCode);
          } else {
            curr = dict[currCode] ? dict[currCode] : (old + old.charAt(0));
          }
          out.push(curr);
          dict[code] = old + curr.charAt(0);
          code++;
          old = curr;
        }
        
        return out.join('');
      } catch (e) {
        console.error('Error decompressing:', e);
        return null;
      }
    }
  };

  const CONFIG = {
    json: {
      channels: 'https://json.angulismotv.workers.dev/channeIs',
      events: 'https://json.angulismotv.workers.dev/euents',
      streamTP: 'https://streamtp.angulismotv.workers.dev/eventos.json',
      la14HD: 'https://la14hd.angulismotv.workers.dev/eventos/json/agenda123.json',
      logos: 'https://logos.angulismotv.workers.dev/logos'
    },
    twitch: {
      channel: 'AngulismoTV',
      parents: ['localhost', '127.0.0.1', 'angulismotv.pages.dev']
    },
    defaults: {
      logo: './assets/logo.png',
      channelName: 'Transmisión'
    },
    cache: {
      duration: 10 * 60 * 1000,
      version: 'v3'
    }
  };

  const cache = new Map();

  class CacheManager {
    static get(key) {
      const item = cache.get(key);
      if (!item) return null;
      
      if (Date.now() - item.timestamp > CONFIG.cache.duration) {
        cache.delete(key);
        return null;
      }
      
      return item.data;
    }
    
    static set(key, data) {
      cache.set(key, {
        data,
        timestamp: Date.now()
      });
    }
    
    static clear() {
      cache.clear();
    }
  }

  class LogoManager {
    constructor() {
      this.logosDB = null;
      this.loading = false;
    }

    async loadLogos() {
      if (this.logosDB) return this.logosDB;
      if (this.loading) return null;
      
      this.loading = true;
      console.log('🎨 Cargando base de datos de logos...');
      
      try {
        const response = await fetch(CONFIG.json.logos);
        const data = await response.json();
        this.logosDB = data.logos;
        console.log(`✅ ${Object.keys(this.logosDB).length} logos cargados`);
        return this.logosDB;
      } catch (error) {
        console.error('❌ Error cargando logos:', error);
        this.logosDB = {};
        return this.logosDB;
      } finally {
        this.loading = false;
      }
    }

    normalizeText(text) {
      if (!text) return '';
      return text
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/[^\w\s]/g, " ")
        .trim();
    }

    detectLogo(channelName) {
      if (!this.logosDB) {
        console.warn('⚠️ Logos no cargados aún');
        return null;
      }

      const searchText = this.normalizeText(channelName);
      console.log(`🔍 Buscando logo para: "${channelName}"`);

      for (const [key, logoData] of Object.entries(this.logosDB)) {
        const normalizedKey = this.normalizeText(key);
        
        if (searchText.includes(normalizedKey)) {
          console.log(`✅ Logo encontrado: ${logoData.name}`);
          return logoData;
        }
        
        if (logoData.keywords) {
          for (const keyword of logoData.keywords) {
            if (searchText.includes(this.normalizeText(keyword))) {
              console.log(`✅ Logo encontrado por keyword: ${logoData.name}`);
              return logoData;
            }
          }
        }
      }

      console.log(`⚠️ Sin logo para: "${channelName}"`);
      return null;
    }
  }

  const logoManager = new LogoManager();

  const PARAM_MAP = {
    short: {
      'vc': 'virtualChannel',
      'e': 'event', 
      'm': 'match',
      'c': 'channel',
      'o': 'opt'
    },
    long: {
      'virtualChannel': 'vc',
      'event': 'e',
      'match': 'm',
      'channel': 'c',
      'opt': 'o'
    }
  };

  class Utils {
    static getAllParams() {
      const urlParams = new URLSearchParams(location.search);
      const params = {};
      
      for (const [key, value] of urlParams.entries()) {
        const longKey = PARAM_MAP.short[key] || key;
        params[longKey] = value;
      }
      
      return params;
    }

    static async fetchJSON(url, options = {}) {
      const cacheKey = `fetch_${url}`;
      const cached = CacheManager.get(cacheKey);
      if (cached && !options.forceRefresh) {
        console.log(`📦 Cache hit: ${url}`);
        return cached;
      }
      
      console.log(`🌐 Fetching: ${url}`);
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 8000);
        
        const response = await fetch(url, {
          signal: controller.signal,
          cache: 'no-cache',
          mode: 'cors',
          ...options
        });
        
        clearTimeout(timeoutId);
        
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        
        const data = await response.json();
        CacheManager.set(cacheKey, data);
        
        return data;
      } catch (error) {
        console.error(`❌ Error fetching ${url}:`, error);
        
        const staleCache = CacheManager.get(cacheKey);
        if (staleCache) {
          console.log('🔄 Usando cache antiguo por error');
          return staleCache;
        }
        
        throw error;
      }
    }

    static syncURL(newParams) {
      const currentParams = Utils.getAllParams();
      const mergedParams = { ...currentParams, ...newParams };
      
      const urlParams = new URLSearchParams();
      Object.entries(mergedParams).forEach(([key, value]) => {
        if (value !== null && value !== undefined) {
          const shortKey = PARAM_MAP.long[key] || key;
          urlParams.set(shortKey, String(value));
        }
      });
      
      const newURL = `${location.pathname}?${urlParams.toString()}`;
      if (location.search !== urlParams.toString()) {
        history.replaceState(null, '', newURL);
      }
    }

    static decodeBase64(str) {
      try {
        return atob(str);
      } catch (e) {
        console.error('Error decoding base64:', e);
        return null;
      }
    }

    static redirect(params) {
      const currentParams = Utils.getAllParams();
      const mergedParams = { ...currentParams, ...params };
      
      const urlParams = new URLSearchParams();
      Object.entries(mergedParams).forEach(([key, value]) => {
        const shortKey = PARAM_MAP.long[key] || key;
        urlParams.set(shortKey, String(value));
      });
      
      window.location.href = `${location.pathname}?${urlParams.toString()}`;
    }

    static decodeBase64Compact(str) {
      try {
        let base64 = str.replace(/-/g, '+').replace(/_/g, '/');
        const padding = base64.length % 4;
        if (padding) base64 += '='.repeat(4 - padding);
        return atob(base64);
      } catch (e) {
        console.error('Error decoding compact base64:', e);
        return null;
      }
    }
  }

  class PlayerController {
    constructor() {
      this.playerFrame = document.getElementById('playerFrame');
      this.reloadBtn = document.getElementById('reloadBtn');
      this.reloadAttempts = 0;
      this.maxReloadAttempts = 2;
      this.currentSource = null;
      this.currentOptionIndex = 0;
      this.init();
    }

    init() {
      if (!this.playerFrame) {
        console.error('Player frame not found');
        return;
      }
      
      if (this.reloadBtn) {
        this.reloadBtn.addEventListener('click', () => this.reload());
      }
      
      this.playerFrame.addEventListener('error', () => this.handleError());
      this.playerFrame.addEventListener('load', () => this.handleLoad());
    }

    setSource(url, optionIndex = 0) {
      if (!url) {
        console.warn('No URL provided to player');
        this.showErrorState();
        return;
      }
      
      this.currentSource = url;
      this.currentOptionIndex = optionIndex;
      
      console.log('🎬 Setting source:', { url: url.substring(0, 100) + '...', optionIndex });
      
      const isM3U8 = url.toLowerCase().includes('.m3u8');
      let finalUrl = url;
      
      if (isM3U8) {
        console.log('🎬 M3U8 detectado, usando reproductor HLS');
        const encodedUrl = encodeURIComponent(url);
        finalUrl = `player-m3u8.html?url=${encodedUrl}&autoplay=1`;
      }
      
      this.playerFrame.classList.add('loading');
      this.playerFrame.src = finalUrl;
      this.reloadAttempts = 0;
    }

    reload() {
      if (!this.currentSource) return;
      
      console.log('🔄 Manual reload triggered');
      this.playerFrame.classList.add('loading');
      
      if (this.reloadBtn) {
        this.reloadBtn.disabled = true;
        const originalHTML = this.reloadBtn.innerHTML;
        this.reloadBtn.innerHTML = '<svg class="icon-reload spinning" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg> Recargando...';
        
        setTimeout(() => {
          this.reloadBtn.disabled = false;
          this.reloadBtn.innerHTML = originalHTML;
        }, 1000);
      }
      
      this.playerFrame.src = '';
      setTimeout(() => {
        this.playerFrame.src = this.currentSource;
      }, 300);
    }

    handleError() {
      console.error('❌ Player error');
      this.reloadAttempts++;
      
      const settings = this.getSettings();
      if (settings.autoReload && this.reloadAttempts < this.maxReloadAttempts) {
        console.log(`🔄 Auto-reload attempt ${this.reloadAttempts}/${this.maxReloadAttempts}`);
        setTimeout(() => this.reload(), 2000);
      } else {
        this.showErrorState();
      }
    }

    handleLoad() {
      console.log('✅ Stream loaded successfully');
      this.playerFrame.classList.remove('loading');
      this.reloadAttempts = 0;
    }

    showErrorState() {
      this.playerFrame.classList.remove('loading');
      console.error('❌ Max reload attempts reached or fatal error');
    }

    getSettings() {
      return window.AngulismoTV?.getSettings?.() || { autoReload: true, autoChat: true };
    }
  }

  class ChatController {
    constructor() {
      this.chatFrame = document.getElementById('twitchChat');
      this.init();
    }

    init() {
      if (!this.chatFrame) return;
      this.setTwitchChat();
    }

    setTwitchChat() {
      const parents = [...CONFIG.twitch.parents, location.hostname].filter(Boolean);
      const params = new URLSearchParams();
      parents.forEach(p => params.append('parent', p));
      params.set('darkpopout', '');
      
      this.chatFrame.src = `https://www.twitch.tv/embed/${CONFIG.twitch.channel}/chat?${params.toString()}`;
      console.log('💬 Twitch chat initialized');
    }
  }

  class EventManager {
    constructor() {
      this.eventsCache = null;
    }

    async loadEventsIfNeeded(matchId) {
      if (!matchId) return;
      
      if (this.eventsCache) {
        return this.eventsCache;
      }
      
      console.log('📅 Loading events for match:', matchId);
      
      try {
        const eventsData = await Utils.fetchJSON(CONFIG.json.events);
        this.eventsCache = eventsData;
        return eventsData;
      } catch (error) {
        console.warn('Failed to load events:', error);
        return [];
      }
    }

    findEventById(matchId, eventsData) {
      if (!eventsData || !Array.isArray(eventsData)) return null;
      
      const event = eventsData.find(ev => `manual-${ev.id}` === matchId);
      if (event) {
        console.log('✅ Event found in manual events:', event.evento);
        return event;
      }
      
      console.warn('❌ Event not found:', matchId);
      return null;
    }
  }

  class ChannelManager {
    constructor(player) {
      this.player = player;
      this.currentChannel = null;
      this.availableChannels = [];
      this.elements = {
        channelName: document.getElementById('channel-name'),
        channelLogo: document.getElementById('channel-logo'),
        channelInfo: document.getElementById('channel-info'),
        optionSelect: document.getElementById('optionSelect'),
        channelSelector: document.getElementById('channelSelector'),
        optionControls: document.getElementById('option-controls')
      };
    }

    async loadFromGeneralList(channelName) {
      const cacheKey = `channels_list`;
      let channelsData = CacheManager.get(cacheKey);
      
      if (!channelsData) {
        try {
          channelsData = await Utils.fetchJSON(CONFIG.json.channels);
          CacheManager.set(cacheKey, channelsData);
        } catch (error) {
          console.error('Error loading channels:', error);
          throw new Error('No se pudo cargar la lista de canales');
        }
      }
      
      const channel = channelsData.channels.find(
        c => (c.name || '').toLowerCase() === channelName.toLowerCase()
      );
      
      if (channel) {
        this.availableChannels = channelsData.channels;
        console.log('✅ Channel loaded:', channel.name);
      }
      
      return channel;
    }

    setChannel(channel, selectedIndex = 0) {
      this.currentChannel = channel;
      
      console.log('🎯 Setting channel:', {
        name: channel.name,
        options: channel.options.length,
        selectedIndex
      });
      
      this.updateHeader(channel);
      
      const safeIndex = Math.max(0, Math.min(selectedIndex, channel.options.length - 1));
      this.populateOptions(channel, safeIndex);
      
      const selectedOption = channel.options[safeIndex];
      if (selectedOption?.iframe) {
        this.player.setSource(selectedOption.iframe, safeIndex);
        Utils.syncURL({ opt: safeIndex });
      } else {
        console.error('❌ No valid iframe found for selected option');
        this.player.showErrorState();
      }
    }

    updateHeader(channel) {
      if (this.elements.channelName) {
        this.elements.channelName.textContent = channel.name;
      }
      
      if (this.elements.channelLogo) {
        const logoData = logoManager.detectLogo(channel.name);
        
        if (logoData && logoData.url) {
          this.elements.channelLogo.src = logoData.url;
          this.elements.channelLogo.alt = logoData.name;
          console.log(`🏆 Logo de competición aplicado: ${logoData.name}`);
        } else {
          this.elements.channelLogo.src = channel.logo || CONFIG.defaults.logo;
          this.elements.channelLogo.alt = channel.name;
        }
      }
    }

    hideHeader() {
      if (this.elements.channelInfo) {
        this.elements.channelInfo.style.display = 'none';
      }
      if (this.elements.optionControls) {
        this.elements.optionControls.style.display = 'none';
      }
    }

    populateOptions(channel, selectedIndex) {
      if (!this.elements.optionSelect) {
        console.warn('⚠️ Option select element not found');
        return;
      }
      
      console.log(`🎛️ Populating options with selectedIndex: ${selectedIndex}`);
      this.elements.optionSelect.innerHTML = '';
      
      channel.options.forEach((opt, idx) => {
        const option = document.createElement('option');
        option.value = String(idx);
        option.textContent = opt.name || `Opción ${idx + 1}`;
        this.elements.optionSelect.appendChild(option);
      });
      
      this.elements.optionSelect.selectedIndex = selectedIndex;
      console.log(`✅ Select value set to: ${this.elements.optionSelect.value}`);
      
      const newSelect = this.elements.optionSelect.cloneNode(true);
      this.elements.optionSelect.parentNode.replaceChild(newSelect, this.elements.optionSelect);
      this.elements.optionSelect = newSelect;
      
      this.elements.optionSelect.selectedIndex = selectedIndex;
      console.log(`✅ After clone, select value: ${this.elements.optionSelect.value}`);
      
      this.elements.optionSelect.addEventListener('change', (e) => {
        const newIndex = Number(e.target.value);
        console.log('🔄 Option changed to:', newIndex);
        
        if (this.currentChannel.options[newIndex]) {
          this.player.setSource(this.currentChannel.options[newIndex].iframe, newIndex);
          Utils.syncURL({ opt: newIndex });
        }
      });
    }
  }

  class DirectLinkHandler {
    static handle(eventParam, player, channelManager) {
      const decodedUrl = Utils.decodeBase64Compact(eventParam) || Utils.decodeBase64(eventParam);
      if (!decodedUrl) {
        console.error('❌ Failed to decode event parameter');
        return false;
      }
      
      console.log('🔗 Using direct link');
      channelManager.hideHeader();
      player.setSource(decodedUrl, 0);
      return true;
    }
  }

  class VirtualChannelHandler {
    static handle(virtualChannelParam, optParam, player, channelManager) {
      try {
        console.log('📺 Intentando decodificar canal virtual...');
        
        // 🔥 MÉTODO 1: Intentar descomprimir con LZ
        let decodedChannel = LZString.decompress(virtualChannelParam);
        
        if (!decodedChannel) {
          // 🔥 MÉTODO 2: Fallback a base64 compact
          console.log('⚠️ No es LZ comprimido, intentando base64 compact...');
          decodedChannel = Utils.decodeBase64Compact(virtualChannelParam);
        }
        
        if (!decodedChannel) {
          // 🔥 MÉTODO 3: Fallback a base64 normal
          console.log('⚠️ No es base64 compact, intentando base64 normal...');
          decodedChannel = Utils.decodeBase64(virtualChannelParam);
        }
        
        if (!decodedChannel) {
          console.error('❌ Failed to decode virtual channel');
          return false;
        }
        
        const channel = JSON.parse(decodedChannel);
        console.log('✅ Virtual channel loaded:', channel.name);
        
        const selectedIndex = Number.isInteger(Number(optParam)) ? Number(optParam) : 0;
        channelManager.setChannel(channel, selectedIndex);
        return true;
      } catch (error) {
        console.error('❌ Error handling virtual channel:', error);
        return false;
      }
    }
  }

  class TransmisionApp {
    constructor() {
      this.player = new PlayerController();
      this.chat = new ChatController();
      this.eventManager = new EventManager();
      this.channelManager = new ChannelManager(this.player);
    }

    async init() {
      console.log('🚀 AngulismoTV - Initializing with shareable URLs (LZ compression)...');
      
      await logoManager.loadLogos();
      
      const params = Utils.getAllParams();
      console.log('📋 URL Parameters:', params);
      
      const selectedIndex = Number.isInteger(Number(params.opt)) ? Number(params.opt) : 0;

      // Prioridad 1 - Virtual channel (comprimido o base64)
      if (params.virtualChannel) {
        const handled = VirtualChannelHandler.handle(
          params.virtualChannel,
          params.opt,
          this.player,
          this.channelManager
        );
        if (handled) return;
      }

      // Prioridad 2 - Link directo
      if (params.event) {
        const handled = DirectLinkHandler.handle(params.event, this.player, this.channelManager);
        if (handled) return;
      }

      // Prioridad 3 - Match
      if (params.match) {
        const channel = await this.handleMatchChannel(params.match, params.channel);
        if (channel) {
          this.channelManager.setChannel(channel, selectedIndex);
          return;
        }
      }

      // Prioridad 4 - Canal normal
      if (params.channel) {
        try {
          const channel = await this.channelManager.loadFromGeneralList(params.channel);
          if (channel) {
            this.channelManager.setChannel(channel, selectedIndex);
            return;
          } else {
            alert(`Canal "${params.channel}" no encontrado`);
            return;
          }
        } catch (error) {
          alert(error.message);
          return;
        }
      }

      console.warn('⚠️ No valid parameters found');
      this.showWelcomeMessage();
    }

    async handleMatchChannel(matchId, channelName) {
      console.log('🎯 Handling match channel:', matchId);
      
      const eventsData = await this.eventManager.loadEventsIfNeeded(matchId);
      const event = this.eventManager.findEventById(matchId, eventsData);
      
      if (!event || !Array.isArray(event.canales) || event.canales.length === 0) {
        console.warn('⚠️ No custom channels found for match');
        return null;
      }
      
      console.log(`✅ Found ${event.canales.length} custom channels`);
      this.channelManager.availableChannels = event.canales;
      
      let channel = null;
      if (channelName) {
        channel = event.canales.find(
          c => (c.name || '').toLowerCase() === channelName.toLowerCase()
        );
      }
      
      if (!channel && event.canales.length > 0) {
        const firstChannel = event.canales[0];
        console.log('🔄 Auto-redirect to first channel:', firstChannel.name);
        Utils.redirect({ 
          match: matchId, 
          channel: firstChannel.name,
          opt: 0
        });
        return null;
      }
      
      return channel;
    }

    showWelcomeMessage() {
      const playerFrame = document.getElementById('playerFrame');
      if (playerFrame) {
        playerFrame.srcdoc = `
          <!DOCTYPE html>
          <html>
          <head>
            <style>
              body { 
                margin: 0; 
                padding: 40px 20px; 
                font-family: Arial, sans-serif; 
                background: #1a1a1a; 
                color: white; 
                text-align: center; 
                display: flex; 
                flex-direction: column; 
                justify-content: center; 
                align-items: center; 
                min-height: 200px;
              }
              h2 { color: #ff6b6b; margin-bottom: 20px; }
              p { max-width: 500px; line-height: 1.5; }
            </style>
          </head>
          <body>
            <h2>🎥 AngulismoTV Player</h2>
            <p>Para ver una transmisión, selecciona un canal o evento desde la página principal.</p>
            <p><a href="index.html" style="color: #4dabf7;">← Volver a la página principal</a></p>
          </body>
          </html>
        `;
      }
    }
  }

  function init() {
    const app = new TransmisionApp();
    
    setTimeout(() => {
      app.init().catch(error => {
        console.error('❌ Initialization error:', error);
        const playerFrame = document.getElementById('playerFrame');
        if (playerFrame) {
          playerFrame.srcdoc = `
            <div style="padding: 40px; text-align: center; color: white; background: #1a1a1a;">
              <h3>😕 Error al cargar</h3>
              <p>Por favor, recarga la página o vuelve a la página principal.</p>
              <button onclick="location.reload()" style="padding: 10px 20px; margin: 10px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer;">
                Recargar
              </button>
              <br>
              <a href="index.html" style="color: #4dabf7;">Volver al inicio</a>
            </div>
          `;
        }
      });
    }, 100);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  window.AngulismoTV = window.AngulismoTV || {};
  window.AngulismoTV.version = '3.2.0-shareable-urls';

  console.log('📺 AngulismoTV Player v3.2.0 loaded (Shareable URLs with LZ compression)');

})();