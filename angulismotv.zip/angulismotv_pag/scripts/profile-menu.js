// ========================================
// MENÚ DE PERFIL DE USUARIO - ACTUALIZADO
// Con iconos SVG profesionales
// ========================================

// ========================================
// HTML DEL MENÚ DESPLEGABLE
// ========================================

const profileMenuHTML = `
<div id="profile-menu" class="profile-menu" style="display: none;">
  <div class="profile-menu-header">
    <div class="profile-menu-avatar" id="profile-menu-avatar">
      <!-- Avatar se carga dinámicamente -->
    </div>
    <div class="profile-menu-info">
      <div class="profile-menu-username" id="profile-menu-username">Usuario</div>
      <div class="profile-menu-email" id="profile-menu-email">email@ejemplo.com</div>
      <div class="profile-menu-rol" id="profile-menu-rol">
        <span class="badge-rol">Usuario</span>
      </div>
    </div>
  </div>
  
  <div class="profile-menu-divider"></div>
  
  <div class="profile-menu-stats">
    <div class="profile-stat">
      <span class="stat-icon">
        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
        </svg>
      </span>
      <div>
        <div class="stat-value" id="profile-mensajes">0</div>
        <div class="stat-label">Mensajes</div>
      </div>
    </div>
    <div class="profile-stat">
      <span class="stat-icon" id="profile-rango-icono">
        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>
      </span>
      <div>
        <div class="stat-value" id="profile-rango">Novato</div>
        <div class="stat-label">Rango</div>
      </div>
    </div>
  </div>
  
  <div class="profile-menu-divider"></div>
  
  <div class="profile-menu-actions">
    <button class="profile-menu-btn" onclick="abrirCambioAvatar()">
      <span>
        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
      </span>
      Cambiar foto de perfil
    </button>
    
    <button class="profile-menu-btn" onclick="abrirCambioPassword()">
      <span>
        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
        </svg>
      </span>
      Cambiar contraseña
    </button>
    
    <button class="profile-menu-btn" onclick="verMisMensajes()">
      <span>
        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
      </span>
      Ver mis mensajes
    </button>
    
    
    <div class="profile-menu-divider"></div>
    
    <button class="profile-menu-btn profile-menu-btn-danger" onclick="cerrarSesion()">
      <span>
        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
        </svg>
      </span>
      Cerrar sesión
    </button>
  </div>
</div>
`;

// ========================================
// CSS DEL MENÚ
// ========================================

const profileMenuCSS = `
<style>
.profile-menu {
  position: fixed !important;
  top: 70px !important;
  right: 20px !important;
  background: #1a1a2e !important;
  border: 1px solid #333 !important;
  border-radius: 12px !important;
  width: 320px !important;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.8) !important;
  z-index: 999999 !important;
  animation: slideDown 0.2s ease-out;
  color: #fff !important;
}

@keyframes slideDown {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.profile-menu-header {
  padding: 20px;
  display: flex;
  gap: 15px;
  align-items: center;
}

.profile-menu-avatar {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  background: #00d4ff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  font-weight: bold;
  color: white;
  overflow: hidden;
}

.profile-menu-avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.profile-menu-info {
  flex: 1;
}

.profile-menu-username {
  font-size: 18px;
  font-weight: bold;
  color: #fff;
  margin-bottom: 4px;
}

.profile-menu-email {
  font-size: 13px;
  color: #999;
  margin-bottom: 6px;
}

.profile-menu-rol {
  display: inline-block;
}

.badge-rol {
  display: inline-block;
  padding: 4px 12px;
  background: #00d4ff;
  color: white;
  border-radius: 12px;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
}

.badge-rol.admin {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.badge-rol.moderador {
  background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
}

.profile-menu-divider {
  height: 1px;
  background: #333;
  margin: 0 20px;
}

.profile-menu-stats {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 15px;
  padding: 20px;
}

.profile-stat {
  display: flex;
  align-items: center;
  gap: 10px;
}

.stat-icon {
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.stat-icon svg {
  width: 24px;
  height: 24px;
  color: #00d4ff;
  stroke-width: 2;
}

.stat-value {
  font-size: 20px;
  font-weight: bold;
  color: #fff;
}

.stat-label {
  font-size: 12px;
  color: #999;
}

.profile-menu-actions {
  padding: 10px;
}

.profile-menu-btn {
  width: 100%;
  padding: 12px 16px;
  background: transparent;
  border: none;
  color: #fff;
  text-align: left;
  cursor: pointer;
  border-radius: 8px;
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 14px;
  transition: background 0.2s;
  margin-bottom: 4px;
}

.profile-menu-btn:hover {
  background: rgba(255, 255, 255, 0.1);
}

.profile-menu-btn span {
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.profile-menu-btn span svg {
  width: 18px;
  height: 18px;
  stroke-width: 2;
  color: rgba(255, 255, 255, 0.7);
}

.profile-menu-btn:hover span svg {
  color: #fff;
}

.profile-menu-btn-danger {
  color: #ff6b6b;
}

.profile-menu-btn-danger:hover {
  background: rgba(255, 107, 107, 0.1);
}

.profile-menu-btn-danger span svg {
  color: #ff6b6b;
}
</style>
`;

// ========================================
// JAVASCRIPT - FUNCIONALIDADES
// ========================================

// Agregar menú al DOM
function inicializarMenuPerfil() {
  // Agregar CSS
  if (!document.getElementById('profile-menu-styles')) {
    const style = document.createElement('div');
    style.id = 'profile-menu-styles';
    style.innerHTML = profileMenuCSS;
    document.head.appendChild(style);
  }
  
  // Agregar HTML del menú
  if (!document.getElementById('profile-menu')) {
    const menuContainer = document.createElement('div');
    menuContainer.innerHTML = profileMenuHTML;
    document.body.appendChild(menuContainer.firstElementChild);
  }
  
// Cerrar menú al hacer clic fuera
document.addEventListener('click', (e) => {
    const menu = document.getElementById('profile-menu');
    const userMosaic = document.querySelector('.user-logged');
    
    if (menu && !menu.contains(e.target) && !userMosaic?.contains(e.target)) {
        menu.style.display = 'none';
    }
});
}

// Toggle del menú
function toggleProfileMenu() {
    const menu = document.getElementById('profile-menu');
    
    if (!menu) {
        console.error('❌ El menú de perfil no existe en el DOM');
        return;
    }
    
    const estaVisible = menu.style.display === 'block';
    
    if (estaVisible) {
        menu.style.display = 'none';
    } else {
        menu.style.display = 'block';
        
        // ✅ CARGAR DATOS INMEDIATAMENTE (SIN AWAIT)
        cargarDatosMenuPerfil();
    }
}

// Cargar datos del usuario
async function cargarDatosMenuPerfil() {
  try {
    // ✅ PRIMERO: Cargar desde AuthState (instantáneo)
    if (typeof AuthState !== 'undefined' && AuthState.user) {
        const user = AuthState.user;
        
        // Avatar
        const avatarEl = document.getElementById('profile-menu-avatar');
        if (user.avatar_url) {
            avatarEl.innerHTML = `<img src="${user.avatar_url}" alt="Avatar">`;
        } else {
            avatarEl.textContent = user.username.substring(0, 2).toUpperCase();
        }
        
        // Información básica
        document.getElementById('profile-menu-username').textContent = user.username;
        document.getElementById('profile-menu-email').textContent = user.email;
        
        // Rol
        const rolEl = document.getElementById('profile-menu-rol');
        const rolClass = user.rol === 'admin' ? 'admin' : user.rol === 'moderador' ? 'moderador' : '';
        rolEl.innerHTML = `<span class="badge-rol ${rolClass}">${user.rol}</span>`;
    }
    
    // ✅ SEGUNDO: Verificar token y actualizar si es necesario
    const token = localStorage.getItem('authToken') || sessionStorage.getItem('authToken');
    
    if (!token) return;
    
    // Hacer el fetch en segundo plano
    const response = await fetch(`${CONFIG.API_URL}/auth/me`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    
    const data = await response.json();
    
    if (data.success && data.user) {
      const user = data.user;
      
      // Actualizar solo si cambió
      const avatarEl = document.getElementById('profile-menu-avatar');
      if (user.avatar_url) {
        avatarEl.innerHTML = `<img src="${user.avatar_url}" alt="Avatar">`;
      }
      
      // Cargar estadísticas
      await cargarEstadisticasUsuario(user.id);
    }
  } catch (error) {
    console.error('Error cargando datos del menú:', error);
  }
}

// Cargar estadísticas
async function cargarEstadisticasUsuario(userId) {
  try {
    const response = await fetch(`${CONFIG.API_URL}/mensajes?limit=100`);
    const data = await response.json();
    
    // Generar UUID esperado
    const userIdPadded = userId.toString().padStart(8, '0');
    const usuarioIdEsperado = `00000000-0000-0000-0000-${userIdPadded.padStart(12, '0')}`;
    
    // Contar mensajes
    const misMensajes = data.mensajes.filter(m => m.usuario_id === usuarioIdEsperado);
    const totalMensajes = misMensajes.length;
    
    document.getElementById('profile-mensajes').textContent = totalMensajes;
    
    // Calcular rango con iconos SVG
    const RANGOS = [
      { 
        nombre: 'Novato', 
        icono: `<svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
        </svg>`, 
        min: 1, 
        max: 10 
      },
      { 
        nombre: 'Activo', 
        icono: `<svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>`, 
        min: 11, 
        max: 50 
      },
      { 
        nombre: 'Veterano', 
        icono: `<svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
        </svg>`, 
        min: 51, 
        max: 100 
      },
      { 
        nombre: 'Leyenda', 
        icono: `<svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
        </svg>`, 
        min: 101, 
        max: 999999 
      }
    ];
    
    const rango = RANGOS.find(r => totalMensajes >= r.min && totalMensajes <= r.max) || RANGOS[0];
    
    document.getElementById('profile-rango').textContent = rango.nombre;
    document.getElementById('profile-rango-icono').innerHTML = rango.icono;
    
  } catch (error) {
    console.error('Error cargando estadísticas:', error);
  }
}

// ========================================
// FUNCIONES DE LAS ACCIONES
// ========================================

function abrirCambioAvatar() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  
  input.onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    if (file.size > 2 * 1024 * 1024) {
        alert('La imagen es muy grande. Máximo 2MB.');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64 = event.target.result;
      
      try {
        const token = localStorage.getItem('authToken') || sessionStorage.getItem('authToken');
        const response = await fetch(`${CONFIG.API_URL}/auth/update-avatar`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({ avatarUrl: base64 })
        });
        
        const data = await response.json();
        
        if (data.success) {
          // ✅ 1. Actualizar AuthState
          if (typeof AuthState !== 'undefined' && AuthState.user) {
              AuthState.user.avatar_url = base64;
              const storage = AuthState.rememberMe ? localStorage : sessionStorage;
              storage.setItem('user', JSON.stringify(AuthState.user));
          }
          
          // ✅ 2. Actualizar avatar en el header
          const userAvatar = document.querySelector('.user-avatar');
          if (userAvatar) {
              userAvatar.src = base64;
          }
          
          // ✅ 3. Actualizar en el menú de perfil
          await cargarDatosMenuPerfil();
          
          // ✅ 4. Sincronizar con sistema de mensajes
          if (typeof sincronizarAvatarUsuario === 'function') {
              await sincronizarAvatarUsuario();
          }
          
          // ✅ 5. Actualizar State.avatarSeleccionado
          if (typeof State !== 'undefined') {
              State.avatarSeleccionado = {
                  tipo: 'foto',
                  valor: base64
              };
              localStorage.setItem('foroAvatar', JSON.stringify(State.avatarSeleccionado));
              
              if (typeof actualizarPreviewAvatar === 'function') {
                  actualizarPreviewAvatar();
              }
          }
          
          mostrarAlerta('Foto de perfil actualizada', 'success');
          
        } else {
          mostrarAlerta(data.error || 'Error al actualizar', 'error');
        }
      } catch (error) {
        console.error('Error:', error);
        mostrarAlerta('Error al actualizar foto', 'error');
      }
    };
    
    reader.readAsDataURL(file);
  };
  
  input.click();
}

function abrirCambioPassword() {
  const currentPass = prompt('Contraseña actual:');
  if (!currentPass) return;
  
  const newPass = prompt('Nueva contraseña (mínimo 8 caracteres):');
  if (!newPass || newPass.length < 8) {
    alert('La contraseña debe tener al menos 8 caracteres');
    return;
  }
  
  const token = localStorage.getItem('authToken');
  
  fetch(`${CONFIG.API_URL}/auth/change-password`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({ currentPassword: currentPass, newPassword: newPass })
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      mostrarAlerta('Contraseña actualizada', 'success');
    } else {
      mostrarAlerta(data.error, 'error');
    }
  });
}

function verMisMensajes() {
  const username = localStorage.getItem('username');
  
  // Scroll a todos mis mensajes y destacarlos
  document.querySelectorAll('.mensaje-item').forEach(msg => {
    const nombreEl = msg.querySelector('.mensaje-nombre');
    if (nombreEl && nombreEl.textContent === username) {
      msg.style.background = 'rgba(0, 212, 255, 0.1)';
      msg.style.border = '2px solid var(--primary-color)';
    } else {
      msg.style.background = '';
      msg.style.border = '';
    }
  });
  
  document.getElementById('profile-menu').style.display = 'none';
  mostrarAlerta('Tus mensajes están destacados', 'info');
}

function verEstadisticas() {
  alert('Estadísticas detalladas - En desarrollo');
  // Aquí puedes crear un modal más elaborado con gráficos
}

function cerrarSesion() {
  if (confirm('¿Estás seguro de cerrar sesión?')) {
    localStorage.clear();
    location.reload();
  }
}

// ========================================
// EXPORTAR FUNCIONES
// ========================================

window.inicializarMenuPerfil = inicializarMenuPerfil;
window.toggleProfileMenu = toggleProfileMenu;
window.abrirCambioAvatar = abrirCambioAvatar;
window.abrirCambioPassword = abrirCambioPassword;
window.verMisMensajes = verMisMensajes;
window.verEstadisticas = verEstadisticas;
window.cerrarSesion = cerrarSesion;

// ========================================
// INICIALIZAR AL CARGAR
// ========================================

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', inicializarMenuPerfil);
} else {
  inicializarMenuPerfil();
}

console.log('✅ Menú de perfil de usuario cargado (iconos SVG profesionales)');