/* ==================== WATCH.JS MEJORADO - REPRODUCTOR DE PELÍCULAS ==================== */

// ==================== CONFIGURACIÓN ====================
const API_URL = 'https://ghibli.alangulismotv.workers.dev';

// ==================== VARIABLES GLOBALES ====================
let player;
let hls;
let currentMovie;
let allMovies = [];

// ==================== ELEMENTOS DOM ====================
const videoElement = document.getElementById('player');
const playerLoading = document.getElementById('player-loading');
const playerError = document.getElementById('player-error');
const errorMessage = document.getElementById('error-message');

// Movie details - Actualizados para el nuevo HTML
const movieTitle = document.getElementById('movie-title');
const movieDescription = document.getElementById('movie-description');
const movieDirector = document.getElementById('movie-director');
const movieOriginalTitle = document.getElementById('movie-original-title');
const relatedGrid = document.getElementById('related-grid');

// Badges
const badgeYear = document.getElementById('badge-year');
const badgeDuration = document.getElementById('badge-duration');
const badgeRating = document.getElementById('badge-rating');

// Detail cards
const detailYear = document.getElementById('detail-year');
const detailDuration = document.getElementById('detail-duration');
const detailDirector = document.getElementById('detail-director');
const detailRatingValue = document.getElementById('detail-rating-value');
const detailRatingCard = document.getElementById('detail-rating-card');

// Awards
const awardsSection = document.getElementById('awards-section');
const awardsList = document.getElementById('awards-list');

// ==================== INICIALIZACIÓN ====================
document.addEventListener('DOMContentLoaded', () => {
  console.log('🎬 Inicializando reproductor mejorado...');
  initializePlayer();
});

/**
 * Inicializa el reproductor
 */
async function initializePlayer() {
  const urlParams = new URLSearchParams(window.location.search);
  const movieId = parseInt(urlParams.get('id'));
  
  if (!movieId) {
    showError('No se especificó ninguna película');
    return;
  }
  
  try {
    console.log('📡 Cargando película desde API...');
    
    const response = await fetch(`${API_URL}/api/movies/${movieId}`);
    
    if (!response.ok) {
      throw new Error(`Película no encontrada (ID: ${movieId})`);
    }
    
    currentMovie = await response.json();
    console.log('🎬 Cargando:', currentMovie.title);
    
    // Cargar información de la película
    loadMovieInfo();
    
    // Configurar reproductor
    setupPlayer();
    
    // Cargar películas relacionadas
    await loadRelatedMovies();
    
  } catch (error) {
    console.error('❌ Error:', error);
    showError(error.message || 'Error al cargar la película');
  }
}

/**
 * Configura el reproductor de video
 */
function setupPlayer() {
  console.log('🎬 Tipo de fuente:', currentMovie.sourceType);
  
  switch(currentMovie.sourceType) {
    case 'iframe':
      setupIframePlayer();
      break;
    case 'hls':
      setupHlsStreaming();
      break;
    case 'mp4':
      setupDirectVideo();
      break;
    default:
      showError('Tipo de fuente no soportado');
  }
}

/**
 * Configura reproductor con iframe embebido
 */
function setupIframePlayer() {
  if (!currentMovie.iframeUrl) {
    showError('No se encontró URL del iframe');
    return;
  }
  
  console.log('📺 Cargando iframe:', currentMovie.iframeUrl);
  
  videoElement.style.display = 'none';
  
  const iframe = document.createElement('iframe');
  iframe.id = 'player-iframe';
  iframe.src = currentMovie.iframeUrl;
  iframe.width = '100%';
  iframe.height = '100%';
  iframe.frameBorder = '0';
  iframe.allowFullscreen = true;
  iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
  iframe.style.position = 'absolute';
  iframe.style.top = '0';
  iframe.style.left = '0';
  iframe.style.width = '100%';
  iframe.style.height = '100%';
  
  const playerWrapper = document.querySelector('.player-wrapper');
  playerWrapper.appendChild(iframe);
  
  iframe.onload = () => {
    console.log('✅ Iframe cargado');
    hideLoading();
  };
  
  setTimeout(() => {
    hideLoading();
  }, 3000);
}

/**
 * Configura streaming HLS
 */
function setupHlsStreaming() {
  if (!currentMovie.hlsUrl) {
    showError('No se encontró URL del stream HLS');
    return;
  }
  
  const streamUrl = currentMovie.hlsUrl;
  console.log('📺 Stream URL:', streamUrl);
  
  if (Hls.isSupported()) {
    setupHlsPlayer(streamUrl);
  } else if (videoElement.canPlayType('application/vnd.apple.mpegurl')) {
    setupNativePlayer(streamUrl);
  } else {
    showError('Tu navegador no soporta reproducción HLS');
  }
}

/**
 * Configura video directo MP4
 */
function setupDirectVideo() {
  if (!currentMovie.mp4Url) {
    showError('No se encontró URL del video');
    return;
  }
  
  console.log('📺 Cargando MP4:', currentMovie.mp4Url);
  
  videoElement.src = currentMovie.mp4Url;
  videoElement.style.display = 'block';
  
  videoElement.addEventListener('loadedmetadata', () => {
    console.log('✅ Video cargado');
    hideLoading();
    initPlyr();
  });
  
  videoElement.addEventListener('error', (e) => {
    console.error('❌ Error de video:', e);
    showError('Error al cargar el video');
  });
}

/**
 * Configura HLS.js
 */
function setupHlsPlayer(streamUrl) {
  hls = new Hls({
    debug: false,
    enableWorker: true,
    lowLatencyMode: true,
    backBufferLength: 90,
    maxBufferLength: 30,
    maxMaxBufferLength: 60,
  });
  
  hls.on(Hls.Events.MANIFEST_PARSED, () => {
    console.log('✅ Manifest cargado');
    hideLoading();
    initPlyr();
    videoElement.play().catch(err => {
      console.log('ℹ️ Autoplay bloqueado:', err.message);
    });
  });
  
  hls.on(Hls.Events.ERROR, (event, data) => {
    console.error('❌ HLS Error:', data);
    
    if (data.fatal) {
      switch(data.type) {
        case Hls.ErrorTypes.NETWORK_ERROR:
          console.log('🔄 Error de red, intentando recuperar...');
          hls.startLoad();
          break;
        case Hls.ErrorTypes.MEDIA_ERROR:
          console.log('🔄 Error de media, intentando recuperar...');
          hls.recoverMediaError();
          break;
        default:
          showError('Error al cargar el video. Por favor, recarga la página.');
          hls.destroy();
          break;
      }
    }
  });
  
  hls.loadSource(streamUrl);
  hls.attachMedia(videoElement);
}

/**
 * Configura reproductor nativo (Safari)
 */
function setupNativePlayer(streamUrl) {
  videoElement.src = streamUrl;
  
  videoElement.addEventListener('loadedmetadata', () => {
    console.log('✅ Video cargado (nativo)');
    hideLoading();
    initPlyr();
  });
  
  videoElement.addEventListener('error', (e) => {
    console.error('❌ Error de video:', e);
    showError('Error al cargar el video');
  });
}

/**
 * Inicializa Plyr (controles del reproductor)
 */
function initPlyr() {
  player = new Plyr(videoElement, {
    controls: [
      'play-large',
      'play',
      'progress',
      'current-time',
      'duration',
      'mute',
      'volume',
      'captions',
      'settings',
      'pip',
      'airplay',
      'fullscreen'
    ],
    settings: ['quality', 'speed'],
    quality: {
      default: 1080,
      options: [1080, 720, 480, 360]
    },
    speed: {
      selected: 1,
      options: [0.5, 0.75, 1, 1.25, 1.5, 2]
    },
    i18n: {
      restart: 'Reiniciar',
      rewind: 'Retroceder {seektime}s',
      play: 'Reproducir',
      pause: 'Pausar',
      fastForward: 'Adelantar {seektime}s',
      seek: 'Buscar',
      seekLabel: '{currentTime} de {duration}',
      played: 'Reproducido',
      buffered: 'Buffered',
      currentTime: 'Tiempo actual',
      duration: 'Duración',
      volume: 'Volumen',
      mute: 'Silenciar',
      unmute: 'Activar sonido',
      enableCaptions: 'Activar subtítulos',
      disableCaptions: 'Desactivar subtítulos',
      settings: 'Configuración',
      menuBack: 'Volver',
      speed: 'Velocidad',
      normal: 'Normal',
      quality: 'Calidad',
      loop: 'Repetir',
      start: 'Inicio',
      end: 'Fin',
      all: 'Todo',
      reset: 'Reiniciar',
      disabled: 'Desactivado',
      enabled: 'Activado',
      advertisement: 'Publicidad',
      qualityBadge: {
        1080: 'FHD',
        720: 'HD',
        480: 'SD',
        360: 'LD'
      }
    }
  });
  
  player.on('ready', () => console.log('🎮 Plyr inicializado'));
  player.on('play', () => console.log('▶️ Reproduciendo'));
  player.on('pause', () => console.log('⏸️ Pausado'));
  player.on('ended', () => console.log('✔️ Finalizado'));
}

/**
 * Carga la información de la película con el nuevo HTML
 */
function loadMovieInfo() {
  // Actualizar título de la página
  document.title = `${currentMovie.title} - AngulismoTV`;
  
  // Actualizar poster del video
  if (videoElement) {
    videoElement.poster = currentMovie.poster;
  }
  
  // Remover skeleton classes
  movieTitle.classList.remove('skeleton-text');
  movieDescription.classList.remove('skeleton-text');
  
  // Título principal
  movieTitle.textContent = currentMovie.title;
  
  // Badges
  if (badgeYear) {
    badgeYear.innerHTML = `<i class="fas fa-calendar"></i> ${currentMovie.year}`;
  }
  
  if (badgeDuration && currentMovie.duration) {
    badgeDuration.innerHTML = `<i class="fas fa-clock"></i> ${currentMovie.duration} min`;
  }
  
  if (badgeRating && currentMovie.rating) {
    badgeRating.innerHTML = `<i class="fas fa-star"></i> ${currentMovie.rating}`;
  } else if (badgeRating) {
    badgeRating.style.display = 'none';
  }
  
  // Metadata
  if (movieDirector) {
    movieDirector.textContent = currentMovie.director;
  }
  
  if (movieOriginalTitle && currentMovie.original_title) {
    movieOriginalTitle.textContent = currentMovie.original_title;
  } else if (document.getElementById('metadata-original-title')) {
    document.getElementById('metadata-original-title').style.display = 'none';
  }
  
  // Descripción
  if (movieDescription) {
    movieDescription.textContent = currentMovie.description;
  }
  
  // Detail cards
  if (detailYear) detailYear.textContent = currentMovie.year;
  if (detailDuration) detailDuration.textContent = currentMovie.duration ? `${currentMovie.duration} min` : 'N/A';
  if (detailDirector) detailDirector.textContent = currentMovie.director;
  
  if (detailRatingValue && currentMovie.rating) {
    detailRatingValue.textContent = currentMovie.rating;
  } else if (detailRatingCard) {
    detailRatingCard.style.display = 'none';
  }
  
  // Awards
  if (currentMovie.awards && currentMovie.awards.length > 0 && awardsSection && awardsList) {
    awardsSection.style.display = 'block';
    awardsList.innerHTML = currentMovie.awards.map(award => `<li>${award}</li>`).join('');
  }
}

/**
 * Carga películas relacionadas desde la API
 */
async function loadRelatedMovies() {
  try {
    console.log('📡 Cargando películas relacionadas...');
    
    const response = await fetch(`${API_URL}/api/movies`);
    
    if (!response.ok) {
      throw new Error('Error al cargar películas relacionadas');
    }
    
    allMovies = await response.json();
    
    // Filtrar película actual
    const related = allMovies.filter(m => m.id !== currentMovie.id);
    
    // Shuffle
    const shuffled = related.sort(() => 0.5 - Math.random());
    
    // Tomar las primeras 4
    const toShow = shuffled.slice(0, 4);
    
    // Renderizar
    relatedGrid.innerHTML = toShow.map(movie => `
      <a href="watch.html?id=${movie.id}" class="related-card">
        <img 
          src="${movie.poster}" 
          alt="${movie.title}"
          class="related-movie-poster"
          loading="lazy"
          onerror="this.src='assets/placeholder.jpg'"
        >
        <div class="related-movie-info">
          <h3 class="related-movie-title">${movie.title}</h3>
          <p class="related-movie-year">${movie.year}</p>
        </div>
      </a>
    `).join('');
    
    console.log(`✅ ${toShow.length} películas relacionadas cargadas`);
    
  } catch (error) {
    console.error('❌ Error al cargar películas relacionadas:', error);
    relatedGrid.innerHTML = `
      <p style="grid-column: 1/-1; text-align: center; color: rgba(255,255,255,0.5); padding: 2rem;">
        No se pudieron cargar las películas relacionadas
      </p>
    `;
  }
}

/**
 * Oculta el loading
 */
function hideLoading() {
  if (playerLoading) {
    playerLoading.classList.add('hidden');
    setTimeout(() => {
      playerLoading.style.display = 'none';
    }, 500);
  }
}

/**
 * Muestra error
 */
function showError(message) {
  console.error('❌', message);
  
  if (playerLoading) {
    playerLoading.style.display = 'none';
  }
  
  if (playerError && errorMessage) {
    errorMessage.textContent = message;
    playerError.classList.add('show');
    playerError.style.display = 'flex';
  }
}

/**
 * Limpieza al salir de la página
 */
window.addEventListener('beforeunload', () => {
  if (hls) {
    hls.destroy();
  }
  if (player) {
    player.destroy();
  }
});

/**
 * Guarda progreso de reproducción
 */
function saveProgress() {
  if (player && currentMovie) {
    const progress = {
      movieId: currentMovie.id,
      currentTime: player.currentTime,
      duration: player.duration,
      timestamp: Date.now()
    };
    
    localStorage.setItem(`movie_progress_${currentMovie.id}`, JSON.stringify(progress));
  }
}

/**
 * Carga progreso guardado
 */
function loadProgress() {
  if (currentMovie) {
    const saved = localStorage.getItem(`movie_progress_${currentMovie.id}`);
    if (saved) {
      const progress = JSON.parse(saved);
      if (progress.currentTime / progress.duration < 0.9) {
        return progress.currentTime;
      }
    }
  }
  return 0;
}

// Guardar progreso cada 10 segundos
if (videoElement) {
  setInterval(() => {
    if (player && !player.paused) {
      saveProgress();
    }
  }, 10000);
}

console.log('✅ Watch.js mejorado cargado (API Mode)');

// ==================== FIN DEL SCRIPT ====================