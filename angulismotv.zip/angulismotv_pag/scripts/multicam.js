(function() {
  'use strict';

  // ==================== DEVICE DETECTION ====================
  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  const isTablet = /iPad|Android(?!.*Mobile)/.test(navigator.userAgent);
  const isLowPerfDevice = isMobile || /(Android|iPhone).*AppleWebKit/.test(navigator.userAgent);
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // ==================== PARALLAX EFFECT (OPTIMIZED) ====================
  function initParallax() {
    if (isLowPerfDevice) return;

    let scrollY = 0;
    let ticking = false;

    function updateParallax() {
      const stars = document.querySelectorAll('.star');
      stars.forEach(star => {
        const speed = parseFloat(star.dataset.speed) || 0;
        const yPos = scrollY * speed;
        star.style.transform = `translateY(${yPos}px)`;
      });
      ticking = false;
    }

    window.addEventListener('scroll', () => {
      scrollY = window.pageYOffset;
      if (!ticking) {
        requestAnimationFrame(updateParallax);
        ticking = true;
      }
    }, { passive: true });
  }

  // ==================== HEADER STARS GENERATION ====================
  function initHeaderStars() {
    const header = document.querySelector('.site-header');
    
  }

  // ==================== CONSTANTS ====================
  const EVENTOS_JSON = 'https://json.angulismotv.workers.dev/euents';
  const STREAMTP_EVENTOS = 'https://streamtp.angulismotv.workers.dev/eventos.json';
  const LA14HD_EVENTOS = 'https://la14hd.angulismotv.workers.dev/eventos/json/agenda123.json';
  const CANALES_JSON = 'https://json.angulismotv.workers.dev/channeIs';
  const LOGOS_JSON = 'https://logos.angulismotv.workers.dev/logos';
  const FETCH_TIMEOUT = 8000;

  // ==================== STATE ====================
  let agendaStreams = [];
  let channelsData = [];
  let currentFilter = 'agenda';
  let currentLayout = 1;
  let activeStreams = {};
  let isFullscreen = false;
  let isLoadingData = false;

  // ==================== UTILITY: FETCH WITH TIMEOUT ====================
  async function fetchJSON(url, options = {}) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), FETCH_TIMEOUT);

    try {
      const response = await fetch(url, {
        cache: 'no-store',
        mode: 'cors',
        signal: controller.signal,
        ...options
      });

      clearTimeout(timeoutId);

      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } catch (error) {
      clearTimeout(timeoutId);
      console.warn(`⚠️ Fetch failed: ${url}`, error.message);
      return null;
    }
  }

  // ==================== 🔥 PROCESAR EVENTOS COMO MAIN.JS ====================
  
  // Función para convertir GMT-5 a GMT-3
  function convertGMT5ToGMT3(dateStr) {
    try {
      if (!dateStr || typeof dateStr !== 'string') return dateStr;
      
      const [date, time] = dateStr.split(' ');
      if (!date || !time) return dateStr;
      
      let yyyy, mm, dd;
      if (date.includes('-')) {
        const parts = date.split('-').map(Number);
        if (parts[0] > 1000) {
          [yyyy, mm, dd] = parts;
        } else {
          [dd, mm, yyyy] = parts;
        }
      } else {
        return dateStr;
      }
      
      const [HH, MM] = time.split(':').map(Number);
      const dt = new Date(yyyy, (mm || 1) - 1, dd || 1, HH || 0, MM || 0, 0, 0);
      
      if (isNaN(dt.getTime())) return dateStr;
      
      dt.setHours(dt.getHours() + 2);
      
      const pad = (n) => n.toString().padStart(2, '0');
      const newDD = pad(dt.getDate());
      const newMM = pad(dt.getMonth() + 1);
      const newYYYY = dt.getFullYear();
      const newHH = pad(dt.getHours());
      const newMM_min = pad(dt.getMinutes());
      
      return `${newDD}-${newMM}-${newYYYY} ${newHH}:${newMM_min}`;
    } catch (e) {
      return dateStr;
    }
  }

  // Adaptar eventos de StreamTP
  function adaptStreamTPEvents(events) {
    if (!Array.isArray(events)) return [];
    
    return events.map(ev => {
      let formattedDate = '';
      if (ev.time) {
        const today = new Date();
        const yyyy = today.getFullYear();
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const dd = String(today.getDate()).padStart(2, '0');
        const initialDate = `${yyyy}-${mm}-${dd} ${ev.time}`;
        formattedDate = convertGMT5ToGMT3(initialDate);
      }
      
      let teams = [];
      if (ev.title && ev.title.includes(' vs ')) {
        teams = ev.title.split(' vs ').map(name => ({ name: name.trim() }));
      } else if (ev.title) {
        teams = [{ name: ev.title.trim() }];
      }
      
      const canales = [];
      if (ev.link) {
        canales.push({
          name: ev.category || 'Transmisión',
          link: btoa(ev.link)
        });
      }
      
      return {
        id: `streamtp-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        start_time: formattedDate,
        teams: teams,
        evento: ev.title || '',
        description: ev.status || '',
        competition_name: ev.category || '',
        competencia: ev.category || '',
        tv_networks: canales,
        canales: canales,
        status: { name: ev.status || '' }
      };
    });
  }

  // Adaptar eventos de LA14HD
  function adaptLA14HDEvents(events) {
    if (!Array.isArray(events)) return [];
    
    return events.map(ev => {
      let teams = [];
      if (ev.title && ev.title.includes(' vs ')) {
        teams = ev.title.split(' vs ').map(name => ({ name: name.trim() }));
      } else if (ev.title) {
        teams = [{ name: ev.title.trim() }];
      }
      
      const canales = [];
      if (ev.link) {
        canales.push({
          name: ev.category || 'La14HD',
          link: btoa(ev.link)
        });
      }
      
      let formattedDate = '';
      if (ev.date && ev.time) {
        const dateParts = ev.date.split('-');
        if (dateParts.length === 3) {
          formattedDate = `${ev.date} ${ev.time}`;
        } else {
          const today = new Date();
          const yyyy = today.getFullYear();
          const mm = String(today.getMonth() + 1).padStart(2, '0');
          const dd = String(today.getDate()).padStart(2, '0');
          formattedDate = `${yyyy}-${mm}-${dd} ${ev.time}`;
        }
      } else if (ev.time) {
        const today = new Date();
        const yyyy = today.getFullYear();
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const dd = String(today.getDate()).padStart(2, '0');
        formattedDate = `${yyyy}-${mm}-${dd} ${ev.time}`;
      }
      
      return {
        id: `la14hd-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        start_time: formattedDate,
        teams: teams,
        evento: ev.title || '',
        description: ev.status || '',
        competition_name: ev.category || '',
        competencia: ev.category || '',
        tv_networks: canales,
        canales: canales,
        status: { name: ev.status || '' }
      };
    });
  }

  // Adaptar eventos manuales
  function adaptManualEvents(events) {
    if (!Array.isArray(events)) return [];
    
    return events.map(ev => {
      let teams = [];
      if (ev.evento && ev.evento.includes(' vs ')) {
        teams = ev.evento.split(' vs ').map(name => ({ name: name.trim() }));
      } else if (ev.evento) {
        teams = [{ name: ev.evento.trim() }];
      }
      
      let canales = [];
      if (Array.isArray(ev.canales)) {
        ev.canales.forEach(canal => {
          if (canal.options && Array.isArray(canal.options)) {
            canal.options.forEach((opt) => {
              canales.push({
                name: `${canal.name} - ${opt.name}`,
                iframe: opt.iframe,
                logo: canal.logo
              });
            });
          } else if (typeof canal === 'string') {
            canales.push({ name: canal });
          } else if (canal.name) {
            canales.push({
              name: canal.name,
              iframe: canal.iframe,
              logo: canal.logo
            });
          }
        });
      } else if (ev.canal) {
        canales = [ev.canal];
      }
      
      return {
        id: `manual-${ev.id || Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        start_time: ev.fecha,
        teams: teams,
        evento: ev.evento,
        description: ev.descripcion || '',
        competition_name: ev.competencia || '',
        competencia: ev.competencia || '',
        tv_networks: canales,
        canales: canales,
        status: { name: ev.estado || '' }
      };
    });
  }

  // Agrupar eventos duplicados
  function groupDuplicateEvents(events) {
    const grouped = {};
    
    events.forEach(event => {
      if (!event || (!event.teams && !event.evento)) return;
      
      let teamNames = [];
      if (event.teams && Array.isArray(event.teams) && event.teams.length > 0) {
        teamNames = event.teams.map(t => t.name?.toLowerCase().trim() || '').filter(name => name);
      } else if (event.evento) {
        const eventoStr = event.evento.toLowerCase();
        let cleanEventName = eventoStr;
        
        if (eventoStr.includes(':')) {
          cleanEventName = eventoStr.split(':').slice(1).join(':').trim();
        }
        
        if (cleanEventName.includes(' vs ')) {
          teamNames = cleanEventName.split(' vs ').map(name => name.trim());
        } else if (cleanEventName.includes(' - ')) {
          teamNames = cleanEventName.split(' - ').map(name => name.trim());
        } else {
          teamNames = [cleanEventName.trim()];
        }
      }
      
      if (teamNames.length === 0) return;
      
      const normalizedTeamNames = teamNames.map(name => 
        name
          .replace(/nhl:\s*/gi, '')
          .replace(/en español\s*/gi, '')
          .replace(/\s*-\s*.+$/, '')
          .trim()
      );
      
      const key = normalizedTeamNames.sort().join('|');
      
      if (!grouped[key]) {
        grouped[key] = {
          id: `group-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          start_time: event.start_time,
          teams: normalizedTeamNames.map(name => ({ name: name.toUpperCase() })),
          evento: event.evento || normalizedTeamNames.join(' vs '),
          description: event.description || '',
          competition_name: event.competition_name || '',
          competencia: event.competencia || '',
          status: event.status || { name: '' },
          sources: [event],
          allNetworks: [...(event.tv_networks || [])],
          allCanales: [...(event.canales || [])]
        };
      } else {
        grouped[key].sources.push(event);
        
        if (event.description && !grouped[key].description) {
          grouped[key].description = event.description;
        }
        
        if (event.competition_name && !grouped[key].competition_name) {
          grouped[key].competition_name = event.competition_name;
        }
        
        // Agregar nuevas opciones
        const newNetworks = event.tv_networks || [];
        newNetworks.forEach(network => {
          const exists = grouped[key].allNetworks.some(existing => 
            existing.name === network.name && existing.iframe === network.iframe
          );
          if (!exists) grouped[key].allNetworks.push(network);
        });
        
        const newCanales = event.canales || [];
        newCanales.forEach(canal => {
          const exists = grouped[key].allCanales.some(existing => 
            existing.name === canal.name && existing.iframe === canal.iframe
          );
          if (!exists) grouped[key].allCanales.push(canal);
        });
      }
    });
    
    return Object.values(grouped);
  }

  // ==================== LOAD AGENDA DATA ====================
  async function loadAgendaData() {
    if (isLoadingData) return;
    isLoadingData = true;

    console.log('📥 Cargando eventos desde todas las fuentes...');

    try {
      // Cargar de todas las fuentes en paralelo
      const [manualEventsRaw, streamTPEventsRaw, la14HDEventsRaw, canalesRaw] = await Promise.allSettled([
        fetchJSON(EVENTOS_JSON),
        fetchJSON(STREAMTP_EVENTOS),
        fetchJSON(LA14HD_EVENTOS),
        fetchJSON(CANALES_JSON)
      ]);

      // Procesar eventos manuales
      const manualEvents = manualEventsRaw.status === 'fulfilled' && Array.isArray(manualEventsRaw.value)
        ? adaptManualEvents(manualEventsRaw.value)
        : [];

      // Procesar StreamTP
      const streamTPEvents = streamTPEventsRaw.status === 'fulfilled'
        ? adaptStreamTPEvents(
            Array.isArray(streamTPEventsRaw.value) 
              ? streamTPEventsRaw.value 
              : streamTPEventsRaw.value?.Events || []
          )
        : [];

      // Procesar LA14HD
      const la14HDEvents = la14HDEventsRaw.status === 'fulfilled'
        ? adaptLA14HDEvents(
            Array.isArray(la14HDEventsRaw.value)
              ? la14HDEventsRaw.value
              : la14HDEventsRaw.value?.Events || []
          )
        : [];

      // Combinar todos los eventos
      const rawEvents = [...manualEvents, ...streamTPEvents, ...la14HDEvents];
      console.log(`📊 Eventos crudos: ${rawEvents.length} (manual: ${manualEvents.length}, streamTP: ${streamTPEvents.length}, la14hd: ${la14HDEvents.length})`);

      // Agrupar eventos duplicados
      agendaStreams = groupDuplicateEvents(rawEvents);
      console.log(`✅ Eventos agrupados: ${agendaStreams.length}`);

      // Procesar canales
      if (canalesRaw.status === 'fulfilled' && canalesRaw.value?.channels) {
        channelsData = [];
        canalesRaw.value.channels.forEach(channel => {
          if (channel.show === true) {
            if (channel.options && Array.isArray(channel.options) && channel.options.length > 0) {
              channel.options.forEach(option => {
                channelsData.push({
                  name: channel.name,
                  logo: channel.logo,
                  optionName: option.name,
                  iframe: option.iframe,
                  url: option.iframe,
                  displayName: channel.options.length > 1 ? `${channel.name} - ${option.name}` : channel.name,
                  categoria: 'Canal deportivo'
                });
              });
            } else {
              channelsData.push({
                name: channel.name,
                logo: channel.logo,
                iframe: channel.iframe,
                url: channel.iframe,
                displayName: channel.name,
                categoria: 'Canal deportivo'
              });
            }
          }
        });
        console.log(`✅ Canales cargados: ${channelsData.length}`);
      }

      loadStreamOptions();
    } catch (error) {
      console.error('❌ Error cargando datos:', error);
    } finally {
      isLoadingData = false;
    }
  }

  // ==================== GET DIRECT PLAYER URL ====================
  function getDirectPlayerUrl(streamData) {
    if (!streamData) return null;

    // Prioridad 1: URL directa
    if (streamData.url) return streamData.url;
    if (streamData.iframe) return streamData.iframe;

    // Prioridad 2: Buscar en allNetworks (eventos agrupados)
    if (streamData.allNetworks?.length > 0) {
      const network = streamData.allNetworks[0];
      if (network.iframe) return network.iframe;
      if (network.link) {
        try {
          return atob(network.link);
        } catch (e) {
          return network.link;
        }
      }
      if (network.url) return network.url;
    }

    // Prioridad 3: Buscar en tv_networks
    if (streamData.tv_networks?.length > 0) {
      const network = streamData.tv_networks[0];
      if (network.iframe) return network.iframe;
      if (network.link) {
        try {
          return atob(network.link);
        } catch (e) {
          return network.link;
        }
      }
      if (network.url) return network.url;
    }

    // Prioridad 4: Buscar en canales
    if (streamData.canales?.length > 0) {
      const canal = streamData.canales[0];
      if (canal.iframe) return canal.iframe;
      if (canal.link) {
        try {
          return atob(canal.link);
        } catch (e) {
          return canal.link;
        }
      }
      if (canal.url) return canal.url;
    }

    console.warn('⚠️ No valid URL found for stream:', streamData.evento || streamData.name);
    return null;
  }

  // ==================== LOAD STREAM OPTIONS ====================
  function loadStreamOptions() {
    for (let i = 1; i <= 4; i++) {
      const dropdown = document.getElementById(`dropdown-${i}`);
      if (dropdown) dropdown.innerHTML = '';
    }

    const dataToShow = currentFilter === 'agenda' ? agendaStreams : channelsData;

    if (!dataToShow?.length) {
      for (let i = 1; i <= 4; i++) {
        const dropdown = document.getElementById(`dropdown-${i}`);
        if (dropdown) {
          const msg = document.createElement('div');
          msg.className = 'stream-option';
          msg.style.opacity = '0.6';
          msg.innerHTML = `<div class="stream-info"><div class="stream-title">No hay ${currentFilter === 'agenda' ? 'eventos' : 'canales'}</div></div>`;
          dropdown.appendChild(msg);
        }
      }
      return;
    }

    dataToShow.forEach((item, index) => {
      for (let i = 1; i <= 4; i++) {
        const dropdown = document.getElementById(`dropdown-${i}`);
        if (!dropdown) continue;

        const option = document.createElement('div');
        option.className = 'stream-option';

        if (currentFilter === 'agenda') {
          const eventTitle = item.evento || 'Evento sin título';
          const competition = item.competition_name || item.competencia || 'Sin competencia';
          const time = formatTime(item.start_time);
          
          option.innerHTML = `
            <div class="stream-info">
              <div class="stream-title">${eventTitle}</div>
              <div class="stream-meta">${competition} • ${time}</div>
            </div>
          `;
        } else {
          const channelName = item.displayName || item.name || `Canal ${index + 1}`;
          const channelCategory = item.categoria || item.optionName || 'Canal en vivo';
          
          option.innerHTML = `
            <div class="stream-info">
              <div class="stream-title">${channelName}</div>
              <div class="stream-meta">${channelCategory}</div>
            </div>
          `;
        }

        option.addEventListener('click', () => selectStream(i, item), { once: false });
        dropdown.appendChild(option);
      }
    });
  }

  // ==================== FORMAT TIME ====================
  function formatTime(str) {
    if (!str) return '--:--';
    if (str.includes(' ')) {
      const parts = str.split(' ');
      if (parts.length < 2) return '--:--';
      return parts[1].substring(0, 5);
    }
    if (str.includes(':')) return str.substring(0, 5);
    return '--:--';
  }

  // ==================== SETUP EVENT LISTENERS ====================
  function setupEventListeners() {
    const layoutDropdownBtn = document.getElementById('layoutDropdownBtn');
    const layoutDropdown = document.getElementById('layoutDropdown');

    if (layoutDropdownBtn) {
      layoutDropdownBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        layoutDropdown?.classList.toggle('show');
        this.classList.toggle('active');
      });
    }

    const filterAgenda = document.getElementById('filterAgenda');
    const filterChannels = document.getElementById('filterChannels');

    filterAgenda?.addEventListener('click', () => {
      if (currentFilter !== 'agenda') {
        currentFilter = 'agenda';
        filterAgenda.classList.add('active');
        filterChannels?.classList.remove('active');
        loadStreamOptions();
      }
    });

    filterChannels?.addEventListener('click', () => {
      if (currentFilter !== 'channels') {
        currentFilter = 'channels';
        filterChannels.classList.add('active');
        filterAgenda?.classList.remove('active');
        loadStreamOptions();
      }
    });

    document.querySelectorAll('.layout-option').forEach(option => {
      option.addEventListener('click', function() {
        const layout = parseInt(this.dataset.layout);
        changeLayout(layout);
        const layoutLabel = layoutDropdownBtn?.querySelector('.layout-label');
        if (layoutLabel) layoutLabel.textContent = this.textContent;
        layoutDropdown?.classList.remove('show');
        layoutDropdownBtn?.classList.remove('active');
      });
    });

    document.querySelectorAll('.dropdown-btn').forEach(btn => {
      btn.addEventListener('click', function(e) {
        e.stopPropagation();
        toggleStreamDropdown(this.dataset.slot);
      });
    });

    document.getElementById('globalFullscreen')?.addEventListener('click', toggleGlobalFullscreen);

    document.addEventListener('click', function(e) {
      if (!e.target.closest('.card-header') && !e.target.closest('.stream-dropdown')) {
        layoutDropdown?.classList.remove('show');
        layoutDropdownBtn?.classList.remove('active');
        document.querySelectorAll('.dropdown-content').forEach(d => d.classList.remove('show'));
        document.querySelectorAll('.dropdown-btn').forEach(b => b.classList.remove('active'));
      }
    });

    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape' && isFullscreen) toggleGlobalFullscreen();
    });

    ['fullscreenchange', 'webkitfullscreenchange', 'mozfullscreenchange', 'MSFullscreenChange'].forEach(event => {
      document.addEventListener(event, handleFullscreenChange);
    });
  }

  // ==================== HANDLE FULLSCREEN CHANGE ====================
  function handleFullscreenChange() {
    const fullscreenElement = document.fullscreenElement ||
                             document.webkitFullscreenElement ||
                             document.mozFullScreenElement ||
                             document.msFullscreenElement;

    if (!fullscreenElement && isFullscreen) {
      toggleGlobalFullscreen();
    }
  }

  // ==================== CLOSE ALL DROPDOWNS ====================
  function closeAllStreamDropdowns() {
    document.querySelectorAll('.dropdown-content').forEach(d => d.classList.remove('show'));
    document.querySelectorAll('.dropdown-btn').forEach(b => b.classList.remove('active'));
    document.getElementById('layoutDropdown')?.classList.remove('show');
    document.getElementById('layoutDropdownBtn')?.classList.remove('active');
  }

  // ==================== TOGGLE STREAM DROPDOWN ====================
  function toggleStreamDropdown(slot) {
    const dropdown = document.getElementById(`dropdown-${slot}`);
    const btn = document.querySelector(`.dropdown-btn[data-slot="${slot}"]`);

    if (!dropdown || !btn) return;

    const wasOpen = dropdown.classList.contains('show');
    closeAllStreamDropdowns();

    if (!wasOpen) {
      dropdown.classList.add('show');
      btn.classList.add('active');
    }
  }

  // ==================== CHANGE LAYOUT ====================
  function changeLayout(layout) {
    currentLayout = layout;

    const grid = document.getElementById('streamsGrid');
    if (grid) grid.className = `streams-grid layout-${layout}`;

    for (let i = 1; i <= 4; i++) {
      const streamElement = document.getElementById(`stream-${i}`);
      const dropdownContainer = document.getElementById(`dropdown-container-${i}`);

      if (i <= layout) {
        if (!streamElement) createStreamElement(i);
        if (dropdownContainer) dropdownContainer.style.display = 'block';
      } else {
        if (streamElement) streamElement.remove();
        if (dropdownContainer) dropdownContainer.style.display = 'none';
        delete activeStreams[i];
        const btn = document.querySelector(`.dropdown-btn[data-slot="${i}"]`);
        if (btn) btn.textContent = `Seleccionar evento para la pantalla ${i}`;
      }
    }
  }

  // ==================== CREATE STREAM ELEMENT ====================
  function createStreamElement(slot) {
    const grid = document.getElementById('streamsGrid');
    if (!grid || document.getElementById(`stream-${slot}`)) return;

    const streamElement = document.createElement('article');
    streamElement.className = 'stream-item';
    streamElement.id = `stream-${slot}`;
    streamElement.dataset.slot = slot;

    const streamData = activeStreams[slot];
    const playerUrl = streamData ? getDirectPlayerUrl(streamData) : null;

    if (streamData && playerUrl) {
      streamElement.classList.add('active');
      const streamTitle = streamData.displayName || streamData.evento || streamData.name || `Stream ${slot}`;
      streamElement.innerHTML = `
        <header class="stream-header">
          <div class="stream-title-bar">
            <strong>Pantalla ${slot}</strong>
            <span> - ${streamTitle}</span>
          </div>
        </header>
        <div class="stream-content">
          <iframe class="stream-iframe" src="${playerUrl}" scrolling="no" allow="autoplay; fullscreen; encrypted-media; picture-in-picture; accelerometer; gyroscope" referrerpolicy="no-referrer" title="${streamTitle}"></iframe>
        </div>
      `;
    } else {
      streamElement.innerHTML = `
        <header class="stream-header">
          <div class="stream-title-bar"><strong>Pantalla ${slot}</strong></div>
        </header>
        <div class="stream-content">
          <div class="stream-placeholder">
            <span class="placeholder-icon">📺</span>
            <span class="placeholder-text">Selecciona un evento para comenzar</span>
          </div>
        </div>
      `;
    }

    grid.appendChild(streamElement);
  }

  // ==================== SELECT STREAM ====================
  function selectStream(slot, stream) {
    activeStreams[slot] = stream;
    const playerUrl = getDirectPlayerUrl(stream);

    const dropdownBtn = document.querySelector(`.dropdown-btn[data-slot="${slot}"]`);
    if (dropdownBtn) {
      const displayName = stream.displayName || stream.evento || stream.name || `Stream ${slot}`;
      dropdownBtn.textContent = displayName.length > 40 ? displayName.substring(0, 40) + '...' : displayName;
    }

    const streamElement = document.getElementById(`stream-${slot}`);
    if (!streamElement) {
      createStreamElement(slot);
      return;
    }

    const streamTitle = stream.displayName || stream.evento || stream.name || `Stream ${slot}`;

    if (playerUrl) {
      streamElement.classList.add('active');
      streamElement.innerHTML = `
        <header class="stream-header">
          <div class="stream-title-bar">
            <strong>Pantalla ${slot}</strong>
            <span> - ${streamTitle}</span>
          </div>
        </header>
        <div class="stream-content">
          <iframe class="stream-iframe" src="${playerUrl}" scrolling="no" allow="autoplay; fullscreen; encrypted-media; picture-in-picture; accelerometer; gyroscope" referrerpolicy="no-referrer" title="${streamTitle}"></iframe>
        </div>
      `;
    } else {
      streamElement.classList.remove('active');
      streamElement.innerHTML = `
        <header class="stream-header">
          <div class="stream-title-bar"><strong>Pantalla ${slot}</strong></div>
        </header>
        <div class="stream-content">
          <div class="stream-placeholder">
            <span class="placeholder-icon">❌</span>
            <span class="placeholder-text">No se pudo cargar el stream</span>
          </div>
        </div>
      `;
    }

    closeAllStreamDropdowns();
  }

  // ==================== TOGGLE GLOBAL FULLSCREEN ====================
  function toggleGlobalFullscreen() {
    if (!isFullscreen) {
      document.body.classList.add('fullscreen-mode');

      const exitBtn = document.createElement('button');
      exitBtn.className = 'exit-fullscreen-btn';
      exitBtn.id = 'exitFullscreenBtn';
      exitBtn.innerHTML = '<span>✕</span>';
      exitBtn.setAttribute('aria-label', 'Salir de pantalla completa');
      exitBtn.addEventListener('click', toggleGlobalFullscreen);
      document.body.appendChild(exitBtn);

      isFullscreen = true;

      const element = document.documentElement;
      if (element.requestFullscreen) {
        element.requestFullscreen().catch(err => console.warn('Fullscreen error:', err));
      } else if (element.webkitRequestFullscreen) {
        element.webkitRequestFullscreen();
      } else if (element.mozRequestFullScreen) {
        element.mozRequestFullScreen();
      } else if (element.msRequestFullscreen) {
        element.msRequestFullscreen();
      }
    } else {
      document.body.classList.remove('fullscreen-mode');
      document.getElementById('exitFullscreenBtn')?.remove();
      isFullscreen = false;

      if (document.exitFullscreen) {
        document.exitFullscreen().catch(err => console.warn('Exit fullscreen error:', err));
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
      } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
      } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
      }
    }
  }

  // ==================== PREVENT DOUBLE-TAP ZOOM (MOBILE ONLY) ====================
  if (isMobile) {
    let lastTouchEnd = 0;
    document.addEventListener('touchend', function(e) {
      const now = Date.now();
      if (now - lastTouchEnd <= 300) {
        e.preventDefault();
      }
      lastTouchEnd = now;
    }, { passive: false });
  }

  // ==================== INITIALIZATION ====================
  document.addEventListener('DOMContentLoaded', () => {
    if (!prefersReducedMotion && !isLowPerfDevice) initParallax();
    initHeaderStars();
    loadAgendaData();
    setupEventListeners();
  });

  console.log(`🎬 AngulismoTV Multicam - ${isMobile ? '📱 Mobile' : isTablet ? '📊 Tablet' : '🖥️ Desktop'}`);
  console.log('⌨️ Shortcuts: ESC (exit fullscreen)');
})();