/**
 * ANGULISMO TV - AGENDA SYSTEM
 * Sistema de gestión de eventos deportivos con soporte multi-fuente
 * Versión: 2.0
 */

// ==================== CONFIGURATION ====================

const CONFIG = {
  urls: {
    channels: 'https://json.angulismotv.workers.dev/channeIs',
    events: 'https://json.angulismotv.workers.dev/euents',
    streamTP: 'https://streamtp.angulismotv.workers.dev/eventos.json',
    la14HD: 'https://la14hd.angulismotv.workers.dev/eventos/json/agenda123.json',
    logos: 'https://logos.angulismotv.workers.dev/logos',
    elcanal: 'https://elcanaldeportivo.angulismotv.workers.dev/partidos.json' 
  },
  cache: {
    duration: 5 * 60 * 1000,
    key: 'angulismo_cache_v5'
  },
  filters: [
    { id: 'all', label: '📋 Todos', icon: '📋' },
    { id: 'live', label: '🔴 En Vivo', icon: '🔴' },
    { id: 'football', label: '⚽ Fútbol', icon: '⚽' },
    { id: 'f1', label: '🏎️ Fórmula 1', icon: '🏎️' },
  ]
};

// ==================== CHANNEL NAME EXTRACTOR ====================

class ChannelNameExtractor {
  constructor() {
    this.specialNames = {
      // ESPN variants
      'espn': 'ESPN', 
      'espnplus': 'ESPN+', 
      'espnpremium': 'ESPN Premium',
      'espn2': 'ESPN 2', 
      'espn3': 'ESPN 3', 
      'espn4': 'ESPN 4',
      'espnmx': 'ESPN México', 
      'espn2mx': 'ESPN 2 México', 
      'espn3mx': 'ESPN 3 México',
      'espndeportes': 'ESPN Deportes',
      // FOX variants
      'fox': 'FOX', 
      'foxsports': 'Fox Sports', 
      'foxsports2': 'Fox Sports 2', 
      'foxsports3': 'Fox Sports 3',
      // TNT
      'tnt': 'TNT', 
      'tntsports': 'TNT Sports',
      // General channels
      'hbo': 'HBO', 
      'hbomax': 'HBO Max', 
      'nbc': 'NBC', 
      'cbs': 'CBS', 
      'abc': 'ABC',
      'bbc': 'BBC', 
      'bein': 'BeIN Sports', 
      'beinsports': 'BeIN Sports',
      // Sports streaming
      'dazn': 'DAZN', 
      'tudn': 'TUDN', 
      'directv': 'DirecTV', 
      'directvsports': 'DirecTV Sports',
      'sky': 'Sky Sports', 
      'skysports': 'Sky Sports',
      // General streaming
      'star': 'Star+', 
      'starplus': 'Star+',
      'disney': 'Disney+',
      'disneyplus': 'Disney+',
      'max': 'Max', 
      'paramount': 'Paramount+', 
      'paramountplus': 'Paramount+',
      'peacock': 'Peacock', 
      'appletv': 'Apple TV+',
      'prime': 'Prime Video', 
      'primevideo': 'Prime Video',
      'youtube': 'YouTube', 
      'twitch': 'Twitch',
      // Latin America
      'univision': 'Univision', 
      'telemundo': 'Telemundo',
      'tyc': 'TyC Sports', 
      'tycsports': 'TyC Sports',
      'dsports': 'DSports',
      'win': 'Win Sports', 
      'winsports': 'Win Sports', 
      'winsports2': 'Win Sports 2',
      'gol': 'Gol TV', 
      'goltv': 'Gol TV',
      'movistar': 'Movistar+', 
      'movistarplus': 'Movistar+',
      'vix': 'ViX', 
      'flow': 'Flow', 
      'claro': 'Claro Sports', 
      'clarosports': 'Claro Sports',
      'sportdigital': 'Sport Digital', 
      'sportdigitaltv': 'Sport Digital',
      'vivo': 'Vivo', 
      'eventos': 'Eventos',
      'america': 'América TV', 
      'americatv': 'América TV',
      'caracol': 'Caracol', 
      'rcn': 'RCN',
      'telefe': 'Telefe', 
      'canal13': 'Canal 13',
      'mega': 'Mega', 
      'chilevision': 'Chilevisión',
      // Others
      'futbol': 'Fútbol', 
      'nfl': 'NFL', 
      'nba': 'NBA',
      'winplus': 'Win Plus',
      'canal5mx': 'Canal 5 MX',
      'tycinternacional': 'TyC Internacional',
      'foxdeportes': 'FOX Deportes',
      'foxone': 'FOX One',
      'espn1nl': 'ESPN 1 NL',
      'liga1max': 'Liga 1 Max'
    };

    this.ignoreWords = [
      'stream', 'live', 'video', 'hls', 'index', 'playlist',
      'master', 'chunk', 'segment', 'ts', 'channel', 'channels',
      'play', 'watch', 'embed', 'player', 'api', 'v1', 'v2', 'www'
    ];
  }

  extract(url, fallback = 'Canal') {
    if (!url) return fallback;
    
    try {
      const link = new URL(url);
      const hostname = link.hostname.toLowerCase();
      const pathname = link.pathname.toLowerCase();
      const params = new URLSearchParams(link.search);
      
      // Step 1: Search in URL parameters
      for (const param of ['channel', 'ch', 'c', 'canal', 'stream', 'id']) {
        const value = params.get(param);
        if (value && value.length > 1 && value.length < 50) {
          const formatted = this.formatName(value);
          if (formatted && formatted !== fallback && !this.ignoreWords.includes(formatted.toLowerCase())) {
            return formatted;
          }
        }
      }
      
      // Step 2: Search in path segments
      const pathParts = pathname.split('/').filter(p => p && p.length > 1);
      for (const part of pathParts) {
        const clean = part.replace(/\.(m3u8|mp4|ts|mpd|html|php)$/i, '').toLowerCase();
        
        if (this.ignoreWords.includes(clean) || clean.length < 2 || clean.length > 30) {
          continue;
        }
        
        const formatted = this.formatName(clean);
        if (formatted && formatted !== fallback && !this.ignoreWords.some(w => formatted.toLowerCase().includes(w))) {
          return formatted;
        }
      }
      
      // Step 3: Search in subdomain
      const subdomainParts = hostname.split('.');
      if (subdomainParts.length > 2) {
        const subdomain = subdomainParts[0];
        if (subdomain && subdomain !== 'www' && subdomain.length > 2 && subdomain.length < 20) {
          const formatted = this.formatName(subdomain);
          if (formatted && formatted !== fallback && !this.ignoreWords.includes(formatted.toLowerCase())) {
            return formatted;
          }
        }
      }
      
      // Step 4: Use domain as last resort
      const domain = hostname.replace('www.', '').split('.')[0];
      if (domain && domain.length > 2 && !this.ignoreWords.includes(domain)) {
        const formatted = this.formatName(domain);
        if (formatted && formatted !== fallback) {
          return formatted;
        }
      }
      
      return fallback;
      
    } catch (e) {
      return fallback;
    }
  }

  formatName(name) {
    if (!name) return '';
    
    // Clean name
    let cleanName = name
      .toLowerCase()
      .replace(/[-_]/g, ' ')
      .replace(/\.(m3u8|mp4|ts|mpd|html|php)$/i, '')
      .replace(/\s+/g, ' ')
      .trim();
    
    // Check special names (without spaces)
    const noSpaces = cleanName.replace(/\s/g, '');
    if (this.specialNames[noSpaces]) {
      return this.specialNames[noSpaces];
    }
    
    // Separate trailing numbers
    cleanName = cleanName.replace(/([a-z])(\d+)$/i, '$1 $2');
    
    // Format each word
    const words = cleanName.split(' ').map(word => {
      // Keep numbers
      if (/^\d+$/.test(word)) return word;
      
      // Check if it's a special name
      if (this.specialNames[word]) return this.specialNames[word];
      
      // HD, UHD, 4K, TV in uppercase
      if (word === 'hd') return 'HD';
      if (word === 'uhd') return 'UHD';
      if (word === '4k') return '4K';
      if (word === 'tv') return 'TV';
      
      // Special Spanish words
      if (word === 'deportes') return 'Deportes';
      if (word === 'america') return 'América';
      if (word === 'mexico') return 'México';
      if (word === 'premium') return 'Premium';
      if (word === 'go') return 'Go';
      
      // Short acronyms (2-3 letters) in uppercase
      if (word.length <= 3 && /^[a-z]+$/.test(word)) {
        return word.toUpperCase();
      }
      
      // Capitalize first letter
      return word.charAt(0).toUpperCase() + word.slice(1);
    }).filter(Boolean);
    
    return words.join(' ');
  }
}

const channelExtractor = new ChannelNameExtractor();

// ==================== CACHE MANAGER ====================

class CacheManager {
  static get(key) {
    try {
      const item = localStorage.getItem(key);
      if (!item) return null;
      
      const { data, timestamp } = JSON.parse(item);
      if (Date.now() - timestamp > CONFIG.cache.duration) {
        localStorage.removeItem(key);
        return null;
      }
      
      return data;
    } catch {
      return null;
    }
  }
  
  static set(key, data) {
    try {
      localStorage.setItem(key, JSON.stringify({ data, timestamp: Date.now() }));
    } catch (error) {
      console.warn('Cache storage error:', error);
    }
  }
  
  static clear(key) {
    localStorage.removeItem(key);
  }
}

// ==================== LOGO SYSTEM ====================

class LogoManager {
  constructor() {
    this.logosDB = null;
    this.loading = false;
  }

  async loadLogos() {
    if (this.logosDB) return this.logosDB;
    if (this.loading) return null;
    
    this.loading = true;
    
    try {
      const response = await fetch(CONFIG.urls.logos);
      const data = await response.json();
      this.logosDB = data.logos;
      return this.logosDB;
    } catch (error) {
      this.logosDB = {};
      return this.logosDB;
    } finally {
      this.loading = false;
    }
  }

  normalizeText(text) {
    if (!text) return '';
    return text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^\w\s]/g, " ").trim();
  }

  detectLogo(event) {
    if (!this.logosDB) return null;

    const searchText = this.normalizeText([
      event.evento || '', event.description || '',
      event.competition_name || '', event.competencia || ''
    ].join(' '));

    for (const [key, logoData] of Object.entries(this.logosDB)) {
      if (searchText.includes(this.normalizeText(key))) {
        return { logo: logoData.url, competition: logoData.name };
      }
      
      if (logoData.keywords) {
        for (const keyword of logoData.keywords) {
          if (searchText.includes(this.normalizeText(keyword))) {
            return { logo: logoData.url, competition: logoData.name };
          }
        }
      }
    }

    return null;
  }
}

const logoManager = new LogoManager();

// ==================== HELPER FUNCTIONS ====================

function createEl(tag, className = '', text = '') {
  const el = document.createElement(tag);
  if (className) el.className = className;
  if (text) el.textContent = text;
  return el;
}

function pad(n) { 
  return n.toString().padStart(2, '0'); 
}

function formatTime(str) {
  if (!str) return '--:--';
  if (str.includes(' ')) {
    const parts = str.split(' ');
    if (parts.length < 2) return '--:--';
    return parts[1].substring(0, 5);
  }
  if (str.includes(':')) return str;
  return '--:--';
}

function formatDayBanner() {
  const now = new Date();
  const dias = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
  const meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
  const d = now.getDate();
  const dia = dias[now.getDay()];
  const mes = meses[now.getMonth()];
  const year = now.getFullYear();
  return `Agenda - ${dia} ${pad(d)} de ${mes} de ${year}`;
}

function isEventLive(startTime) {
  if (!startTime) return false;
  try {
    const eventTime = new Date(startTime.replace(/(\d{4})-(\d{2})-(\d{2})/, '$1-$2-$3'));
    const now = new Date();
    const diffHours = (now - eventTime) / (1000 * 60 * 60);
    return diffHours >= 0 && diffHours < 3;
  } catch {
    return false;
  }
}

function isEventUpcoming(startTime) {
  if (!startTime) return true;
  try {
    const eventTime = new Date(startTime.replace(/(\d{4})-(\d{2})-(\d{2})/, '$1-$2-$3'));
    const now = new Date();
    return eventTime > now;
  } catch {
    return true;
  }
}

/**
 * Normalize team name for comparison and matching
 * Handles common abbreviations and variations
 */
function normalizeTeamName(name) {
  if (!name) return '';
  
  const abbreviations = {
    'barcelona': ['barça', 'barca', 'fcb', 'fc barcelona', 'fc barça'],
    'real madrid': ['madrid', 'rmadrid', 'rm', 'real', 'r madrid'],
    'atletico madrid': ['atletico', 'atleti', 'atm', 'atletico de madrid', 'atl madrid'],
    'athletic bilbao': ['athletic', 'bilbao', 'ath bilbao', 'athletic club'],
    'manchester united': ['man united', 'man utd', 'manchester utd', 'united', 'm united'],
    'manchester city': ['man city', 'city', 'manchester c', 'm city'],
    'bayern munich': ['bayern', 'fcb munich', 'fc bayern', 'bayern munchen'],
    'paris saint germain': ['psg', 'paris sg', 'paris', 'paris saint-germain'],
    'inter milan': ['inter', 'internazionale', 'inter de milan'],
    'ac milan': ['milan', 'acm', 'ac milan'],
    'juventus': ['juve', 'juventus fc'],
    'atletico tucuman': ['atletico tucuman', 'atl tucuman', 'tucuman', 'atl. tucuman'],
    'river plate': ['river', 'carp', 'river plate'],
    'boca juniors': ['boca', 'cabj', 'boca jrs'],
    'america': ['america mexico', 'club america', 'america mex'],
    'chivas': ['guadalajara', 'chivas guadalajara', 'chivas gdl'],
    'cruz azul': ['cruz azul fc', 'la maquina'],
    'cerro largo': ['cerro largo fc', 'cerro'],
    'atletico san luis': ['san luis', 'atl san luis', 'atletico sl']
  };
  
  const normalized = name.toLowerCase().trim();
  
  for (const [full, abbrevs] of Object.entries(abbreviations)) {
    if (normalized === full || abbrevs.includes(normalized)) {
      return full;
    }
  }
  
  return normalized;
}

/**
 * Calculate similarity score between two team arrays
 * Returns: 1.0 (perfect match), 0.95 (reversed order), or partial score
 */
function calculateTeamSimilarity(teams1, teams2) {
  if (teams1.length !== teams2.length) return 0;
  
  // Case 1: Same exact order
  let matches = 0;
  for (let i = 0; i < teams1.length; i++) {
    if (teams1[i] === teams2[i]) matches++;
  }
  
  if (matches === teams1.length) return 1.0;
  
  // Case 2: Reversed order
  matches = 0;
  for (let i = 0; i < teams1.length; i++) {
    if (teams1[i] === teams2[teams2.length - 1 - i]) matches++;
  }
  
  if (matches === teams1.length) return 0.95;
  
  // Case 3: Partial similarity (abbreviations)
  let partialMatches = 0;
  for (const team1 of teams1) {
    for (const team2 of teams2) {
      // Substring similarity
      if (team1.includes(team2) || team2.includes(team1)) {
        partialMatches++;
        break;
      }
      // Common keywords (words longer than 3 chars)
      const words1 = team1.split(' ').filter(w => w.length > 3);
      const words2 = team2.split(' ').filter(w => w.length > 3);
      const commonWords = words1.filter(w => words2.includes(w));
      if (commonWords.length > 0) {
        partialMatches += 0.5;
        break;
      }
    }
  }
  
  return partialMatches / teams1.length;
}

/**
 * Rename duplicate channel options to avoid conflicts
 * Adds sequential numbers to duplicate names
 */
function renameDuplicateOptions(options) {
  if (!Array.isArray(options) || options.length === 0) return [];
  
  const nameCount = {};
  const result = [];
  const usedNames = new Set();
  
  options.forEach(option => {
    const name = option.name || 'Opción';
    const baseName = name.replace(/\s*\(\d+\)$/, '').trim();
    nameCount[baseName] = (nameCount[baseName] || 0) + 1;
  });
  
  options.forEach((option, index) => {
    let name = option.name || 'Opción';
    const baseName = name.replace(/\s*\(\d+\)$/, '').trim();
    
    if (nameCount[baseName] > 1) {
      let counter = 1;
      let newName = `${baseName} (${counter})`;
      
      while (usedNames.has(newName)) {
        counter++;
        newName = `${baseName} (${counter})`;
      }
      
      name = newName;
    }
    
    usedNames.add(name);
    
    result.push({
      ...option,
      name: name,
      displayName: name,
      originalName: option.name || 'Opción'
    });
  });
  
  return result;
}

/**
 * Parse start time from various string formats
 * Returns Date object or max date if parsing fails
 */
function parseStartTime(str) {
  try {
    if (!str || typeof str !== 'string') return new Date(8640000000000000);
    let cleanStr = str.trim();
    if (cleanStr.includes(':') && !cleanStr.includes('-')) {
      const today = new Date();
      const yyyy = today.getFullYear();
      const mm = pad(today.getMonth() + 1);
      const dd = pad(today.getDate());
      cleanStr = `${yyyy}-${mm}-${dd} ${cleanStr}`;
    }
    const [date, time] = cleanStr.split(' ');
    if (!date || !time) return new Date(8640000000000000);
    let yyyy, mm, dd;
    if (date.includes('-')) {
      const parts = date.split('-').map(Number);
      if (parts[0] > 1000) {
        [yyyy, mm, dd] = parts;
      } else {
        [dd, mm, yyyy] = parts;
        if (yyyy < 1000) yyyy += 2000;
      }
    } else {
      return new Date(8640000000000000);
    }
    const [HH, MM] = time.split(':').map(Number);
    const dt = new Date(yyyy, (mm || 1) - 1, dd || 1, HH || 0, MM || 0, 0, 0);
    if (isNaN(dt.getTime())) {
      return new Date(8640000000000000);
    }
    return dt;
  } catch (error) {
    return new Date(8640000000000000);
  }
}

// ==================== TIMEZONE NORMALIZATION ====================

/**
 * Convert date from GMT-5 to GMT-3 (Argentina timezone)
 * Used for StreamTP and LA14HD sources which provide times in GMT-5
 */
function convertGMT5ToGMT3(dateStr) {
  try {
    if (!dateStr || typeof dateStr !== 'string') return dateStr;
    
    const [date, time] = dateStr.split(' ');
    if (!date || !time) return dateStr;
    
    let yyyy, mm, dd;
    
    if (date.includes('-')) {
      const parts = date.split('-').map(Number);
      if (parts[0] > 1000) {
        [yyyy, mm, dd] = parts;
      } else {
        [dd, mm, yyyy] = parts;
      }
    } else {
      return dateStr;
    }
    
    const [HH, MM] = time.split(':').map(Number);
    const dt = new Date(yyyy, (mm || 1) - 1, dd || 1, HH || 0, MM || 0, 0, 0);
    
    if (isNaN(dt.getTime())) return dateStr;
    
    // Add 2 hours to convert GMT-5 to GMT-3
    dt.setHours(dt.getHours() + 2);
    
    const newDD = pad(dt.getDate());
    const newMM = pad(dt.getMonth() + 1);
    const newYYYY = dt.getFullYear();
    const newHH = pad(dt.getHours());
    const newMM_min = pad(dt.getMinutes());
    
    return `${newDD}-${newMM}-${newYYYY} ${newHH}:${newMM_min}`;
    
  } catch (e) {
    console.error('Error converting timezone:', dateStr, e);
    return dateStr;
  }
}

/**
 * Normalize datetime to GMT-3 based on source type
 * Manual events are already in GMT-3 and remain untouched
 * External sources (StreamTP, LA14HD) are converted from GMT-5 to GMT-3
 */
function normalizeToGMT3(dateStr, sourceType) {
  if (!dateStr || typeof dateStr !== 'string') return dateStr;
  
  try {
    switch(sourceType) {
      case 'manual':
        // Manual events already in correct timezone (GMT-3)
        return dateStr;
        
      case 'streamtp':
        // StreamTP provides only time (HH:mm) in GMT-5
        // Add current date and convert to GMT-3
        const today = new Date();
        const yyyy = today.getFullYear();
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const dd = String(today.getDate()).padStart(2, '0');
        const dateInGMT5 = `${yyyy}-${mm}-${dd} ${dateStr}`;
        return convertGMT5ToGMT3(dateInGMT5);
        
      case 'la14hd':
        // LA14HD provides full date+time in GMT-5
        // Convert directly to GMT-3
        return convertGMT5ToGMT3(dateStr);
        
      default:
        return dateStr;
    }
  } catch (error) {
    console.error(`Error normalizing date (${sourceType}):`, dateStr, error);
    return dateStr;
  }
}

// ==================== EVENT GROUPING AND DEDUPLICATION ====================

/**
 * Group duplicate events from different sources
 * Uses fuzzy matching to identify similar events based on:
 * - Team names (with abbreviation support)
 * - Start time (±30 minutes tolerance)
 * Priority order: manual > streamtp > la14hd
 */
function groupDuplicateEvents(events) {
  const grouped = {};
  
  // Sort events by priority before grouping
  const sortedEvents = events.sort((a, b) => {
    const priority = { 'manual': 3, 'streamtp': 2, 'la14hd': 1 };
    const priorityA = priority[a.sourceType] || 0;
    const priorityB = priority[b.sourceType] || 0;
    return priorityB - priorityA;
  });
  
  sortedEvents.forEach(event => {
    if (!event || (!event.teams && !event.evento)) return;
    
    let teamNames = [];
    let originalEventName = '';
    
    if (event.teams && Array.isArray(event.teams) && event.teams.length > 0) {
      teamNames = event.teams.map(t => t.name?.toLowerCase().trim() || '').filter(name => name);
      originalEventName = event.teams.map(t => t.name).join(' vs ');
    } else if (event.evento) {
      originalEventName = event.evento;
      const eventoStr = event.evento.toLowerCase();
      let cleanEventName = eventoStr;
      
      if (eventoStr.includes(':')) {
        cleanEventName = eventoStr.split(':').slice(1).join(':').trim();
      }
      
      if (cleanEventName.includes(' vs ')) {
        teamNames = cleanEventName.split(' vs ').map(name => name.trim());
      } else if (cleanEventName.includes(' - ')) {
        teamNames = cleanEventName.split(' - ').map(name => name.trim());
      } else {
        teamNames = [cleanEventName.trim()];
      }
    } else {
      return;
    }
    
    if (teamNames.length === 0) return;
    
    const normalizedTeamNames = teamNames.map(name => {
      return name
        .replace(/nhl:\s*/gi, '')
        .replace(/en español\s*/gi, '')
        .replace(/\s*-\s*.+$/, '')
        .trim();
    });
    
    const sortedTeamNames = normalizedTeamNames.sort().join('|');
    let matchedKey = sortedTeamNames;
    let fuzzyMatched = false;
    
    // Search for similar existing events
    for (const existingKey of Object.keys(grouped)) {
      const existingEvent = grouped[existingKey];
      
      // Check if same time (±30 minutes tolerance)
      const timeDiff = Math.abs(
        parseStartTime(existingEvent.start_time) - parseStartTime(event.start_time)
      ) / (1000 * 60);
      
      if (timeDiff > 30) continue;
      
      // Check if similar teams
      const existingTeams = existingKey.split('|').map(t => normalizeTeamName(t));
      const newTeams = normalizedTeamNames.map(t => normalizeTeamName(t));
      
      const similarity = calculateTeamSimilarity(existingTeams, newTeams);
      
      if (similarity > 0.7) {
        matchedKey = existingKey;
        fuzzyMatched = true;
        break;
      }
    }
    
    if (!grouped[matchedKey]) {
      const logoData = logoManager.detectLogo(event);
      
      grouped[matchedKey] = {
        id: `group-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        start_time: event.start_time,
        teams: normalizedTeamNames.map(name => ({ name: name.toUpperCase() })),
        evento: originalEventName,
        description: event.description || '',
        competition_name: event.competition_name || '',
        competencia: event.competencia || '',
        status: event.status || { name: '' },
        slug: event.slug || `group-${matchedKey}`,
        sources: [event],
        allNetworks: [...(event.tv_networks || [])],
        allCanales: [...(event.canales || [])],
        isLive: isEventLive(event.start_time),
        isUpcoming: isEventUpcoming(event.start_time),
        competitionLogo: logoData?.logo || null,
        competitionName: logoData?.competition || null,
        sourceType: event.sourceType
      };
    } else {
      const existingEvent = grouped[matchedKey];
      existingEvent.sources.push(event);
      
      // Priority: If new event has higher priority, update data
      const priority = { 'manual': 3, 'streamtp': 2, 'la14hd': 1 };
      const newPriority = priority[event.sourceType] || 0;
      const currentPriority = priority[existingEvent.sourceType] || 0;
      
      if (newPriority > currentPriority) {
        existingEvent.evento = originalEventName;
        existingEvent.start_time = event.start_time;
        existingEvent.sourceType = event.sourceType;
        existingEvent.description = event.description || existingEvent.description;
        existingEvent.competition_name = event.competition_name || existingEvent.competition_name;
      }
      
      // Update logo if not exists
      if (!existingEvent.competitionLogo) {
        const logoData = logoManager.detectLogo(event);
        if (logoData) {
          existingEvent.competitionLogo = logoData.logo;
          existingEvent.competitionName = logoData.competition;
        }
      }
      
      // Add channels without duplicates
      const newNetworks = event.tv_networks || [];
      newNetworks.forEach(network => {
        const exists = existingEvent.allNetworks.some(existing => 
          existing.name === network.name && existing.iframe === network.iframe && existing.link === network.link
        );
        if (!exists) existingEvent.allNetworks.push(network);
      });
      
      const newCanales = event.canales || [];
      newCanales.forEach(canal => {
        const exists = existingEvent.allCanales.some(existing => 
          existing.name === canal.name && existing.iframe === canal.iframe && existing.link === canal.link
        );
        if (!exists) existingEvent.allCanales.push(canal);
      });
      
      existingEvent.isLive = existingEvent.isLive || isEventLive(event.start_time);
      existingEvent.isUpcoming = existingEvent.isUpcoming || isEventUpcoming(event.start_time);
    }
  });
  
  return Object.values(grouped);
}

// ==================== DATA FETCHING ====================

async function fetchJSON(url, options = {}) {
  try {
    const response = await fetch(url, { cache: 'no-store', mode: 'cors', ...options });
    if (!response.ok) throw new Error('Failed to load ' + url);
    return await response.json();
  } catch (error) {
    console.error(`Error fetching ${url}:`, error);
    return null;
  }
}

// ==================== EVENT ADAPTERS ====================

/**
 * Adapt manual events (highest priority source)
 * Events are already in correct timezone (GMT-3)
 */
async function adaptManualEvents(events) {
  return events.map(ev => {
    let teams = [];
    if (ev.evento.includes(' vs ')) {
      teams = ev.evento.split(' vs ').map(name => ({ name: name.trim() }));
    } else {
      teams = [{ name: ev.evento.trim() }];
    }
    
    let canales = [];
    if (Array.isArray(ev.canales)) {
      ev.canales.forEach(canal => {
        if (canal.options && Array.isArray(canal.options)) {
          canal.options.forEach((opt, idx) => {
            canales.push({
              name: `${canal.name} - ${opt.name}`,
              iframe: opt.iframe,
              logo: canal.logo
            });
          });
        }
        else if (typeof canal === 'string') {
          canales.push({ name: canal });
        }
        else if (canal.name) {
          canales.push({ name: canal.name, iframe: canal.iframe, logo: canal.logo });
        }
      });
    } else if (ev.canal) {
      canales = [ev.canal];
    }
    
    let renamedCanales = renameDuplicateOptions(canales);
    
    // Manual events already in GMT-3, no conversion needed
    const normalizedDate = normalizeToGMT3(ev.fecha, 'manual');
    
    return {
      id: `manual-${ev.id}`,
      start_time: normalizedDate,
      teams: teams,
      evento: ev.evento,
      description: ev.descripcion || '',
      competition_name: ev.competencia || '',
      competencia: ev.competencia || '',
      tv_networks: renamedCanales,
      canales: renamedCanales,
      status: { name: ev.estado || '' },
      slug: `manual-${ev.id}`,
      sourceType: 'manual'
    };
  });
}

/**
 * Adapt StreamTP events
 * Convert times from GMT-5 to GMT-3
 */
async function adaptStreamTPEvents(events) {
  if (!Array.isArray(events)) return [];
  
  return events.map(ev => {
    // Convert GMT-5 to GMT-3
    const normalizedDate = normalizeToGMT3(ev.time, 'streamtp');
    
    let teams = [];
    if (ev.title && ev.title.includes(' vs ')) {
      teams = ev.title.split(' vs ').map(name => ({ name: name.trim() }));
    } else if (ev.title) {
      teams = [{ name: ev.title.trim() }];
    }
    
    const canales = [];
    if (ev.link) {
      const channelName = channelExtractor.extract(ev.link, ev.category || 'Canal');
      canales.push({ name: channelName, link: btoa(ev.link || '') });
    }
    
    return {
      id: `streamtp-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      start_time: normalizedDate,
      teams: teams,
      evento: ev.title || '',
      description: ev.status || '',
      competition_name: ev.category || '',
      competencia: ev.category || '',
      tv_networks: canales,
      canales: canales,
      status: { name: ev.status || '' },
      slug: `streamtp-${Date.now()}`,
      sourceType: 'streamtp'
    };
  });
}

/**
 * Adapt LA14HD events
 * Convert times from GMT-5 to GMT-3
 */
async function adaptLA14HDEvents(events) {
  if (!Array.isArray(events)) return [];
  
  return events.map(ev => {
    let teams = [];
    if (ev.title && ev.title.includes(' vs ')) {
      teams = ev.title.split(' vs ').map(name => ({ name: name.trim() }));
    } else if (ev.title) {
      teams = [{ name: ev.title.trim() }];
    }
    
    const canales = [];
    if (ev.link) {
      const channelName = channelExtractor.extract(ev.link, ev.category || 'Canal');
      canales.push({ name: channelName, link: btoa(ev.link || '') });
    }
    
    // Build full date
    let formattedDate = '';
    if (ev.date && ev.time) {
      formattedDate = `${ev.date} ${ev.time}`;
    } else if (ev.time) {
      const today = new Date();
      const yyyy = today.getFullYear();
      const mm = String(today.getMonth() + 1).padStart(2, '0');
      const dd = String(today.getDate()).padStart(2, '0');
      formattedDate = `${yyyy}-${mm}-${dd} ${ev.time}`;
    }
    
    // Convert GMT-5 to GMT-3
    const normalizedDate = normalizeToGMT3(formattedDate, 'la14hd');
    
    return {
      id: `la14hd-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      start_time: normalizedDate,
      teams: teams,
      evento: ev.title || '',
      description: ev.status || '',
      competition_name: ev.category || '',
      competencia: ev.category || '',
      tv_networks: canales,
      canales: canales,
      status: { name: ev.status || '' },
      slug: `la14hd-${Date.now()}`,
      sourceType: 'la14hd'
    };
  });
}

/**
 * Adapt El Canal Deportivo events
 */
async function adaptElCanalEvents(events) {
  if (!Array.isArray(events)) return [];
  
  return events.map(ev => {
    let rawTitle = ev.title || ev.name || ev.evento || ev.event || '';
    let eventName = rawTitle;
    let teams = [];
    let competition = '';

    competition = ev.competition || ev.competencia || ev.league || ev.tournament || '';

    if (rawTitle.includes(' vs ')) {
      teams = rawTitle.split(' vs ').map(name => ({ 
        name: name.trim().replace(/^\d+\s*-\s*/, '')
      }));
    } else if (rawTitle.includes(' - ')) {
      const parts = rawTitle.split(' - ');
      if (parts.length >= 2) {
        if (!competition) {
          competition = parts[parts.length - 1].trim();
        }
        const eventPart = parts.slice(0, -1).join(' - ');
        if (eventPart.includes(' vs ')) {
          teams = eventPart.split(' vs ').map(name => ({ name: name.trim() }));
        } else {
          teams = [{ name: eventPart.trim() }];
        }
      } else {
        teams = [{ name: rawTitle.trim() }];
      }
    } else {
      teams = [{ name: rawTitle.trim() }];
    }

    const canales = [];
    const possibleStreams = ev.streams || ev.links || ev.channels || ev.canales || [];
    
    if (Array.isArray(possibleStreams)) {
      possibleStreams.forEach((stream, index) => {
        const streamUrl = stream.url || stream.link || stream.iframe || stream.src;
        if (streamUrl) {
          const channelName = channelExtractor.extract(streamUrl, stream.name || `Canal ${index + 1}`);
          canales.push({ 
            name: channelName, 
            iframe: streamUrl,
            link: btoa(streamUrl)
          });
        }
      });
    }

    let formattedDate = '';
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = pad(today.getMonth() + 1);
    const dd = pad(today.getDate());
    
    if (ev.time && ev.date) {
      formattedDate = `${ev.date} ${ev.time}`;
    } else if (ev.datetime) {
      formattedDate = ev.datetime;
    } else if (ev.start_time) {
      formattedDate = ev.start_time;
    } else if (ev.time) {
      formattedDate = `${yyyy}-${mm}-${dd} ${ev.time}`;
    } else {
      formattedDate = `${yyyy}-${mm}-${dd} 00:00`;
    }

    return {
      id: `elcanal-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      start_time: formattedDate,
      teams: teams,
      evento: eventName,
      description: ev.description || '',
      competition_name: competition,
      competencia: competition,
      tv_networks: canales,
      canales: canales,
      status: { name: ev.status || 'Programado' },
      slug: `elcanal-${Date.now()}`,
      sourceType: 'elcanal'
    };
  }).filter(event => event.evento);
}

// ==================== AGENDA MANAGER ====================

class AgendaManager {
  constructor() {
    this.allEvents = [];
    this.filteredEvents = [];
    this.currentFilter = 'all';
    this.searchQuery = '';
  }
  
  async loadAllEvents() {
    await logoManager.loadLogos();
    
    const cached = CacheManager.get(CONFIG.cache.key);
    if (cached) {
      this.allEvents = cached;
      return this.allEvents;
    }
    
    try {
      const [manualEventsRaw, streamTPEventsRaw, la14HDEventsRaw, elCanalEventsRaw] = await Promise.all([
        fetchJSON(CONFIG.urls.events).catch(() => []),
        fetchJSON(CONFIG.urls.streamTP).catch(() => ({ Events: [] })),
        fetchJSON(CONFIG.urls.la14HD).catch(() => ({ Events: [] })),
        fetchJSON(CONFIG.urls.elcanal).catch(() => [])
      ]);
      
      const manualEvents = await adaptManualEvents(Array.isArray(manualEventsRaw) ? manualEventsRaw : []);
      
      let streamTPArray = [];
      if (streamTPEventsRaw && typeof streamTPEventsRaw === 'object') {
        streamTPArray = Array.isArray(streamTPEventsRaw) ? streamTPEventsRaw : streamTPEventsRaw.Events || [];
      }
      
      let la14HDArray = [];
      if (la14HDEventsRaw && typeof la14HDEventsRaw === 'object') {
        la14HDArray = Array.isArray(la14HDEventsRaw) ? la14HDEventsRaw : la14HDEventsRaw.Events || [];
      }
      
      let elCanalArray = [];
      if (Array.isArray(elCanalEventsRaw)) {
        elCanalArray = elCanalEventsRaw;
      }
      
      const streamTPEvents = await adaptStreamTPEvents(streamTPArray);
      const la14HDEvents = await adaptLA14HDEvents(la14HDArray);
      const elCanalEvents = await adaptElCanalEvents(elCanalArray);
      
      const rawEvents = [...manualEvents, ...streamTPEvents, ...la14HDEvents, ...elCanalEvents];
      
      this.allEvents = groupDuplicateEvents(rawEvents);
      
      this.sortEvents();
      
      CacheManager.set(CONFIG.cache.key, this.allEvents);
      
      console.log(`Events loaded: ${rawEvents.length} raw → ${this.allEvents.length} grouped`);
      console.log(`Sources: ${manualEvents.length} manual, ${streamTPEvents.length} streamTP, ${la14HDEvents.length} la14HD, ${elCanalEvents.length} elcanal`);
      return this.allEvents;
    } catch (error) {
      console.error('Error loading events:', error);
      return [];
    }
  }
  
  sortEvents() {
    this.allEvents.sort((a, b) => {
      const timeA = parseStartTime(a.start_time);
      const timeB = parseStartTime(b.start_time);
      return timeA - timeB;
    });
  }
  
  filterEvents(filter = 'all') {
    this.currentFilter = filter;
    
    let filtered = this.allEvents;
    
    switch(filter) {
      case 'live':
        filtered = filtered.filter(event => event.isLive);
        break;
      case 'upcoming':
        filtered = filtered.filter(event => event.isUpcoming);
        break;
      case 'football':
        filtered = filtered.filter(event => 
          event.evento.toLowerCase().includes('vs') ||
          event.competition_name?.toLowerCase().includes('liga') ||
          event.competition_name?.toLowerCase().includes('champions') ||
          event.competition_name?.toLowerCase().includes('copa') ||
          event.competition_name?.toLowerCase().includes('premier') ||
          event.competition_name?.toLowerCase().includes('futbol') ||
          event.evento.toLowerCase().includes('fútbol')
        );
        break;
      case 'f1':
        filtered = filtered.filter(event => 
          event.evento.toLowerCase().includes('f1') ||
          event.evento.toLowerCase().includes('formula') ||
          event.competition_name?.toLowerCase().includes('f1') ||
          event.competition_name?.toLowerCase().includes('formula')
        );
        break;
    }
    
    if (this.searchQuery) {
      filtered = this.searchEvents(filtered, this.searchQuery);
    }
    
    this.filteredEvents = filtered;
    return this.filteredEvents;
  }
  
  searchEvents(events, query) {
    const searchTerm = query.toLowerCase().trim();
    if (!searchTerm) return events;
    
    return events.filter(event => 
      event.evento.toLowerCase().includes(searchTerm) ||
      event.competition_name?.toLowerCase().includes(searchTerm) ||
      event.description?.toLowerCase().includes(searchTerm) ||
      event.teams?.some(team => team.name.toLowerCase().includes(searchTerm))
    );
  }
  
  setSearchQuery(query) {
    this.searchQuery = query;
    return this.filterEvents(this.currentFilter);
  }
}

// ==================== UI RENDERER ====================

class AgendaRenderer {
  constructor(agendaManager) {
    this.agendaManager = agendaManager;
    this.container = document.getElementById('agenda');
    if (this.container) {
      this.initControls();
    }
  }
  
  initControls() {
    if (!this.container) return;
    
    const controlsContainer = this.createControlsContainer();
    const agendaContainer = this.container.parentElement;
    
    if (agendaContainer && !agendaContainer.querySelector('.agenda-controls')) {
      agendaContainer.insertBefore(controlsContainer, this.container);
    }
    
    const banner = document.getElementById('dayBanner');
    if (banner) {
      banner.textContent = formatDayBanner();
    }
  }
  
  createControlsContainer() {
    const container = createEl('div', 'agenda-controls');
    
    const searchContainer = createEl('div', 'search-container');
    const searchInput = createEl('input');
    searchInput.type = 'text';
    searchInput.id = 'searchEvents';
    searchInput.placeholder = 'Buscar evento, liga o deporte...';
    searchContainer.appendChild(searchInput);
    
    const filtersContainer = createEl('div', 'agenda-filters');
    CONFIG.filters.forEach(filter => {
      const btn = createEl('button', 'filter-btn', filter.label);
      btn.dataset.filter = filter.id;
      if (filter.id === 'all') btn.classList.add('active');
      filtersContainer.appendChild(btn);
    });
    
    container.appendChild(searchContainer);
    container.appendChild(filtersContainer);
    
    this.bindControlEvents(searchInput, filtersContainer);
    
    return container;
  }
  
  bindControlEvents(searchInput, filtersContainer) {
    let searchTimeout;
    searchInput.addEventListener('input', (e) => {
      clearTimeout(searchTimeout);
      searchTimeout = setTimeout(() => {
        const filtered = this.agendaManager.setSearchQuery(e.target.value);
        this.renderEvents(filtered);
      }, 300);
    });
    
    filtersContainer.addEventListener('click', (e) => {
      const filterBtn = e.target.closest('.filter-btn');
      if (filterBtn) {
        filtersContainer.querySelectorAll('.filter-btn').forEach(btn => {
          btn.classList.remove('active');
        });
        filterBtn.classList.add('active');
        
        const filtered = this.agendaManager.filterEvents(filterBtn.dataset.filter);
        this.renderEvents(filtered);
      }
    });
  }
  
  buildMatchCard(groupedEvent) {
    const card = createEl('div', 'match-card');
    const header = createEl('div', 'match-header');
    
    const timeCol = createEl('div', 'time-col');
    const timeBadge = createEl('div', 'time-badge', formatTime(groupedEvent.start_time));
    timeCol.appendChild(timeBadge);
    
    const main = createEl('div', 'match-main');
    
    if (groupedEvent.competitionLogo) {
      const logoImg = createEl('img', 'competition-logo');
      logoImg.src = groupedEvent.competitionLogo;
      logoImg.alt = groupedEvent.competitionName || 'Liga';
      logoImg.loading = 'eager';
      logoImg.onerror = function() {
        this.style.display = 'none';
      };
      main.appendChild(logoImg);
    }
    
    const textContainer = createEl('div', 'match-text');
    
    let eventName = '';
    const allEventNames = groupedEvent.sources.map(source => source.evento).filter(name => name);
    if (allEventNames.length > 0) {
      eventName = allEventNames.reduce((longest, current) => 
        current.length > longest.length ? current : longest, allEventNames[0]
      );
    } else if (groupedEvent.teams && groupedEvent.teams.length > 0) {
      eventName = groupedEvent.teams.map(t => t.name).join(' vs ');
    } else {
      eventName = 'Evento Deportivo';
    }
    
    const title = createEl('div', 'teams', eventName);
    textContainer.appendChild(title);
    
    if (groupedEvent.competitionName) {
      const compName = createEl('div', 'competition-name', groupedEvent.competitionName);
      textContainer.appendChild(compName);
    }
    
    main.appendChild(textContainer);
    
    const expandIcon = createEl('div', 'expand-icon');
    expandIcon.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>';
    
    header.appendChild(timeCol);
    header.appendChild(main);
    header.appendChild(expandIcon);
    card.appendChild(header);
    
    const dropdown = createEl('div', 'dropdown hidden');
    const menu = createEl('ul', 'channel-menu');
    
    const options = groupedEvent.allNetworks.length > 0 ? groupedEvent.allNetworks : groupedEvent.allCanales;
    
    if (options.length === 0) {
      const li = createEl('li', 'channel-item');
      li.textContent = 'Sin opciones disponibles';
      li.style.opacity = '0.6';
      menu.appendChild(li);
    } else {
      const renamedOptions = renameDuplicateOptions(options);
      
      renamedOptions.forEach((option, index) => {
        const li = createEl('li', 'channel-item');
        const left = createEl('div', 'left');
        const play = createEl('span', 'play-icon');
        
        let optionName = option.name || `Opción ${index + 1}`;
        
        if (optionName.toLowerCase().includes('youtube')) {
          optionName = `📺 ${optionName}`;
        }
        
        const name = createEl('span', '', optionName);
        left.appendChild(play);
        left.appendChild(name);
        li.appendChild(left);
        
        li.addEventListener('click', (event) => {
          event.stopPropagation();
          
          const virtualChannel = {
            name: eventName,
            logo: './assets/logo.png',
            options: renamedOptions.map((opt, idx) => {
              let url = '';
              if (opt.iframe) {
                url = opt.iframe;
              } else if (opt.link) {
                try {
                  url = atob(opt.link);
                } catch (e) {
                  url = '';
                }
              }
              return {
                name: opt.name || `Opción ${idx + 1}`,
                iframe: url
              };
            })
          };
          
          const encodedChannel = encodeBase64Compact(JSON.stringify(virtualChannel));
          const transmisionUrl = buildShortURL({
            virtualChannel: encodedChannel,
            opt: index
          });
          
          window.top.location.href = transmisionUrl;
        });
        
        menu.appendChild(li);
      });
    }
    
    dropdown.appendChild(menu);
    card.appendChild(dropdown);
    
    header.addEventListener('click', (e) => {
      if (e.target.closest('.channel-item')) return;
      
      dropdown.classList.toggle('hidden');
      card.classList.toggle('expanded');
      expandIcon.classList.toggle('expanded');
    });
    
    return card;
  }
  
  renderEvents(events = []) {
    if (!this.container) return;
    
    this.container.innerHTML = '';
    
    if (events.length === 0) {
      this.showEmptyState();
      return;
    }
    
    const listEl = createEl('div', 'matches');
    
    events.forEach(event => {
      const card = this.buildMatchCard(event);
      listEl.appendChild(card);
    });
    
    this.container.appendChild(listEl);
    
    this.updateCounter(events.length);
  }
  
  showEmptyState() {
    if (!this.container) return;
    
    this.container.innerHTML = `
      <div class="no-events">
        <div class="empty-icon">📅</div>
        <h3>No hay eventos</h3>
        <p>No se encontraron eventos con los filtros actuales.</p>
      </div>
    `;
    this.updateCounter(0);
  }
  
  updateCounter(count) {
    if (!this.container) return;
    
    let counter = document.querySelector('.events-counter');
    if (!counter) {
      counter = createEl('div', 'events-counter');
      const parent = this.container.parentElement;
      if (parent) {
        parent.appendChild(counter);
      }
    }
    
    const filter = this.agendaManager.currentFilter;
    const filterText = CONFIG.filters.find(f => f.id === filter)?.label || '';
    counter.textContent = `${count} evento${count !== 1 ? 's' : ''} ${filter !== 'all' ? `en ${filterText.toLowerCase()}` : ''}`;
  }
  
  showLoading() {
    if (!this.container) return;
    
    this.container.innerHTML = `
      <div class="loading-state">
        <div class="spinner"></div>
        <p>Cargando eventos deportivos...</p>
      </div>
    `;
  }
  
  showError(error) {
    if (!this.container) return;
    
    this.container.innerHTML = `
      <div class="error-state">
        <div class="error-icon">⚠️</div>
        <h3>Error al cargar la agenda</h3>
        <p>${error.message || 'Intenta recargar la página'}</p>
        <button class="retry-btn">Reintentar</button>
      </div>
    `;
    
    const retryBtn = this.container.querySelector('.retry-btn');
    if (retryBtn) {
      retryBtn.addEventListener('click', () => window.location.reload());
    }
  }
}

// ==================== URL BUILDING ====================

function buildShortURL(params) {
  const urlParams = new URLSearchParams();
  const paramMap = {
    'virtualChannel': 'vc',
    'event': 'e',
    'match': 'm',
    'channel': 'c',
    'opt': 'o'
  };
  
  Object.entries(params).forEach(([key, value]) => {
    if (value !== null && value !== undefined) {
      const shortKey = paramMap[key] || key;
      urlParams.set(shortKey, String(value));
    }
  });
  
  return `transmision.html?${urlParams.toString()}`;
}

function encodeBase64Compact(str) {
  return btoa(str)
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}

// ==================== CHANNEL RENDERING ====================

async function renderChannels(channelData) {
  const channelsGrid = document.getElementById('channelsGrid');
  if (!channelsGrid || !channelData || !Array.isArray(channelData.channels)) return;
  channelsGrid.innerHTML = '';
  channelData.channels.forEach(ch => {
    const card = createEl('div', 'channel-card');
    const img = createEl('img');
    img.src = ch.logo;
    img.alt = ch.name;
    const name = createEl('div', 'name', ch.name);
    card.appendChild(img);
    card.appendChild(name);
    card.addEventListener('click', () => {
      const url = buildShortURL({ channel: ch.name });
      window.top.location.href = url;
    });
    if (ch.show == true) {
      channelsGrid.appendChild(card);
    }
  });
}

// ==================== INITIALIZATION ====================

async function init() {
  const agendaContainer = document.getElementById('agenda');
  const channelsGrid = document.getElementById('channelsGrid');
  
  if (agendaContainer && !channelsGrid) {
    await initAgendaOnly();
  } else if (agendaContainer && channelsGrid) {
    await initFullPage();
  } else if (!agendaContainer && channelsGrid) {
    await initChannelsOnly();
  }
}

async function initAgendaOnly() {
  const agendaContainer = document.getElementById('agenda');
  
  if (!agendaContainer) return;
  
  agendaContainer.innerHTML = `<div class="loading-state"><div class="spinner"></div><p>Cargando eventos deportivos...</p></div>`;
  
  try {
    const agendaManager = new AgendaManager();
    const events = await agendaManager.loadAllEvents();
    const renderer = new AgendaRenderer(agendaManager);
    const filtered = agendaManager.filterEvents('all');
    renderer.renderEvents(filtered);
  } catch (err) {
    console.error('Error loading agenda:', err);
    if (agendaContainer) {
      agendaContainer.innerHTML = `<div class="error-state"><div class="error-icon">⚠️</div><h3>Error al cargar la agenda</h3><button class="retry-btn">Reintentar</button></div>`;
      
      const retryBtn = agendaContainer.querySelector('.retry-btn');
      if (retryBtn) {
        retryBtn.addEventListener('click', () => window.location.reload());
      }
    }
  }
}

async function initFullPage() {
  const agendaContainer = document.getElementById('agenda');
  const channelsGrid = document.getElementById('channelsGrid');
  
  if (agendaContainer) {
    agendaContainer.innerHTML = '<div class="loading-state">Cargando agenda...</div>';
    try {
      const agendaManager = new AgendaManager();
      const events = await agendaManager.loadAllEvents();
      const renderer = new AgendaRenderer(agendaManager);
      const filtered = agendaManager.filterEvents('all');
      renderer.renderEvents(filtered);
    } catch (err) {
      console.error('Error loading agenda:', err);
      agendaContainer.innerHTML = `<div class="error-state"><div class="error-icon">⚠️</div><h3>Error al cargar la agenda</h3><button class="retry-btn">Reintentar</button></div>`;
      
      const retryBtn = agendaContainer.querySelector('.retry-btn');
      if (retryBtn) {
        retryBtn.addEventListener('click', () => window.location.reload());
      }
    }
  }
  
  if (channelsGrid) {
    channelsGrid.innerHTML = '<div class="loading">Cargando canales...</div>';
    try {
      const channelData = await fetchJSON(CONFIG.urls.channels).catch(() => ({ channels: [] }));
      await renderChannels(channelData);
    } catch (err) {
      console.error('Error loading channels:', err);
      channelsGrid.innerHTML = '<div class="error">Error al cargar canales</div>';
    }
  }
}

async function initChannelsOnly() {
  const channelsGrid = document.getElementById('channelsGrid');
  
  if (channelsGrid) {
    channelsGrid.innerHTML = '<div class="loading">Cargando canales...</div>';
    try {
      const channelData = await fetchJSON(CONFIG.urls.channels).catch(() => ({ channels: [] }));
      await renderChannels(channelData);
    } catch (err) {
      console.error('Error loading channels:', err);
      channelsGrid.innerHTML = '<div class="error">Error al cargar canales</div>';
    }
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// ==================== PUBLIC API ====================

window.AngulismoAgenda = {
  reload: () => {
    CacheManager.clear(CONFIG.cache.key);
    window.location.reload();
  },
  clearCache: () => {
    CacheManager.clear(CONFIG.cache.key);
    console.log('Cache cleared');
  },
  logos: {
    refresh: async () => {
      logoManager.logosDB = null;
      await logoManager.loadLogos();
      console.log('Logos refreshed');
    },
    list: () => {
      if (!logoManager.logosDB) {
        console.log('Logos not loaded');
        return;
      }
      console.table(
        Object.entries(logoManager.logosDB).map(([key, data]) => ({
          Competition: key,
          Name: data.name,
          Keywords: data.keywords.join(', ')
        }))
      );
    },
    search: (query) => {
      const mockEvent = { evento: query };
      const result = logoManager.detectLogo(mockEvent);
      console.log(result || 'Not found');
    }
  }
};