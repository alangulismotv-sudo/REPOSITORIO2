// ========================================
// SISTEMA DE BADGES - VERSIÓN FINAL FUNCIONAL
// Espera correctamente a que carguen los mensajes
// ========================================

console.log('🔍 Sistema de badges de usuarios cargando...');

// ========================================
// FUNCIÓN PRINCIPAL: AGREGAR BADGE
// ========================================

function agregarBadgeUsuario(mensajeElement, usuarioId = null) {
    const nombreElement = mensajeElement.querySelector('.mensaje-nombre');
    if (!nombreElement) return;
    
    // Si ya tiene badge de usuario, no agregar otro
    if (nombreElement.nextElementSibling?.classList.contains('badge-verificado-icon') ||
        nombreElement.nextElementSibling?.classList.contains('badge-anonimo-icon')) {
        return;
    }
    
    // Determinar si es registrado
    let esRegistrado = false;
    
    if (usuarioId !== null && usuarioId !== undefined && usuarioId !== '' && usuarioId !== 'null') {
        esRegistrado = true;
    }
    
    if (!esRegistrado) {
        const datasetId = mensajeElement.dataset.usuarioId;
        if (datasetId && datasetId !== 'null' && datasetId !== 'undefined' && datasetId !== '') {
            esRegistrado = true;
        }
    }
    
    // Crear badge e insertarlo DESPUÉS del nombre (sin moverlo)
    const badge = document.createElement('span');
    
    if (esRegistrado) {
        badge.className = 'badge-verificado-icon';
        badge.setAttribute('data-tooltip', 'Usuario verificado');
        badge.setAttribute('title', 'Usuario registrado');
        nombreElement.classList.add('registrado');
    } else {
        badge.className = 'badge-anonimo-icon';
        badge.setAttribute('data-tooltip', 'Usuario invitado');
        badge.setAttribute('title', 'Usuario invitado');
        nombreElement.classList.add('anonimo');
    }
    
    // Insertar el badge DESPUÉS del nombre (sin tocarlo)
    nombreElement.parentNode.insertBefore(badge, nombreElement.nextSibling);
}

// ========================================
// SINCRONIZACIÓN Y APLICACIÓN
// ========================================

async function sincronizarYAplicarBadges() {
    console.log('🔄 Sincronizando badges...');
    
    try {
        // Obtener mensajes del API
        const response = await fetch(`${CONFIG.API_URL}/mensajes?limit=50`);
        const data = await response.json();
        
        if (!data.success || !data.mensajes) {
            console.error('❌ Error obteniendo mensajes del API');
            return;
        }
        
        console.log(`📥 Recibidos ${data.mensajes.length} mensajes del API`);
        
        // Crear mapa de ID → usuario_id
        const mapaUsuarios = {};
        data.mensajes.forEach(msg => {
            mapaUsuarios[String(msg.id)] = msg.usuario_id;
        });
        
        console.log(`📋 Mapa creado con ${Object.keys(mapaUsuarios).length} entradas`);
        
        // Esperar un momento a que el DOM esté listo
        await new Promise(resolve => setTimeout(resolve, 100));
        
        // Procesar elementos HTML
        const mensajesHTML = document.querySelectorAll('.mensaje-item');
        let registrados = 0;
        let anonimos = 0;
        
        console.log(`🔍 Procesando ${mensajesHTML.length} elementos HTML`);
        
        mensajesHTML.forEach((msgDiv, index) => {
            const mensajeId = msgDiv.dataset.mensajeId || msgDiv.getAttribute('data-mensaje-id');
            
            if (!mensajeId || mensajeId === 'undefined') {
                console.warn(`⚠️ Elemento ${index + 1} sin data-mensaje-id`);
                return;
            }
            
            const mensajeIdStr = String(mensajeId);
            const usuarioId = mapaUsuarios[mensajeIdStr];
            
            // Agregar data-usuario-id al elemento
            if (usuarioId !== null && usuarioId !== undefined && usuarioId !== '') {
                msgDiv.dataset.usuarioId = usuarioId;
                registrados++;
            } else {
                anonimos++;
            }
            
            // Agregar badge
            agregarBadgeUsuario(msgDiv, usuarioId);
        });
        
        console.log(`✅ Badges aplicados: ${registrados} registrados, ${anonimos} anónimos`);
        
    } catch (error) {
        console.error('❌ Error sincronizando badges:', error);
    }
}

// ========================================
// LIMPIAR Y REPROCESAR
// ========================================

function limpiarBadges() {
    document.querySelectorAll('.badge-anonimo-icon, .badge-verificado-icon').forEach(b => b.remove());
    document.querySelectorAll('.mensaje-nombre-container').forEach(c => {
        const nombre = c.querySelector('.mensaje-nombre');
        if (nombre && c.parentNode) {
            c.parentNode.insertBefore(nombre, c);
            c.remove();
        }
    });
}

async function reprocesarBadges() {
    console.log('🔄 Reprocesando badges...');
    limpiarBadges();
    await sincronizarYAplicarBadges();
}

// ========================================
// INTEGRACIÓN CON cargarMensajes
// ========================================

if (typeof cargarMensajes === 'function' && !window.cargarMensajesOriginalBadges) {
    window.cargarMensajesOriginalBadges = cargarMensajes;
    
    window.cargarMensajes = async function() {
        // Llamar a la función original
        await window.cargarMensajesOriginalBadges();
        
        // Esperar a que el DOM se actualice
        await new Promise(resolve => setTimeout(resolve, 200));
        
        // Sincronizar y aplicar badges
        await sincronizarYAplicarBadges();
    };
    
    console.log('✅ cargarMensajes interceptado para badges automáticos');
}

// ========================================
// MUTATION OBSERVER (Detectar mensajes nuevos)
// ========================================

const observerBadges = new MutationObserver((mutations) => {
    mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
            if (node.nodeType === 1 && node.classList?.contains('mensaje-item')) {
                // Nuevo mensaje detectado
                setTimeout(async () => {
                    const mensajeId = node.dataset.mensajeId || node.getAttribute('data-mensaje-id');
                    
                    if (mensajeId && mensajeId !== 'undefined') {
                        // Obtener usuario_id desde el API
                        try {
                            const response = await fetch(`${CONFIG.API_URL}/mensajes?limit=50`);
                            const data = await response.json();
                            const mensaje = data.mensajes?.find(m => String(m.id) === String(mensajeId));
                            
                            if (mensaje && mensaje.usuario_id) {
                                node.dataset.usuarioId = mensaje.usuario_id;
                                agregarBadgeUsuario(node, mensaje.usuario_id);
                            } else {
                                agregarBadgeUsuario(node, null);
                            }
                        } catch (error) {
                            console.error('Error obteniendo usuario_id:', error);
                            agregarBadgeUsuario(node, null);
                        }
                    } else {
                        agregarBadgeUsuario(node, null);
                    }
                }, 100);
            }
        });
    });
});

// ========================================
// COMANDOS GLOBALES
// ========================================

window.agregarBadgeUsuario = agregarBadgeUsuario;
window.sincronizarYAplicarBadges = sincronizarYAplicarBadges;
window.reprocesarBadges = reprocesarBadges;

// ========================================
// AUTO-INICIALIZACIÓN
// ========================================

async function inicializarBadges() {
    console.log('🚀 Inicializando sistema de badges...');
    
    // Esperar a que el DOM esté listo
    if (document.readyState === 'loading') {
        await new Promise(resolve => {
            document.addEventListener('DOMContentLoaded', resolve);
        });
    }
    
    // Esperar a que carguen los mensajes (más tiempo)
    
    // Sincronizar y aplicar badges
    await sincronizarYAplicarBadges();
    
    // Iniciar observer
    setTimeout(() => {
        const listaMensajes = document.getElementById('listaMensajes');
        if (listaMensajes) {
            observerBadges.observe(listaMensajes, {
                childList: true,
                subtree: true
            });
            console.log('✅ Observer activo para mensajes nuevos');
        }
    }, 500);
    
    console.log('✅ Sistema de badges inicializado');
    console.log('💡 Comandos: reprocesarBadges() si no funciona');
}

// Ejecutar inicialización
inicializarBadges();

console.log('✅ Sistema de badges cargado');