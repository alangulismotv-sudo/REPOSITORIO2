// Limpia la consola cada 2 segundos
function limpiarConsolaConstante() {
    setInterval(() => {
        console.clear();
    }, 200); // 2000ms = 2 segundos
}

// Iniciar la limpieza automática
limpiarConsolaConstante();