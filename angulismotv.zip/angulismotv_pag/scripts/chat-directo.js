// ========================================
// SISTEMA DE CHAT DIRECTO V7 - OPTIMIZADO
// ✅ Renderizado incremental
// ✅ Caché inteligente
// ✅ Polling solo cuando sea necesario
// ========================================

(function() {
    'use strict';
    
    console.log('💬 Sistema de chat directo v7 OPTIMIZADO inicializado');
    
    const CONFIG = {
        API_URL: 'https://foro.angulismotv.workers.dev',
        POLL_INTERVAL_ACTIVE: 15000,      // 15s cuando chat abierto
        POLL_INTERVAL_BACKGROUND: 60000,   // 60s cuando chat cerrado
        MAX_MESSAGE_LENGTH: 2000,
        TYPING_TIMEOUT: 2000,
        ONLINE_CHECK_INTERVAL: 45000,      // Reducido de 30s
        HEARTBEAT_INTERVAL: 30000,         // Reducido de 15s
        MESSAGE_BATCH_SIZE: 50,            // Para virtualización
        CACHE_TTL: 30000                   // 30s de caché
    };
    
    let state = {
        isOpen: false,
        currentConversation: null,
        conversaciones: [],
        conversationsMap: new Map(),       // Para búsqueda O(1)
        messages: {},
        messagesMap: new Map(),            // Cache de mensajes por ID
        unreadCount: 0,
        pollInterval: null,
        currentUser: null,
        isAuthenticated: false,
        searchMode: 'conversations',
        searchResults: [],
        typingUsers: new Set(),
        onlineUsers: new Set(),
        heartbeatInterval: null,
        onlineCheckInterval: null,
        lastActivity: Date.now(),
        isLoadingMessages: false,
        isMobile: false,
        lastPollTime: 0,
        lastMessagesHash: {},              // Para detectar cambios
        isDirty: false,                    // Flag para saber si hay que re-renderizar
        visibilityState: 'visible'
    };
    
    let elements = {};
    let searchTimeout = null;
    let typingTimeout = null;
    let renderQueue = [];
    let isRendering = false;
    
    // ========================================
    // DETECTAR MÓVIL
    // ========================================
    
    function checkIfMobile() {
        const wasMobile = state.isMobile;
        state.isMobile = window.innerWidth <= 768;
        return wasMobile !== state.isMobile;
    }
    
    // ========================================
    // VERIFICAR AUTH - CON CACHÉ
    // ========================================
    
    let authCache = { valid: false, timestamp: 0 };
    
    async function verificarAutenticacion() {
        // Usar caché si es reciente (5s)
        if (authCache.valid && (Date.now() - authCache.timestamp < 5000)) {
            state.isAuthenticated = authCache.valid;
            return authCache.valid;
        }
        
        const token = localStorage.getItem('authToken');
        
        if (!token) {
            state.isAuthenticated = false;
            authCache = { valid: false, timestamp: Date.now() };
            return false;
        }
        
        try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            
            if (payload.exp < Date.now() / 1000) {
                localStorage.removeItem('authToken');
                state.isAuthenticated = false;
                authCache = { valid: false, timestamp: Date.now() };
                return false;
            }
            
            if (!state.currentUser || state.currentUser.id !== payload.userId) {
                state.currentUser = {
                    id: payload.userId,
                    username: payload.username,
                    avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(payload.username)}&background=random`
                };
                console.log('✅ Usuario autenticado:', state.currentUser.username);
            }
            
            state.isAuthenticated = true;
            authCache = { valid: true, timestamp: Date.now() };
            return true;
            
        } catch (error) {
            console.error('Error verificando auth:', error);
            state.isAuthenticated = false;
            authCache = { valid: false, timestamp: Date.now() };
            return false;
        }
    }
    
    // ========================================
    // SISTEMA DE HEARTBEAT - OPTIMIZADO
    // ========================================
    
    function startHeartbeat() {
        if (state.heartbeatInterval) return;
        
        sendHeartbeat();
        state.heartbeatInterval = setInterval(() => {
            // Solo enviar si el usuario está activo
            if (Date.now() - state.lastActivity < 120000) { // 2 min
                sendHeartbeat();
            }
        }, CONFIG.HEARTBEAT_INTERVAL);
    }
    
    function stopHeartbeat() {
        if (state.heartbeatInterval) {
            clearInterval(state.heartbeatInterval);
            state.heartbeatInterval = null;
        }
    }
    
    async function sendHeartbeat() {
        if (!state.isAuthenticated) return;
        
        try {
            const token = localStorage.getItem('authToken');
            fetch(`${CONFIG.API_URL}/user/heartbeat`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ timestamp: Date.now() }),
                keepalive: true // Optimización
            }).catch(() => {}); // Silenciar errores
            
            state.lastActivity = Date.now();
        } catch (error) {
            // Silenciar
        }
    }
    
    async function getOnlineUsers() {
        if (!state.isAuthenticated) return;
        
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${CONFIG.API_URL}/users/online`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            
            if (!response.ok) return;
            
            const data = await response.json();
            const newOnlineUsers = new Set(data.online_users || []);
            
            // Solo actualizar UI si cambió algo
            if (!setsAreEqual(state.onlineUsers, newOnlineUsers)) {
                state.onlineUsers = newOnlineUsers;
                updateOnlineStatusIncremental();
            }
            
        } catch (error) {
            // Silenciar
        }
    }
    
    function setsAreEqual(set1, set2) {
        if (set1.size !== set2.size) return false;
        for (let item of set1) {
            if (!set2.has(item)) return false;
        }
        return true;
    }
    
    function updateOnlineStatusIncremental() {
        // Solo actualizar los elementos que cambiaron
        document.querySelectorAll('.dm-conversation').forEach(el => {
            const userId = parseInt(el.getAttribute('data-user-id'));
            const isOnline = state.onlineUsers.has(userId);
            const wasOnline = el.classList.contains('online');
            
            if (isOnline !== wasOnline) {
                el.classList.toggle('online', isOnline);
            }
        });
        
        // Actualizar estado en header si es la conversación actual
        if (state.currentConversation && elements.onlineStatus) {
            const isOnline = state.onlineUsers.has(state.currentConversation.otro_usuario_id);
            const currentText = elements.onlineStatus.textContent;
            const newText = isOnline ? 'En línea' : 'Desconectado';
            
            if (currentText !== newText) {
                elements.onlineStatus.textContent = newText;
                elements.onlineStatus.className = `dm-chat-user-status ${isOnline ? 'online' : 'offline'}`;
            }
        }
    }
    
    // ========================================
    // CREAR UI
    // ========================================
    
    function createUI() {
        const html = `
            <button class="dm-floating-button" id="dmFloatingBtn" style="display: none;">
                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
                <span class="dm-notification-badge" id="dmNotificationBadge" style="display: none;">0</span>
            </button>
            
            <div class="dm-modal" id="dmModal">
                <div class="dm-container">
                    <div class="dm-sidebar" id="dmSidebar">
                        <div class="dm-sidebar-header">
                            <h2 class="dm-sidebar-title">
                                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                                </svg>
                                Mensajes
                            </h2>
                            <button class="dm-close-btn" id="dmCloseBtn">
                                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </div>
                        
                        <div class="dm-search">
                            <svg class="dm-search-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                            </svg>
                            <input 
                                type="text" 
                                class="dm-search-input" 
                                placeholder="Buscar usuarios o conversaciones..."
                                id="dmSearchInput"
                            >
                        </div>
                        
                        <div class="dm-conversations-list" id="dmConversationsList">
                            <div class="dm-empty-state" style="padding: 40px 20px;">
                                <div class="dm-empty-icon">
                                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" style="width: 64px; height: 64px; opacity: 0.3;">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                                    </svg>
                                </div>
                                <div class="dm-empty-text">No hay conversaciones</div>
                                <div class="dm-empty-subtitle">Busca usuarios para iniciar un chat</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="dm-chat" id="dmChat">
                        <div class="dm-chat-header" id="dmChatHeader" style="display: none;">
                            <button class="dm-back-btn" id="dmBackBtn">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="15 18 9 12 15 6"></polyline>
                                </svg>
                            </button>
                            
                            <div class="dm-chat-user">
                                <img src="" alt="" class="dm-chat-user-avatar" id="dmChatAvatar">
                                <div class="dm-chat-user-info">
                                    <div class="dm-chat-user-name" id="dmChatName"></div>
                                    <div id="dmChatStatusContainer">
                                        <span class="dm-typing-indicator" id="dmTypingIndicator" style="display: none;">
                                            escribiendo
                                            <span class="dm-typing-dot">.</span>
                                            <span class="dm-typing-dot">.</span>
                                            <span class="dm-typing-dot">.</span>
                                        </span>
                                        <span class="dm-chat-user-status" id="dmOnlineStatus">Desconectado</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="dm-messages" id="dmMessages">
                            <div class="dm-empty-state">
                                <div class="dm-empty-icon">
                                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" style="width: 64px; height: 64px; opacity: 0.3;">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                                    </svg>
                                </div>
                                <div class="dm-empty-title">Sin conversación seleccionada</div>
                                <div class="dm-empty-text">Selecciona una conversación para comenzar</div>
                            </div>
                        </div>
                        
                        <div class="dm-input" id="dmInput" style="display: none;">
                            <div class="dm-input-wrapper">
                                <button class="dm-input-btn dm-attach-btn" id="dmAttachBtn" title="Adjuntar imagen">
                                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                    </svg>
                                </button>
                                <input type="file" id="dmFileInput" accept="image/*" style="display: none;">
                                <textarea 
                                    class="dm-input-field" 
                                    placeholder="Escribe un mensaje..."
                                    id="dmInputField"
                                    rows="1"
                                    maxlength="2000"
                                ></textarea>
                                <div class="dm-char-counter" id="dmCharCounter" style="display: none;">0/2000</div>
                            </div>
                            <div class="dm-input-actions">
                                <button class="dm-send-btn dm-input-btn" id="dmSendBtn">
                                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div id="dmToastContainer" style="position: fixed; top: 20px; right: 20px; z-index: 10001;"></div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', html);
        
        elements = {
            floatingBtn: document.getElementById('dmFloatingBtn'),
            notificationBadge: document.getElementById('dmNotificationBadge'),
            modal: document.getElementById('dmModal'),
            closeBtn: document.getElementById('dmCloseBtn'),
            backBtn: document.getElementById('dmBackBtn'),
            sidebar: document.getElementById('dmSidebar'),
            conversationsList: document.getElementById('dmConversationsList'),
            searchInput: document.getElementById('dmSearchInput'),
            chat: document.getElementById('dmChat'),
            chatHeader: document.getElementById('dmChatHeader'),
            chatAvatar: document.getElementById('dmChatAvatar'),
            chatName: document.getElementById('dmChatName'),
            onlineStatus: document.getElementById('dmOnlineStatus'),
            typingIndicator: document.getElementById('dmTypingIndicator'),
            messages: document.getElementById('dmMessages'),
            input: document.getElementById('dmInput'),
            inputField: document.getElementById('dmInputField'),
            sendBtn: document.getElementById('dmSendBtn'),
            attachBtn: document.getElementById('dmAttachBtn'),
            fileInput: document.getElementById('dmFileInput'),
            charCounter: document.getElementById('dmCharCounter'),
            toastContainer: document.getElementById('dmToastContainer')
        };
        
        console.log('✅ UI del chat creada');
    }
    
    // ========================================
    // TOASTS
    // ========================================
    
    function showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `dm-toast dm-toast-${type}`;
        
        const icons = {
            success: `<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" style="width: 20px; height: 20px;">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
            </svg>`,
            error: `<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" style="width: 20px; height: 20px;">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
            </svg>`,
            warning: `<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" style="width: 20px; height: 20px;">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>`,
            info: `<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" style="width: 20px; height: 20px;">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>`
        };
        
        toast.innerHTML = `
            <span class="dm-toast-icon">${icons[type] || icons.info}</span>
            <span class="dm-toast-message">${message}</span>
        `;
        
        elements.toastContainer.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(400px)';
            setTimeout(() => toast.remove(), 200);
        }, 2500);
    }
    
    // ========================================
    // NAVEGACIÓN MÓVIL
    // ========================================
    
    function showSidebar() {
        if (state.isMobile) {
            elements.sidebar.classList.add('mobile-visible');
            elements.chat.classList.remove('mobile-visible');
        }
    }
    
    function showChat() {
        if (state.isMobile) {
            elements.sidebar.classList.remove('mobile-visible');
            elements.chat.classList.add('mobile-visible');
        }
    }
    
    // ========================================
    // EVENT LISTENERS
    // ========================================
    
    function attachEventListeners() {
        elements.floatingBtn.addEventListener('click', toggleModal);
        elements.closeBtn.addEventListener('click', closeModal);
        elements.modal.addEventListener('click', (e) => {
            if (e.target === elements.modal) closeModal();
        });
        
        elements.backBtn.addEventListener('click', () => {
            showSidebar();
        });
        
        elements.searchInput.addEventListener('input', debounce(handleSearch, 300));
        elements.sendBtn.addEventListener('click', sendMessage);
        elements.attachBtn.addEventListener('click', () => elements.fileInput.click());
        elements.fileInput.addEventListener('change', handleFileSelect);
        
        elements.inputField.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });
        
        elements.inputField.addEventListener('input', throttle(() => {
            autoResizeTextarea();
            updateCharCounter();
            handleTypingIndicator();
        }, 200)); // Reducido de 100ms a 200ms
        
        window.addEventListener('resize', throttle(() => {
            if (checkIfMobile()) {
                // Solo re-renderizar si cambió móvil/desktop
                state.isDirty = true;
            }
        }, 250));
        
        // Track de actividad - throttled
        const trackActivity = throttle(() => {
            state.lastActivity = Date.now();
        }, 1000); // Solo una vez por segundo
        
        document.addEventListener('mousemove', trackActivity, { passive: true });
        document.addEventListener('keypress', trackActivity, { passive: true });
        document.addEventListener('click', trackActivity, { passive: true });
        
        // Page Visibility API para pausar polling cuando tab inactivo
        document.addEventListener('visibilitychange', () => {
            state.visibilityState = document.hidden ? 'hidden' : 'visible';
            
            if (state.isOpen) {
                stopPolling();
                if (!document.hidden) {
                    startPolling();
                    // Refrescar inmediatamente al volver
                    loadConversaciones();
                }
            }
        });
        
        if ('Notification' in window && Notification.permission === 'default') {
            elements.floatingBtn.addEventListener('click', () => {
                Notification.requestPermission();
            }, { once: true });
        }
    }
    
    // ========================================
    // UTILIDADES
    // ========================================
    
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), wait);
        };
    }
    
    function throttle(func, limit) {
        let inThrottle;
        return function(...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }
    
    // ========================================
    // MANEJO DE IMÁGENES
    // ========================================
    
    async function handleFileSelect(e) {
        const file = e.target.files[0];
        if (!file) return;
        
        if (!file.type.startsWith('image/')) {
            showToast('Solo se permiten imágenes', 'error');
            return;
        }
        
        if (file.size > 5 * 1024 * 1024) {
            showToast('La imagen no puede superar 5MB', 'error');
            return;
        }
        
        try {
            showToast('Cargando imagen...', 'info');
            
            const base64 = await fileToBase64(file);
            
            if (!base64 || !base64.startsWith('data:image/')) {
                throw new Error('Formato de imagen inválido');
            }
            
            elements.inputField.dataset.attachment = base64;
            
            const preview = document.createElement('div');
            preview.className = 'dm-image-preview';
            preview.innerHTML = `
                <img src="${base64}" alt="Preview">
                <button class="dm-remove-image" onclick="window.ChatDirecto.removeAttachment()">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            `;
            
            const oldPreview = elements.inputField.parentElement.querySelector('.dm-image-preview');
            if (oldPreview) oldPreview.remove();
            
            elements.inputField.parentElement.insertBefore(preview, elements.inputField);
            
            showToast('Imagen cargada correctamente', 'success');
        } catch (error) {
            console.error('Error al cargar imagen:', error);
            showToast('Error al cargar la imagen', 'error');
        }
        
        elements.fileInput.value = '';
    }
    
    function removeAttachment() {
        delete elements.inputField.dataset.attachment;
        const preview = elements.inputField.parentElement.querySelector('.dm-image-preview');
        if (preview) preview.remove();
        showToast('Imagen eliminada', 'info');
    }
    
    function fileToBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
                const result = reader.result;
                if (result && typeof result === 'string' && result.startsWith('data:image/')) {
                    resolve(result);
                } else {
                    reject(new Error('Formato inválido'));
                }
            };
            reader.onerror = () => reject(new Error('Error leyendo archivo'));
            reader.readAsDataURL(file);
        });
    }
    
    // ========================================
    // TYPING INDICATOR - OPTIMIZADO
    // ========================================
    
    let lastTypingSignal = 0;
    
    function handleTypingIndicator() {
        if (!state.currentConversation) return;
        
        const now = Date.now();
        // Solo enviar señal si han pasado 2s desde la última
        if (now - lastTypingSignal < 2000) return;
        
        lastTypingSignal = now;
        
        clearTimeout(typingTimeout);
        sendTypingSignal(true);
        
        typingTimeout = setTimeout(() => {
            sendTypingSignal(false);
        }, CONFIG.TYPING_TIMEOUT);
    }
    
    async function sendTypingSignal(isTyping) {
        if (!state.currentConversation?.conversacion_id) return;
        
        try {
            const token = localStorage.getItem('authToken');
            fetch(`${CONFIG.API_URL}/dm/typing`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    conversacion_id: state.currentConversation.conversacion_id,
                    is_typing: isTyping
                }),
                keepalive: true
            }).catch(() => {});
        } catch (error) {
            // Silenciar
        }
    }
    
    let typingCheckCache = { conversacionId: null, isTyping: false, timestamp: 0 };
    
    async function checkTypingStatus() {
        if (!state.currentConversation?.conversacion_id) return;
        
        // Usar caché de 2s
        if (typingCheckCache.conversacionId === state.currentConversation.conversacion_id &&
            Date.now() - typingCheckCache.timestamp < 2000) {
            return;
        }
        
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(
                `${CONFIG.API_URL}/dm/typing/${state.currentConversation.conversacion_id}`,
                { headers: { 'Authorization': `Bearer ${token}` } }
            );
            
            if (!response.ok) return;
            
            const data = await response.json();
            
            typingCheckCache = {
                conversacionId: state.currentConversation.conversacion_id,
                isTyping: data.is_typing,
                timestamp: Date.now()
            };
            
            // Solo actualizar si cambió
            const shouldShow = data.is_typing;
            const isShowing = elements.typingIndicator.style.display !== 'none';
            
            if (shouldShow !== isShowing) {
                elements.typingIndicator.style.display = shouldShow ? 'inline-flex' : 'none';
                elements.onlineStatus.style.display = shouldShow ? 'none' : 'inline';
            }
        } catch (error) {
            // Silenciar
        }
    }
    
    // ========================================
    // CONTADOR DE CARACTERES
    // ========================================
    
    function updateCharCounter() {
        const length = elements.inputField.value.length;
        elements.charCounter.textContent = `${length}/2000`;
        
        elements.charCounter.style.display = length > 0 ? 'block' : 'none';
        
        if (length > 1800) {
            elements.charCounter.style.color = '#ef4444';
        } else if (length > 1500) {
            elements.charCounter.style.color = '#f59e0b';
        } else {
            elements.charCounter.style.color = '#6b7280';
        }
    }
    
    // ========================================
    // BÚSQUEDA - OPTIMIZADA
    // ========================================
    
    function handleSearch(e) {
        const query = e.target.value.trim();
        
        if (query.length === 0) {
            state.searchMode = 'conversations';
            renderConversaciones();
            return;
        }
        
        if (query.length < 2) {
            elements.conversationsList.innerHTML = `
                <div class="dm-empty-state" style="padding: 40px 20px;">
                    <div class="dm-empty-icon">
                        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" style="width: 64px; height: 64px; opacity: 0.3;">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                        </svg>
                    </div>
                    <div class="dm-empty-text">Escribe al menos 2 caracteres</div>
                </div>
            `;
            return;
        }
        
        performSearch(query);
    }
    
    async function performSearch(query) {
        try {
            const queryLower = query.toLowerCase();
            
            // Búsqueda local primero (instantánea)
            const filteredConversations = state.conversaciones.filter(conv =>
                conv.otro_usuario_nombre.toLowerCase().includes(queryLower)
            );
            
            // Renderizar resultados locales inmediatamente
            if (filteredConversations.length > 0) {
                renderSearchResults(filteredConversations, []);
            }
            
            // Luego búsqueda remota
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${CONFIG.API_URL}/users/search?q=${encodeURIComponent(query)}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            
            if (!response.ok) throw new Error('Error buscando usuarios');
            
            const data = await response.json();
            state.searchResults = data.users || [];
            
            renderSearchResults(filteredConversations, state.searchResults);
            
        } catch (error) {
            console.error('Error en búsqueda:', error);
        }
    }
    
    function renderSearchResults(conversations, users) {
        const fragment = document.createDocumentFragment();
        
        if (conversations.length > 0) {
            const header = document.createElement('div');
            header.style.cssText = 'padding: 12px 16px; font-size: 12px; font-weight: 600; color: #6b7280; text-transform: uppercase;';
            header.textContent = 'Conversaciones';
            fragment.appendChild(header);
            
            conversations.forEach(conv => {
                const hasUnread = conv.mensajes_no_leidos > 0;
                const isOnline = state.onlineUsers.has(conv.otro_usuario_id);
                const el = createConversationElement(conv, hasUnread, isOnline, 'conversation');
                fragment.appendChild(el);
            });
        }
        
        if (users.length > 0) {
            const header = document.createElement('div');
            header.style.cssText = `padding: 12px 16px; font-size: 12px; font-weight: 600; color: #6b7280; text-transform: uppercase; margin-top: ${conversations.length > 0 ? '8px' : '0'};`;
            header.textContent = 'Usuarios';
            fragment.appendChild(header);
            
            users.forEach(user => {
                const isOnline = state.onlineUsers.has(user.id);
                const el = createUserSearchElement(user, isOnline);
                fragment.appendChild(el);
            });
        }
        
        if (conversations.length === 0 && users.length === 0) {
            const empty = document.createElement('div');
            empty.className = 'dm-empty-state';
            empty.style.padding = '40px 20px';
            empty.innerHTML = `
                <div class="dm-empty-icon">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" style="width: 64px; height: 64px; opacity: 0.3;">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </div>
                <div class="dm-empty-text">No se encontraron resultados</div>
            `;
            fragment.appendChild(empty);
        }
        
        elements.conversationsList.innerHTML = '';
        elements.conversationsList.appendChild(fragment);
    }
    
    function createUserSearchElement(user, isOnline) {
        const el = document.createElement('div');
        el.className = `dm-conversation ${isOnline ? 'online' : ''}`;
        el.setAttribute('data-type', 'new-user');
        el.setAttribute('data-user-id', user.id);
        el.setAttribute('data-user-name', user.username);
        el.setAttribute('data-user-avatar', user.avatar_url || getDefaultAvatar(user.username));
        
        el.innerHTML = `
            <img src="${user.avatar_url || getDefaultAvatar(user.username)}" 
                 alt="${user.username}" 
                 class="dm-conversation-avatar"
                 onerror="this.src='${getDefaultAvatar(user.username)}'">
            <div class="dm-conversation-info">
                <div class="dm-conversation-name">${user.username}</div>
                <div class="dm-conversation-preview">Iniciar conversación</div>
            </div>
            <div class="dm-conversation-meta">
                <svg style="width: 20px; height: 20px; color: #3b82f6;" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                </svg>
            </div>
        `;
        
        el.addEventListener('click', () => {
            openConversation({
                conversacion_id: null,
                otro_usuario_id: user.id,
                otro_usuario_nombre: user.username,
                otro_usuario_avatar: user.avatar_url || getDefaultAvatar(user.username)
            });
            elements.searchInput.value = '';
        }, { passive: true });
        
        return el;
    }
    
    // ========================================
    // UI BASED ON AUTH
    // ========================================
    
    function updateUIBasedOnAuth() {
        if (state.isAuthenticated) {
            elements.floatingBtn.style.display = 'flex';
            startHeartbeat();
            startOnlineCheck();
        } else {
            elements.floatingBtn.style.display = 'none';
            stopHeartbeat();
            stopOnlineCheck();
        }
    }
    
    function startOnlineCheck() {
        if (state.onlineCheckInterval) return;
        
        getOnlineUsers();
        state.onlineCheckInterval = setInterval(getOnlineUsers, CONFIG.ONLINE_CHECK_INTERVAL);
    }
    
    function stopOnlineCheck() {
        if (state.onlineCheckInterval) {
            clearInterval(state.onlineCheckInterval);
            state.onlineCheckInterval = null;
        }
    }
    
    // ========================================
    // TOGGLE MODAL
    // ========================================
    
    function toggleModal() {
        if (!state.isAuthenticated) {
            showToast('Debes iniciar sesión para usar el chat', 'warning');
            return;
        }
        
        state.isOpen = !state.isOpen;
        
        if (state.isOpen) {
            checkIfMobile();
            elements.modal.classList.add('active');
            document.body.classList.add('dm-modal-open');
            
            if (state.isMobile) {
                showSidebar();
            }
            
            loadConversaciones();
            startPolling();
        } else {
            closeModal();
        }
    }
    
    function closeModal() {
        state.isOpen = false;
        elements.modal.classList.remove('active');
        document.body.classList.remove('dm-modal-open');
        document.body.style.overflow = '';
        
        elements.sidebar.classList.remove('mobile-visible');
        elements.chat.classList.remove('mobile-visible');
        
        stopPolling();
    }
    
    // ========================================
    // CARGAR CONVERSACIONES - OPTIMIZADO
    // ========================================
    
    let conversationsCache = { data: [], timestamp: 0 };
    
    async function loadConversaciones(force = false) {
        // Usar caché si es reciente (15s) y no es forzado
        if (!force && conversationsCache.data.length > 0 && 
            Date.now() - conversationsCache.timestamp < 15000) {
            state.conversaciones = conversationsCache.data;
            return;
        }
        
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${CONFIG.API_URL}/dm/conversations`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            
            if (!response.ok) throw new Error('Error cargando conversaciones');
            
            const data = await response.json();
            const newConversations = data.conversaciones || [];
            
            // Solo actualizar si cambió algo
            const hasChanges = JSON.stringify(newConversations) !== JSON.stringify(state.conversaciones);
            
            if (hasChanges) {
                const previousUnread = state.unreadCount;
                state.conversaciones = newConversations;
                
                // Actualizar map para búsqueda rápida
                state.conversationsMap.clear();
                newConversations.forEach(conv => {
                    state.conversationsMap.set(conv.conversacion_id, conv);
                });
                
                conversationsCache = {
                    data: newConversations,
                    timestamp: Date.now()
                };
                
                if (elements.searchInput.value.trim().length === 0) {
                    renderConversaciones();
                }
                
                updateUnreadCount();
                
                if (state.unreadCount > previousUnread && !state.isOpen) {
                    showDesktopNotification();
                }
            }
            
        } catch (error) {
            console.error('Error cargando conversaciones:', error);
        }
    }
    
    // ========================================
    // NOTIFICACIONES
    // ========================================
    
    function showDesktopNotification() {
        if ('Notification' in window && Notification.permission === 'granted') {
            const newMessages = state.unreadCount - (state.previousUnreadCount || 0);
            if (newMessages > 0) {
                new Notification('Nuevo mensaje directo', {
                    body: `Tienes ${state.unreadCount} mensaje${state.unreadCount > 1 ? 's' : ''} sin leer`,
                    icon: '/assets/icon.png',
                    tag: 'dm-notification',
                    requireInteraction: false
                });
            }
        }
        state.previousUnreadCount = state.unreadCount;
    }
    
    // ========================================
    // RENDER CONVERSACIONES - INCREMENTAL
    // ========================================
    
    function renderConversaciones() {
        if (state.conversaciones.length === 0) {
            elements.conversationsList.innerHTML = `
                <div class="dm-empty-state" style="padding: 40px 20px;">
                    <div class="dm-empty-icon">
                        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" style="width: 64px; height: 64px; opacity: 0.3;">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                        </svg>
                    </div>
                    <div class="dm-empty-text">No hay conversaciones</div>
                    <div class="dm-empty-subtitle">Busca usuarios para iniciar un chat</div>
                </div>
            `;
            return;
        }
        
        // Renderizado incremental - reusar elementos existentes
        const existingElements = Array.from(elements.conversationsList.querySelectorAll('.dm-conversation'));
        const fragment = document.createDocumentFragment();
        
        state.conversaciones.forEach((conv, index) => {
            let el = existingElements[index];
            const hasUnread = conv.mensajes_no_leidos > 0;
            const isOnline = state.onlineUsers.has(conv.otro_usuario_id);
            
            if (el && el.getAttribute('data-conversation-id') === conv.conversacion_id) {
                // Actualizar elemento existente solo si cambió
                updateConversationElement(el, conv, hasUnread, isOnline);
                fragment.appendChild(el);
            } else {
                // Crear nuevo elemento
                el = createConversationElement(conv, hasUnread, isOnline);
                fragment.appendChild(el);
            }
        });
        
        // Solo reemplazar si hay cambios reales
        elements.conversationsList.innerHTML = '';
        elements.conversationsList.appendChild(fragment);
    }
    
    function createConversationElement(conv, hasUnread, isOnline, type = 'conversation') {
        const el = document.createElement('div');
        const isActive = state.currentConversation?.conversacion_id === conv.conversacion_id;
        
        el.className = `dm-conversation ${isActive ? 'active' : ''} ${hasUnread ? 'unread' : ''} ${isOnline ? 'online' : ''}`;
        el.setAttribute('data-type', type);
        el.setAttribute('data-conversation-id', conv.conversacion_id);
        el.setAttribute('data-user-id', conv.otro_usuario_id);
        el.setAttribute('data-user-name', conv.otro_usuario_nombre);
        el.setAttribute('data-user-avatar', conv.otro_usuario_avatar || getDefaultAvatar(conv.otro_usuario_nombre));
        
        el.innerHTML = `
            <img src="${conv.otro_usuario_avatar || getDefaultAvatar(conv.otro_usuario_nombre)}" 
                 alt="${conv.otro_usuario_nombre}" 
                 class="dm-conversation-avatar"
                 onerror="this.src='${getDefaultAvatar(conv.otro_usuario_nombre)}'">
            <div class="dm-conversation-info">
                <div class="dm-conversation-name">${conv.otro_usuario_nombre}</div>
                <div class="dm-conversation-preview">${conv.ultimo_mensaje || 'Sin mensajes'}</div>
            </div>
            <div class="dm-conversation-meta">
                <div class="dm-conversation-time">${formatearFecha(conv.ultimo_mensaje_fecha)}</div>
                ${hasUnread ? `<div class="dm-conversation-unread">${conv.mensajes_no_leidos}</div>` : ''}
            </div>
        `;
        
        el.addEventListener('click', () => {
            openConversation({
                conversacion_id: conv.conversacion_id,
                otro_usuario_id: conv.otro_usuario_id,
                otro_usuario_nombre: conv.otro_usuario_nombre,
                otro_usuario_avatar: conv.otro_usuario_avatar
            });
        }, { passive: true });
        
        return el;
    }
    
    function updateConversationElement(el, conv, hasUnread, isOnline) {
        // Solo actualizar clases si cambiaron
        const isActive = state.currentConversation?.conversacion_id === conv.conversacion_id;
        
        el.classList.toggle('active', isActive);
        el.classList.toggle('unread', hasUnread);
        el.classList.toggle('online', isOnline);
        
        // Actualizar preview si cambió
        const previewEl = el.querySelector('.dm-conversation-preview');
        const newPreview = conv.ultimo_mensaje || 'Sin mensajes';
        if (previewEl && previewEl.textContent !== newPreview) {
            previewEl.textContent = newPreview;
        }
        
        // Actualizar tiempo si cambió
        const timeEl = el.querySelector('.dm-conversation-time');
        const newTime = formatearFecha(conv.ultimo_mensaje_fecha);
        if (timeEl && timeEl.textContent !== newTime) {
            timeEl.textContent = newTime;
        }
        
        // Actualizar badge de no leídos
        const metaEl = el.querySelector('.dm-conversation-meta');
        const unreadEl = metaEl.querySelector('.dm-conversation-unread');
        
        if (hasUnread && !unreadEl) {
            const badge = document.createElement('div');
            badge.className = 'dm-conversation-unread';
            badge.textContent = conv.mensajes_no_leidos;
            metaEl.appendChild(badge);
        } else if (!hasUnread && unreadEl) {
            unreadEl.remove();
        } else if (unreadEl && unreadEl.textContent !== String(conv.mensajes_no_leidos)) {
            unreadEl.textContent = conv.mensajes_no_leidos;
        }
    }
    
    // ========================================
    // ABRIR CONVERSACIÓN
    // ========================================
    
    async function openConversation(conversation) {
        if (state.isLoadingMessages) return;
        
        if (state.isMobile) {
            showChat();
        }
        
        state.currentConversation = conversation;
        elements.chatHeader.style.display = 'flex';
        elements.input.style.display = 'flex';
        
        const avatarUrl = conversation.otro_usuario_avatar || getDefaultAvatar(conversation.otro_usuario_nombre);
        elements.chatAvatar.src = avatarUrl;
        elements.chatAvatar.onerror = () => {
            elements.chatAvatar.src = getDefaultAvatar(conversation.otro_usuario_nombre);
        };
        
        elements.chatName.textContent = conversation.otro_usuario_nombre;
        
        const isOnline = state.onlineUsers.has(conversation.otro_usuario_id);
        elements.onlineStatus.textContent = isOnline ? 'En línea' : 'Desconectado';
        elements.onlineStatus.className = `dm-chat-user-status ${isOnline ? 'online' : 'offline'}`;
        
        if (conversation.conversacion_id) {
            await loadMessages(conversation.conversacion_id);
            await markAsRead(conversation.conversacion_id);
        } else {
            elements.messages.innerHTML = `
                <div class="dm-empty-state">
                    <div class="dm-empty-icon">
                        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" style="width: 64px; height: 64px; opacity: 0.3;">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                        </svg>
                    </div>
                    <div class="dm-empty-title">Nueva conversación</div>
                    <div class="dm-empty-text">Envía el primer mensaje a ${conversation.otro_usuario_nombre}</div>
                </div>
            `;
        }
        
        if (elements.searchInput.value.trim().length === 0) {
            renderConversaciones();
        }
        
        elements.inputField.focus();
    }
    
    // ========================================
    // CARGAR MENSAJES - OPTIMIZADO
    // ========================================
    
    async function loadMessages(conversacionId) {
        if (state.isLoadingMessages) return;
        state.isLoadingMessages = true;
        
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${CONFIG.API_URL}/dm/messages/${conversacionId}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            
            if (!response.ok) throw new Error('Error cargando mensajes');
            
            const data = await response.json();
            const newMessages = data.mensajes || [];
            
            // Calcular hash para detectar cambios
            const newHash = JSON.stringify(newMessages.map(m => m.id + m.leido));
            const oldHash = state.lastMessagesHash[conversacionId];
            
            if (newHash !== oldHash) {
                state.messages[conversacionId] = newMessages;
                state.lastMessagesHash[conversacionId] = newHash;
                
                // Actualizar map
                newMessages.forEach(msg => {
                    state.messagesMap.set(msg.id, msg);
                });
                
                renderMessages(conversacionId);
            }
        } catch (error) {
            console.error('Error:', error);
            showToast('Error al cargar mensajes', 'error');
        } finally {
            state.isLoadingMessages = false;
        }
    }
    
    function renderMessages(conversacionId) {
        const mensajes = state.messages[conversacionId] || [];
        
        if (mensajes.length === 0) {
            elements.messages.innerHTML = `
                <div class="dm-empty-state">
                    <div class="dm-empty-icon">
                        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" style="width: 64px; height: 64px; opacity: 0.3;">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                        </svg>
                    </div>
                    <div class="dm-empty-title">Sin mensajes aún</div>
                    <div class="dm-empty-text">Envía el primer mensaje</div>
                </div>
            `;
            return;
        }
        
        const wasAtBottom = elements.messages.scrollHeight - elements.messages.scrollTop <= elements.messages.clientHeight + 100;
        
        // Renderizado en batch para mejor performance
        const fragment = document.createDocumentFragment();
        
        mensajes.forEach(msg => {
            const el = createMessageElement(msg);
            fragment.appendChild(el);
        });
        
        elements.messages.innerHTML = '';
        elements.messages.appendChild(fragment);
        
        if (wasAtBottom) {
            scrollToBottom();
        }
    }
    
    function createMessageElement(msg) {
        const div = document.createElement('div');
        const isOwn = msg.remitente_id === state.currentUser.id;
        
        div.className = `dm-message ${isOwn ? 'own' : ''}`;
        
        const avatar = isOwn 
            ? state.currentUser.avatar 
            : (state.currentConversation.otro_usuario_avatar || getDefaultAvatar(state.currentConversation.otro_usuario_nombre));
        
        let contenidoMensaje = escapeHtml(msg.mensaje);
        let imagenHTML = '';
        
        if (msg.attachment && msg.attachment.startsWith('data:image/')) {
            imagenHTML = `
                <div class="dm-message-image">
                    <img src="${msg.attachment}" alt="Imagen" loading="lazy" onclick="window.ChatDirecto.openImage('${msg.attachment}')">
                </div>
            `;
        }
        
        div.innerHTML = `
            <img src="${avatar}" 
                 alt="" 
                 class="dm-message-avatar"
                 loading="lazy"
                 onerror="this.src='${getDefaultAvatar(isOwn ? state.currentUser.username : state.currentConversation.otro_usuario_nombre)}'">
            <div class="dm-message-content">
                ${imagenHTML}
                ${contenidoMensaje ? `<div class="dm-message-bubble">${contenidoMensaje}</div>` : ''}
                <div class="dm-message-time">
                    ${formatearHora(msg.creado_en)}
                    ${isOwn && msg.leido ? '<span style="color: #3b82f6; margin-left: 4px;" title="Visto">✓✓</span>' : ''}
                </div>
            </div>
        `;
        
        return div;
    }
    
    function openImage(src) {
        const modal = document.createElement('div');
        modal.className = 'dm-image-modal';
        modal.innerHTML = `
            <div class="dm-image-modal-backdrop" onclick="this.parentElement.remove()">
                <img src="${src}" alt="Imagen completa" loading="lazy">
                <button class="dm-image-modal-close" onclick="event.stopPropagation(); this.parentElement.parentElement.remove()">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        `;
        document.body.appendChild(modal);
    }
    
    // ========================================
    // ENVIAR MENSAJE
    // ========================================
    
    async function sendMessage() {
        const text = elements.inputField.value.trim();
        const attachment = elements.inputField.dataset.attachment;
        
        if (!text && !attachment) return;
        
        if (!state.currentConversation) return;
        
        if (text && text.length > 500) {
            const confirmar = confirm(`Tu mensaje tiene ${text.length} caracteres. ¿Enviar de todos modos?`);
            if (!confirmar) return;
        }
        
        elements.inputField.disabled = true;
        elements.sendBtn.disabled = true;
        
        try {
            const token = localStorage.getItem('authToken');
            
            const payload = {
                destinatario_id: parseInt(state.currentConversation.otro_usuario_id, 10),
                mensaje: text || '[Imagen]'
            };
            
            if (attachment) {
                payload.attachment = attachment;
            }
            
            const response = await fetch(`${CONFIG.API_URL}/dm/send`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(payload)
            });
            
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Error enviando mensaje');
            }
            
            const result = await response.json();
            
            if (!state.currentConversation.conversacion_id && result.conversacion_id) {
                state.currentConversation.conversacion_id = result.conversacion_id;
            }
            
            elements.inputField.value = '';
            elements.inputField.style.height = 'auto';
            delete elements.inputField.dataset.attachment;
            updateCharCounter();
            
            const preview = elements.inputField.parentElement.querySelector('.dm-image-preview');
            if (preview) preview.remove();
            
            // Invalidar caché
            conversationsCache.timestamp = 0;
            
            await loadMessages(state.currentConversation.conversacion_id);
            loadConversaciones(true); // Forzar recarga
            
            showToast('Mensaje enviado', 'success');
            
        } catch (error) {
            console.error('Error:', error);
            showToast(error.message || 'Error al enviar mensaje', 'error');
        } finally {
            elements.inputField.disabled = false;
            elements.sendBtn.disabled = false;
            elements.inputField.focus();
        }
    }
    
    // ========================================
    // MARCAR COMO LEÍDO
    // ========================================
    
    async function markAsRead(conversacionId) {
        if (!conversacionId) return;
        
        try {
            const token = localStorage.getItem('authToken');
            fetch(`${CONFIG.API_URL}/dm/read/${conversacionId}`, {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${token}` },
                keepalive: true
            }).catch(() => {});
            
            // Actualizar localmente
            const conv = state.conversationsMap.get(conversacionId);
            if (conv) {
                conv.mensajes_no_leidos = 0;
                updateUnreadCount();
            }
        } catch (error) {
            // Silenciar
        }
    }
    
    // ========================================
    // ACTUALIZAR CONTADOR
    // ========================================
    
    async function updateUnreadCount() {
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${CONFIG.API_URL}/dm/unread-count`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            
            if (!response.ok) return;
            
            const data = await response.json();
            const newCount = data.unread_count || 0;
            
            // Solo actualizar si cambió
            if (state.unreadCount !== newCount) {
                state.unreadCount = newCount;
                
                if (state.unreadCount > 0) {
                    elements.notificationBadge.textContent = state.unreadCount > 99 ? '99+' : state.unreadCount;
                    elements.notificationBadge.style.display = 'flex';
                } else {
                    elements.notificationBadge.style.display = 'none';
                }
            }
        } catch (error) {
            // Silenciar
        }
    }
    
    // ========================================
    // POLLING - INTELIGENTE
    // ========================================
    
    function startPolling() {
        stopPolling();
        
        // Intervalo adaptativo según visibilidad
        const interval = document.hidden ? 
            CONFIG.POLL_INTERVAL_BACKGROUND : 
            CONFIG.POLL_INTERVAL_ACTIVE;
        
        state.pollInterval = setInterval(async () => {
            // Solo hacer polling si el tab está visible o hay conversación abierta
            if (!document.hidden || state.currentConversation) {
                await loadConversaciones();
                
                if (state.currentConversation?.conversacion_id) {
                    await loadMessages(state.currentConversation.conversacion_id);
                    checkTypingStatus();
                }
            }
        }, interval);
    }
    
    function stopPolling() {
        if (state.pollInterval) {
            clearInterval(state.pollInterval);
            state.pollInterval = null;
        }
    }
    
    // ========================================
    // UTILIDADES
    // ========================================
    
    function autoResizeTextarea() {
        elements.inputField.style.height = 'auto';
        const newHeight = Math.min(elements.inputField.scrollHeight, 150);
        elements.inputField.style.height = newHeight + 'px';
    }
    
    function scrollToBottom() {
        elements.messages.scrollTop = elements.messages.scrollHeight;
    }
    
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    function getDefaultAvatar(username) {
        return `https://ui-avatars.com/api/?name=${encodeURIComponent(username)}&background=random&color=fff&bold=true`;
    }
    
    function formatearFecha(fecha) {
        if (!fecha) return '';
        const date = new Date(fecha);
        const now = new Date();
        const diffMs = now - date;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);
        
        if (diffMins < 1) return 'Ahora';
        if (diffMins < 60) return `Hace ${diffMins}m`;
        if (diffHours < 24) return `Hace ${diffHours}h`;
        if (diffDays === 1) return 'Ayer';
        if (diffDays < 7) return `Hace ${diffDays}d`;
        
        return date.toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit' });
    }
    
    function formatearHora(fecha) {
        if (!fecha) return '';
        
        try {
            let date;
            
            if (typeof fecha === 'string') {
                let isoFecha = fecha.replace(' ', 'T');
                
                if (!isoFecha.endsWith('Z') && !isoFecha.includes('+') && !isoFecha.includes('-', 10)) {
                    isoFecha += 'Z';
                }
                
                date = new Date(isoFecha);
            } else {
                date = new Date(fecha);
            }
            
            if (isNaN(date.getTime())) {
                console.error('Fecha inválida:', fecha);
                return '';
            }
            
            const horas = date.getHours().toString().padStart(2, '0');
            const minutos = date.getMinutes().toString().padStart(2, '0');
            
            return `${horas}:${minutos}`;
            
        } catch (error) {
            console.error('Error formateando hora:', error, fecha);
            return '';
        }
    }
    
    // ========================================
    // DETECTAR CAMBIOS DE AUTH - OPTIMIZADO
    // ========================================
    
    function checkAuthPeriodically() {
        setInterval(async () => {
            const wasAuth = state.isAuthenticated;
            await verificarAutenticacion();
            
            if (wasAuth !== state.isAuthenticated) {
                updateUIBasedOnAuth();
                if (state.isAuthenticated) {
                    updateUnreadCount();
                }
            }
        }, 5000); // Reducido de 2s a 5s
    }
    
    // ========================================
    // API PÚBLICA
    // ========================================
    
    window.ChatDirecto = {
        open: toggleModal,
        close: closeModal,
        removeAttachment: removeAttachment,
        openImage: openImage,
        startConversation: async (userId, userName, userAvatar) => {
            if (!state.isOpen) toggleModal();
            const existingConv = state.conversaciones.find(c => c.otro_usuario_id === userId);
            if (existingConv) {
                openConversation(existingConv);
            } else {
                openConversation({
                    conversacion_id: null,
                    otro_usuario_id: userId,
                    otro_usuario_nombre: userName,
                    otro_usuario_avatar: userAvatar || getDefaultAvatar(userName)
                });
            }
        }
    };
    
    // ========================================
    // INICIALIZACIÓN
    // ========================================
    
    async function init() {
        createUI();
        attachEventListeners();
        await verificarAutenticacion();
        updateUIBasedOnAuth();
        checkAuthPeriodically();
        checkIfMobile();
        
        if (state.isAuthenticated) {
            setInterval(updateUnreadCount, 45000); // Reducido de 30s
            updateUnreadCount();
        }
        
        console.log('✅ Chat directo v7 OPTIMIZADO listo');
    }
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
})();