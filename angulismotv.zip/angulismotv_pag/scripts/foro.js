// ========================================
// FORO MEJORADO - AngulismoTV
// Sistema con multimedia, drag & drop, y mejoras UX
// ========================================

const CONFIG = {
    API_URL: 'https://foro.angulismotv.workers.dev',
    REFRESH_INTERVAL: 15000,
    MAX_NOMBRE: 30,
    MAX_MENSAJE: 1000,
    MAX_ARCHIVO_SIZE: 10 * 1024 * 1024, // 10MB
    MAX_AVATAR_SIZE: 2 * 1024 * 1024,
    COLORES_AVATAR: [
        '#72d6ff', '#ff7fff', '#7fff7f', '#ffff7f', 
        '#ff7f7f', '#7f7fff', '#ff7fcc', '#7fffcc'
    ],
    TIPOS_IMAGEN: ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/bmp', 'image/svg+xml'],
    TIPOS_VIDEO: ['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime'],
    TIPOS_AUDIO: ['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/ogg', 'audio/aac', 'audio/webm'],
    TIPOS_DOCUMENTO: [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document', // .docx
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // .xlsx
        'application/vnd.ms-powerpoint',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation', // .pptx
        'text/plain',
        'text/csv',
        'application/zip',
        'application/x-zip-compressed',
        'application/x-rar-compressed',
        'application/json'
    ]
};

// ========================================
// LISTENER DE EVENTO DE LOGIN
// ========================================

window.addEventListener('userLoggedIn', function(event) {
    console.log('🔔 Evento de login recibido en foro.js');
    
    const user = event.detail.user;
    
    if (!user) {
        console.error('❌ No hay datos de usuario');
        return;
    }
    
    console.log('✅ Usuario:', user.username);
    
    // 1. Actualizar nombre inmediatamente
    const nombreInput = document.getElementById('foroNombre');
    if (nombreInput) {
        nombreInput.value = user.username;
        nombreInput.disabled = true;
        console.log('✅ Nombre actualizado');
    }
    
    // 2. Sincronizar avatar inmediatamente
    if (user.avatar_url) {
        State.avatarSeleccionado = {
            tipo: 'foto',
            valor: user.avatar_url
        };
        localStorage.setItem('foroAvatar', JSON.stringify(State.avatarSeleccionado));
        
        // Actualizar preview visual
        if (typeof actualizarPreviewAvatar === 'function') {
            actualizarPreviewAvatar();
        }
        
        console.log('✅ Avatar sincronizado');
    }
});

// Sincronizar al cargar si ya está logueado
setTimeout(() => {
    if (typeof AuthState !== 'undefined' && AuthState.isAuthenticated && AuthState.user) {
        console.log('🔄 Sincronizando usuario ya logueado...');
        
        const user = AuthState.user;
        
        // Actualizar nombre
        const nombreInput = document.getElementById('foroNombre');
        if (nombreInput && user.username) {
            nombreInput.value = user.username;
            nombreInput.disabled = true;
        }
        
        // Sincronizar avatar
        if (user.avatar_url) {
            State.avatarSeleccionado = {
                tipo: 'foto',
                valor: user.avatar_url
            };
            localStorage.setItem('foroAvatar', JSON.stringify(State.avatarSeleccionado));
            
            if (typeof actualizarPreviewAvatar === 'function') {
                actualizarPreviewAvatar();
            }
        }
        
        console.log('✅ Usuario sincronizado al cargar');
    }
}, 800);

console.log('✅ Listener de login registrado en foro.js');

// ========================================
// ACTUALIZAR: obtenerAvatarParaEnviar
// Reemplaza la función existente
// ========================================

function obtenerAvatarParaEnviar() {
    // ✅ PRIORIDAD 1: Usuario autenticado
    if (typeof AuthState !== 'undefined' && AuthState.isAuthenticated && AuthState.user) {
        if (AuthState.user.avatar_url) {
            console.log('✅ Usando avatar del usuario autenticado');
            return `<img src="${AuthState.user.avatar_url}" alt="Avatar" class="avatar-imagen">`;
        }
        return generarAvatarIniciales(AuthState.user.username);
    }
    
    // PRIORIDAD 2: Avatar manual
    const nombreInput = document.getElementById('foroNombre');
    const nombre = nombreInput ? nombreInput.value.trim() : '';
    
    switch(State.avatarSeleccionado.tipo) {
        case 'foto':
            if (State.avatarSeleccionado.valor) {
                return `<img src="${State.avatarSeleccionado.valor}" alt="Avatar" class="avatar-imagen">`;
            }
            break;
        case 'emoji':
            if (State.avatarSeleccionado.valor) {
                return `<div class="avatar-emoji">${State.avatarSeleccionado.valor}</div>`;
            }
            break;
    }
    
    return generarAvatarIniciales(nombre);
}

// ========================================
// ACTUALIZAR: inicializarSistemaAvatar
// Reemplaza la función existente
// ========================================

function inicializarSistemaAvatar() {
    // ✅ PASO 1: Verificar si hay usuario autenticado con avatar
    if (typeof AuthState !== 'undefined' && AuthState.isAuthenticated && AuthState.user && AuthState.user.avatar_url) {
        console.log('✅ Usuario autenticado detectado, usando su avatar');
        State.avatarSeleccionado = {
            tipo: 'foto',
            valor: AuthState.user.avatar_url
        };
        localStorage.setItem('foroAvatar', JSON.stringify(State.avatarSeleccionado));
    } else {
        // PASO 2: Cargar avatar guardado localmente
        const avatarGuardado = localStorage.getItem('foroAvatar');
        if (avatarGuardado) {
            try {
                State.avatarSeleccionado = JSON.parse(avatarGuardado);
                console.log('📦 Avatar cargado desde localStorage');
            } catch (e) {
                console.error('Error cargando avatar:', e);
                State.avatarSeleccionado = {
                    tipo: 'iniciales',
                    valor: null
                };
            }
        }
    }
    
    // PASO 3: Actualizar preview del avatar
    actualizarPreviewAvatar();
    
    // PASO 4: Event listener para seleccionar archivo
    const avatarFile = document.getElementById('avatarFile');
    if (avatarFile) {
        avatarFile.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) previsualizarImagen(file);
        });
    }
    
    // PASO 5: Event listener para cerrar modal
    const modal = document.getElementById('modalAvatar');
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) cerrarModalAvatar();
        });
    }
    
    // PASO 6: Listener para sincronizar cuando cambie el usuario
    window.addEventListener('storage', function(e) {
        if (e.key === 'user' || e.key === 'authToken') {
            console.log('🔄 Detectado cambio en usuario, re-sincronizando avatar...');
            setTimeout(() => {
                if (typeof AuthState !== 'undefined' && AuthState.isAuthenticated && AuthState.user && AuthState.user.avatar_url) {
                    State.avatarSeleccionado = {
                        tipo: 'foto',
                        valor: AuthState.user.avatar_url
                    };
                    localStorage.setItem('foroAvatar', JSON.stringify(State.avatarSeleccionado));
                    actualizarPreviewAvatar();
                    console.log('✅ Avatar re-sincronizado');
                }
            }, 300);
        }
    });
    
    console.log('✅ Sistema de avatar inicializado:', State.avatarSeleccionado);
}

// ========================================
// ACTUALIZAR: actualizarPreviewAvatar
// Reemplaza la función existente
// ========================================

function actualizarPreviewAvatar() {
    const avatarPreview = document.getElementById('avatarPreview');
    const avatarIniciales = document.getElementById('avatarIniciales');
    const nombreInput = document.getElementById('foroNombre');
    
    if (!avatarPreview || !avatarIniciales) return;
    
    // ✅ PRIORIDAD 1: Usuario autenticado con avatar
    if (typeof AuthState !== 'undefined' && AuthState.isAuthenticated && AuthState.user && AuthState.user.avatar_url) {
        avatarPreview.src = AuthState.user.avatar_url;
        avatarPreview.style.display = 'block';
        avatarIniciales.style.display = 'none';
        return;
    }
    
    // PRIORIDAD 2: Avatar seleccionado manualmente
    const nombre = nombreInput ? nombreInput.value.trim() : '';
    
    switch(State.avatarSeleccionado.tipo) {
        case 'foto':
            if (State.avatarSeleccionado.valor) {
                avatarPreview.src = State.avatarSeleccionado.valor;
                avatarPreview.style.display = 'block';
                avatarIniciales.style.display = 'none';
            }
            break;
            
        case 'emoji':
            avatarPreview.style.display = 'none';
            avatarIniciales.style.display = 'flex';
            avatarIniciales.textContent = State.avatarSeleccionado.valor || '😊';
            avatarIniciales.style.background = 'linear-gradient(135deg, #72d6ff, #ff7fff)';
            break;
            
        case 'iniciales':
        default:
            avatarPreview.style.display = 'none';
            avatarIniciales.style.display = 'flex';
            
            let iniciales = 'U';
            if (nombre) {
                iniciales = nombre.split(' ')
                    .map(n => n[0])
                    .join('')
                    .substring(0, 2)
                    .toUpperCase();
            }
            
            avatarIniciales.textContent = iniciales;
            avatarIniciales.style.background = generarColorAvatar(nombre);
            break;
    }
}

    window.iniciarChatCon = function(userId, userName, userAvatar, event) {
    if (event) event.stopPropagation();
    
    console.log('💬 Iniciando chat con:', userName, 'ID:', userId);
    
    // Verificar que ChatDirecto existe
    if (typeof ChatDirecto === 'undefined') {
        alert('El sistema de chat no está disponible. Por favor, recarga la página.');
        return;
    }
    
    // Iniciar conversación
    ChatDirecto.startConversation(userId, userName, userAvatar);
};


// ========================================
// ESTADO GLOBAL
// ========================================
const State = {
    ultimoMensajeId: null,
    mensajeSeleccionado: null,
    mensajeSeleccionadoNombre: '',
    mensajeSeleccionadoTexto: '',
    avatarSeleccionado: {
        tipo: 'iniciales',
        valor: null
    },
    archivosAdjuntos: [], // Nuevo: almacena archivos antes de enviar
    refreshTimer: null,
    isTyping: false,
    typingTimer: null
};

// ========================================
// INICIALIZACIÓN
// ========================================
document.addEventListener('DOMContentLoaded', function() {
    init();
});

function init() {
    try {
        cargarMensajes();
        inicializarEventos();
        inicializarBusqueda();
        inicializarNotificaciones();
        inicializarSistemaAvatar();
        inicializarDragAndDrop();
        inicializarPegadoMultimedia();
        inicializarAtajosTeclado();
        
        State.refreshTimer = setInterval(verificarNuevosMensajes, CONFIG.REFRESH_INTERVAL);
        
        console.log('✅ Foro mejorado inicializado correctamente');
    } catch (error) {
        console.error('❌ Error inicializando foro:', error);
        mostrarAlerta('Error al inicializar el foro', 'error');
    }
}

// ========================================
// EVENTOS DEL FORMULARIO MEJORADOS
// ========================================
function inicializarEventos() {
    const foroMensaje = document.getElementById('foroMensaje');
    const foroNombre = document.getElementById('foroNombre');
    
    if (!foroMensaje || !foroNombre) {
        console.error('Elementos del formulario no encontrados');
        return;
    }
    
    // Enter para enviar (Ctrl+Enter para nueva línea)
    foroMensaje.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey && !e.ctrlKey) {
            e.preventDefault();
            enviarMensaje();
        }
    });
    
    // Indicador de escritura
    foroMensaje.addEventListener('input', function() {
        manejarEscritura();
        actualizarContador();
        detectarURLs(this.value);
    });
    
    // Auto-guardar nombre
    const nombreGuardado = localStorage.getItem('foroNombre');
    if (nombreGuardado) {
        foroNombre.value = nombreGuardado;
    }
    
    foroNombre.addEventListener('input', function() {
        localStorage.setItem('foroNombre', this.value);
        if (State.avatarSeleccionado.tipo === 'iniciales') {
            actualizarPreviewAvatar();
        }
    });
    
    // Auto-focus
    foroMensaje.focus();
}

// ========================================
// DRAG & DROP PARA ARCHIVOS
// ========================================
function inicializarDragAndDrop() {
    const dropZone = document.getElementById('foroMensaje');
    if (!dropZone) return;
    
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, preventDefaults, false);
    });
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => {
            dropZone.classList.add('drag-over');
        }, false);
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => {
            dropZone.classList.remove('drag-over');
        }, false);
    });
    
    dropZone.addEventListener('drop', handleDrop, false);
}

function handleDrop(e) {
    const dt = e.dataTransfer;
    const files = dt.files;
    
    if (files.length > 0) {
        procesarArchivos(files);
    }
}

// ========================================
// PEGADO DE MULTIMEDIA
// ========================================
function inicializarPegadoMultimedia() {
    const foroMensaje = document.getElementById('foroMensaje');
    if (!foroMensaje) return;
    
    foroMensaje.addEventListener('paste', async function(e) {
        const items = e.clipboardData.items;
        
        for (let i = 0; i < items.length; i++) {
            const item = items[i];
            
            // Detectar imágenes pegadas
            if (item.type.indexOf('image') !== -1) {
                e.preventDefault();
                const blob = item.getAsFile();
                await procesarArchivos([blob]);
                break;
            }
            
            // Detectar texto (URLs de videos)
            if (item.type === 'text/plain') {
                item.getAsString(texto => {
                    if (esURLVideo(texto)) {
                        e.preventDefault();
                        agregarEmbedVideo(texto);
                    }
                });
            }
        }
    });
}

// ========================================
// PROCESAR ARCHIVOS
// ========================================
async function procesarArchivos(files) {
    for (let file of files) {
        if (file.size > CONFIG.MAX_ARCHIVO_SIZE) {
            mostrarAlerta(`${file.name} es muy grande. Máximo 10MB.`, 'warning');
            continue;
        }
        
        if (CONFIG.TIPOS_IMAGEN.includes(file.type)) {
            await procesarImagen(file);
        } else if (CONFIG.TIPOS_VIDEO.includes(file.type)) {
            await procesarVideo(file);
        } else if (CONFIG.TIPOS_AUDIO.includes(file.type)) {
            await procesarAudio(file);
        } else if (CONFIG.TIPOS_DOCUMENTO.includes(file.type)) {
            await procesarDocumento(file);
        } else {
            mostrarAlerta(`Tipo de archivo no soportado: ${file.name}`, 'warning');
        }
    }
}

async function procesarImagen(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            // Optimizar imagen antes de guardar
            optimizarImagen(e.target.result, (imagenOptimizada) => {
                State.archivosAdjuntos.push({
                    tipo: 'imagen',
                    nombre: file.name,
                    data: imagenOptimizada,
                    tamano: file.size
                });
                
                mostrarPreviewArchivo({
                    tipo: 'imagen',
                    url: imagenOptimizada,
                    nombre: file.name
                });
                
                mostrarAlerta('Imagen agregada correctamente', 'success');
                resolve();
            });
        };
        
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

async function procesarVideo(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            State.archivosAdjuntos.push({
                tipo: 'video',
                nombre: file.name,
                data: e.target.result,
                tamano: file.size
            });
            
            mostrarPreviewArchivo({
                tipo: 'video',
                url: e.target.result,
                nombre: file.name
            });
            
            mostrarAlerta('Video agregado correctamente', 'success');
            resolve();
        };
        
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

async function procesarAudio(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            State.archivosAdjuntos.push({
                tipo: 'audio',
                nombre: file.name,
                data: e.target.result,
                tamano: file.size,
                mimeType: file.type
            });
            
            mostrarPreviewArchivo({
                tipo: 'audio',
                url: e.target.result,
                nombre: file.name,
                mimeType: file.type
            });
            
            mostrarAlerta('Audio agregado correctamente', 'success');
            resolve();
        };
        
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

async function procesarDocumento(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            State.archivosAdjuntos.push({
                tipo: 'documento',
                nombre: file.name,
                data: e.target.result,
                tamano: file.size,
                mimeType: file.type
            });
            
            mostrarPreviewArchivo({
                tipo: 'documento',
                url: e.target.result,
                nombre: file.name,
                mimeType: file.type,
                extension: obtenerExtension(file.name)
            });
            
            mostrarAlerta('Documento agregado correctamente', 'success');
            resolve();
        };
        
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

function obtenerExtension(filename) {
    return filename.split('.').pop().toUpperCase();
}

function obtenerIconoDocumento(mimeType, extension) {
    // PDFs
    if (mimeType === 'application/pdf') return '📄';
    
    // Documentos Word
    if (mimeType.includes('word') || extension === 'DOC' || extension === 'DOCX') return '📝';
    
    // Hojas de cálculo
    if (mimeType.includes('excel') || mimeType.includes('spreadsheet') || extension === 'XLS' || extension === 'XLSX') return '📊';
    
    // Presentaciones
    if (mimeType.includes('powerpoint') || mimeType.includes('presentation') || extension === 'PPT' || extension === 'PPTX') return '📊';
    
    // Archivos de texto
    if (mimeType === 'text/plain' || extension === 'TXT') return '📃';
    
    // CSV
    if (mimeType === 'text/csv' || extension === 'CSV') return '📋';
    
    // Archivos comprimidos
    if (mimeType.includes('zip') || mimeType.includes('rar') || extension === 'ZIP' || extension === 'RAR') return '📦';
    
    // JSON
    if (mimeType === 'application/json' || extension === 'JSON') return '⚙️';
    
    // Por defecto
    return '📎';
}

function formatearTamano(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
}

// ========================================
// OPTIMIZACIÓN DE IMÁGENES
// ========================================
function optimizarImagen(dataURL, callback) {
    const img = new Image();
    img.onload = function() {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        
        // Redimensionar si es muy grande
        const maxDimension = 1920;
        if (width > maxDimension || height > maxDimension) {
            if (width > height) {
                height = (height / width) * maxDimension;
                width = maxDimension;
            } else {
                width = (width / height) * maxDimension;
                height = maxDimension;
            }
        }
        
        canvas.width = width;
        canvas.height = height;
        
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);
        
        // Comprimir a 85% calidad
        callback(canvas.toDataURL('image/jpeg', 0.85));
    };
    img.src = dataURL;
}

// ========================================
// DETECCIÓN Y EMBED DE VIDEOS
// ========================================
function detectarURLs(texto) {
    const urls = texto.match(/https?:\/\/[^\s]+/g);
    if (!urls) return;
    
    urls.forEach(url => {
        if (esURLVideo(url) && !State.archivosAdjuntos.some(a => a.url === url)) {
            // Mostrar sugerencia de embed
            mostrarSugerenciaEmbed(url);
        }
    });
}

function esURLVideo(url) {
    const patronesVideo = [
        /youtube\.com\/watch\?v=([^&]+)/,
        /youtu\.be\/([^?]+)/,
        /vimeo\.com\/(\d+)/,
        /dailymotion\.com\/video\/([^_]+)/,
        /twitch\.tv\/videos\/(\d+)/,
        /streamable\.com\/([^\/]+)/
    ];
    
    return patronesVideo.some(patron => patron.test(url));
}

function agregarEmbedVideo(url) {
    const embedURL = convertirAEmbedURL(url);
    
    if (embedURL) {
        State.archivosAdjuntos.push({
            tipo: 'video_embed',
            url: url,
            embedURL: embedURL,
            nombre: 'Video externo'
        });
        
        mostrarPreviewArchivo({
            tipo: 'video_embed',
            url: embedURL,
            nombre: 'Video'
        });
        
        mostrarAlerta('Video agregado correctamente', 'success');
    }
}

function convertirAEmbedURL(url) {
    // YouTube
    let match = url.match(/youtube\.com\/watch\?v=([^&]+)/);
    if (match) return `https://www.youtube.com/embed/${match[1]}`;
    
    match = url.match(/youtu\.be\/([^?]+)/);
    if (match) return `https://www.youtube.com/embed/${match[1]}`;
    
    // Vimeo
    match = url.match(/vimeo\.com\/(\d+)/);
    if (match) return `https://player.vimeo.com/video/${match[1]}`;
    
    // Twitch
    match = url.match(/twitch\.tv\/videos\/(\d+)/);
    if (match) return `https://player.twitch.tv/?video=${match[1]}&parent=${window.location.hostname}`;
    
    // Streamable
    match = url.match(/streamable\.com\/([^\/]+)/);
    if (match) return `https://streamable.com/e/${match[1]}`;
    
    return null;
}

function mostrarSugerenciaEmbed(url) {
    const sugerencia = document.createElement('div');
    sugerencia.className = 'sugerencia-embed';
    sugerencia.innerHTML = `
        <span>📹 Se detectó un video. ¿Quieres insertarlo?</span>
        <button onclick="agregarEmbedVideo('${url}')">Sí</button>
        <button onclick="this.parentElement.remove()">No</button>
    `;
    
    const formulario = document.querySelector('.formulario-integrado');
    if (formulario && !document.querySelector('.sugerencia-embed')) {
        formulario.insertBefore(sugerencia, formulario.firstChild);
        setTimeout(() => sugerencia.remove(), 10000);
    }
}

// ========================================
// PREVIEW DE ARCHIVOS ADJUNTOS
// ========================================
function mostrarPreviewArchivo(archivo) {
    let container = document.getElementById('archivos-preview');
    
    if (!container) {
        container = document.createElement('div');
        container.id = 'archivos-preview';
        container.className = 'archivos-preview';
        
        const formulario = document.querySelector('.formulario-integrado');
        formulario.insertBefore(container, formulario.firstChild);
    }
    
    const preview = document.createElement('div');
    preview.className = 'archivo-preview-item';
    
    const index = State.archivosAdjuntos.length - 1;
    
    if (archivo.tipo === 'imagen') {
        preview.innerHTML = `
            <img src="${archivo.url}" alt="${archivo.nombre}">
            <button class="btn-remover-archivo" onclick="removerArchivo(${index})">&times;</button>
            <span class="archivo-nombre">${archivo.nombre}</span>
        `;
    } else if (archivo.tipo === 'video') {
        preview.innerHTML = `
            <video src="${archivo.url}" controls></video>
            <button class="btn-remover-archivo" onclick="removerArchivo(${index})">&times;</button>
            <span class="archivo-nombre">${archivo.nombre}</span>
        `;
    } else if (archivo.tipo === 'audio') {
        preview.innerHTML = `
            <div class="audio-preview">
                <span class="audio-icon">🎵</span>
                <span class="audio-name">${archivo.nombre}</span>
            </div>
            <button class="btn-remover-archivo" onclick="removerArchivo(${index})">&times;</button>
        `;
    } else if (archivo.tipo === 'documento') {
        const icono = obtenerIconoDocumento(archivo.mimeType, archivo.extension);
        preview.innerHTML = `
            <div class="documento-preview">
                <span class="documento-icon">${icono}</span>
                <span class="documento-ext">${archivo.extension || 'FILE'}</span>
            </div>
            <button class="btn-remover-archivo" onclick="removerArchivo(${index})">&times;</button>
            <span class="archivo-nombre">${archivo.nombre}</span>
        `;
    } else if (archivo.tipo === 'video_embed') {
        preview.innerHTML = `
            <div class="video-embed-preview">
                <span class="video-icon">📹</span>
                <span>Video de ${extraerPlataforma(archivo.url)}</span>
            </div>
            <button class="btn-remover-archivo" onclick="removerArchivo(${index})">&times;</button>
        `;
    }
    
    container.appendChild(preview);
}

function removerArchivo(index) {
    State.archivosAdjuntos.splice(index, 1);
    
    const container = document.getElementById('archivos-preview');
    if (container) {
        if (State.archivosAdjuntos.length === 0) {
            container.remove();
        } else {
            // Reconstruir previews
            container.innerHTML = '';
            State.archivosAdjuntos.forEach((archivo, i) => {
                mostrarPreviewArchivo(archivo);
            });
        }
    }
}

function extraerPlataforma(url) {
    if (url.includes('youtube.com') || url.includes('youtu.be')) return 'YouTube';
    if (url.includes('vimeo.com')) return 'Vimeo';
    if (url.includes('twitch.tv')) return 'Twitch';
    if (url.includes('streamable.com')) return 'Streamable';
    return 'Web';
}

// ========================================
// ATAJOS DE TECLADO
// ========================================
function inicializarAtajosTeclado() {
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + K para limpiar formulario
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            limpiarFormulario();
        }
        
        // Escape para cancelar respuesta
        if (e.key === 'Escape') {
            cancelarRespuesta();
        }
        
        // Ctrl/Cmd + R para recargar mensajes
        if ((e.ctrlKey || e.metaKey) && e.key === 'r') {
            e.preventDefault();
            cargarMensajes();
            mostrarAlerta('Mensajes actualizados', 'info');
        }
    });
}

function limpiarFormulario() {
    const foroMensaje = document.getElementById('foroMensaje');
    if (foroMensaje) {
        foroMensaje.value = '';
        actualizarContador();
    }
    
    State.archivosAdjuntos = [];
    const container = document.getElementById('archivos-preview');
    if (container) container.remove();
    
    cancelarRespuesta();
    mostrarAlerta('Formulario limpiado', 'info');
}

// ========================================
// INDICADOR DE ESCRITURA
// ========================================
function manejarEscritura() {
    if (!State.isTyping) {
        State.isTyping = true;
        // Aquí podrías enviar al servidor que el usuario está escribiendo
    }
    
    clearTimeout(State.typingTimer);
    State.typingTimer = setTimeout(() => {
        State.isTyping = false;
    }, 1000);
}

function actualizarContador() {
    const foroMensaje = document.getElementById('foroMensaje');
    const contador = document.getElementById('charCounter');
    
    if (!foroMensaje || !contador) return;
    
    const length = foroMensaje.value.length;
    const mediaLength = State.archivosAdjuntos.reduce((sum, a) => {
        return sum + (a.data ? a.data.length : 0);
    }, 0);
    
    contador.textContent = `${length}/${CONFIG.MAX_MENSAJE}`;
    
    if (length > CONFIG.MAX_MENSAJE * 0.9) {
        contador.style.color = '#F44336';
    } else if (State.archivosAdjuntos.length > 0) {
        contador.style.color = '#7fff7f';
    } else {
        contador.style.color = '#7F8C8D';
    }
    
    // Mostrar contador de archivos
    if (State.archivosAdjuntos.length > 0) {
        contador.textContent += ` • ${State.archivosAdjuntos.length} 📎`;
    }
}

// ========================================
// SISTEMA DE AVATAR (mantenido del original)
// ========================================
function inicializarSistemaAvatar() {
    // ✅ PASO 1: Verificar si hay usuario autenticado con avatar
    if (typeof AuthState !== 'undefined' && AuthState.isAuthenticated && AuthState.user && AuthState.user.avatar_url) {
        console.log('✅ Usuario autenticado detectado, usando su avatar');
        State.avatarSeleccionado = {
            tipo: 'foto',
            valor: AuthState.user.avatar_url
        };
        localStorage.setItem('foroAvatar', JSON.stringify(State.avatarSeleccionado));
    } else {
        // PASO 2: Cargar avatar guardado localmente
        const avatarGuardado = localStorage.getItem('foroAvatar');
        if (avatarGuardado) {
            try {
                State.avatarSeleccionado = JSON.parse(avatarGuardado);
                console.log('📦 Avatar cargado desde localStorage');
            } catch (e) {
                console.error('Error cargando avatar:', e);
                // Reset a iniciales si hay error
                State.avatarSeleccionado = {
                    tipo: 'iniciales',
                    valor: null
                };
            }
        }
    }
    
    // PASO 3: Actualizar preview del avatar
    actualizarPreviewAvatar();
    
    // PASO 4: Event listener para seleccionar archivo
    const avatarFile = document.getElementById('avatarFile');
    if (avatarFile) {
        avatarFile.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) previsualizarImagen(file);
        });
    }
    
    // PASO 5: Event listener para cerrar modal al hacer clic fuera
    const modal = document.getElementById('modalAvatar');
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) cerrarModalAvatar();
        });
    }
    
    // ✅ PASO 6: Listener para sincronizar cuando cambie el usuario
    window.addEventListener('storage', function(e) {
        if (e.key === 'user' || e.key === 'authToken') {
            console.log('🔄 Detectado cambio en usuario, re-sincronizando avatar...');
            setTimeout(() => {
                // Recargar avatar del usuario actualizado
                if (typeof AuthState !== 'undefined' && AuthState.isAuthenticated && AuthState.user && AuthState.user.avatar_url) {
                    State.avatarSeleccionado = {
                        tipo: 'foto',
                        valor: AuthState.user.avatar_url
                    };
                    localStorage.setItem('foroAvatar', JSON.stringify(State.avatarSeleccionado));
                    actualizarPreviewAvatar();
                    console.log('✅ Avatar re-sincronizado');
                }
            }, 500);
        }
    });
    
    console.log('✅ Sistema de avatar inicializado:', State.avatarSeleccionado);
}

// ========================================
// FUNCIÓN AUXILIAR: Forzar sincronización manual
// ========================================

function forzarSincronizacionAvatar() {
    console.log('🔄 Forzando sincronización de avatar...');
    
    if (typeof AuthState !== 'undefined' && AuthState.isAuthenticated && AuthState.user) {
        if (AuthState.user.avatar_url) {
            console.log('✅ Avatar encontrado en AuthState.user');
            State.avatarSeleccionado = {
                tipo: 'foto',
                valor: AuthState.user.avatar_url
            };
            localStorage.setItem('foroAvatar', JSON.stringify(State.avatarSeleccionado));
            actualizarPreviewAvatar();
            console.log('✅ Avatar sincronizado correctamente');
            return true;
        } else {
            console.warn('⚠️ Usuario autenticado pero sin avatar_url');
            return false;
        }
    } else {
        console.error('❌ No hay usuario autenticado');
        return false;
    }
}

// Exportar función para uso global
window.forzarSincronizacionAvatar = forzarSincronizacionAvatar;

// ========================================
// EJECUTAR SINCRONIZACIÓN AL CARGAR
// ========================================

// Esperar a que AuthState esté listo antes de sincronizar
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        setTimeout(() => {
            if (typeof forzarSincronizacionAvatar === 'function') {
                forzarSincronizacionAvatar();
            }
        }, 1500); // Esperar 1.5 segundos para que AuthState esté completamente cargado
    });
} else {
    setTimeout(() => {
        if (typeof forzarSincronizacionAvatar === 'function') {
            forzarSincronizacionAvatar();
        }
    }, 1500);
}

function abrirSelectorAvatar() {
    const modal = document.getElementById('modalAvatar');
    if (modal) {
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
}

function cerrarModalAvatar() {
    const modal = document.getElementById('modalAvatar');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
        ocultarTodasSecciones();
        
        const previewArea = document.getElementById('previewArea');
        if (previewArea) previewArea.style.display = 'none';
    }
}

function seleccionarAvatar(tipo) {
    ocultarTodasSecciones();
    State.avatarSeleccionado.tipo = tipo;
    
    switch(tipo) {
        case 'foto':
            const seccionFoto = document.getElementById('seccionFoto');
            if (seccionFoto) seccionFoto.style.display = 'block';
            break;
        case 'emoji':
            const seccionEmoji = document.getElementById('seccionEmoji');
            if (seccionEmoji) seccionEmoji.style.display = 'block';
            break;
        case 'iniciales':
            usarAvatarIniciales();
            break;
    }
}

function ocultarTodasSecciones() {
    const seccionFoto = document.getElementById('seccionFoto');
    const seccionEmoji = document.getElementById('seccionEmoji');
    if (seccionFoto) seccionFoto.style.display = 'none';
    if (seccionEmoji) seccionEmoji.style.display = 'none';
}

function previsualizarImagen(file) {
    if (file.size > CONFIG.MAX_AVATAR_SIZE) {
        mostrarAlerta('La imagen es muy grande. Máximo 2MB.', 'error');
        return;
    }
    
    if (!file.type.match('image.*')) {
        mostrarAlerta('Por favor selecciona una imagen válida.', 'error');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const previewArea = document.getElementById('previewArea');
        const imagePreview = document.getElementById('imagePreview');
        
        if (imagePreview) imagePreview.src = e.target.result;
        if (previewArea) previewArea.style.display = 'block';
        
        State.avatarSeleccionado.valor = e.target.result;
    };
    reader.onerror = () => mostrarAlerta('Error al leer la imagen.', 'error');
    reader.readAsDataURL(file);
}

function confirmarAvatar() {
    guardarAvatar();
    cerrarModalAvatar();
    mostrarAlerta('Avatar actualizado correctamente', 'success');
}

function seleccionarEmoji(emoji) {
    State.avatarSeleccionado.tipo = 'emoji';
    State.avatarSeleccionado.valor = emoji;
    guardarAvatar();
    cerrarModalAvatar();
    mostrarAlerta('Avatar actualizado correctamente', 'success');
}

function usarAvatarIniciales() {
    State.avatarSeleccionado.tipo = 'iniciales';
    State.avatarSeleccionado.valor = null;
    guardarAvatar();
    cerrarModalAvatar();
    mostrarAlerta('Avatar cambiado a iniciales', 'success');
}

function actualizarPreviewAvatar() {
    const avatarPreview = document.getElementById('avatarPreview');
    const avatarIniciales = document.getElementById('avatarIniciales');
    const nombreInput = document.getElementById('foroNombre');
    
    if (!avatarPreview || !avatarIniciales) return;
    
    // ✅ PRIORIDAD 1: Usuario autenticado con avatar
    if (typeof AuthState !== 'undefined' && AuthState.isAuthenticated && AuthState.user && AuthState.user.avatar_url) {
        avatarPreview.src = AuthState.user.avatar_url;
        avatarPreview.style.display = 'block';
        avatarIniciales.style.display = 'none';
        return;
    }
    
    // PRIORIDAD 2: Avatar seleccionado manualmente
    const nombre = nombreInput ? nombreInput.value.trim() : '';
    
    switch(State.avatarSeleccionado.tipo) {
        case 'foto':
            if (State.avatarSeleccionado.valor) {
                avatarPreview.src = State.avatarSeleccionado.valor;
                avatarPreview.style.display = 'block';
                avatarIniciales.style.display = 'none';
            }
            break;
            
        case 'emoji':
            avatarPreview.style.display = 'none';
            avatarIniciales.style.display = 'flex';
            avatarIniciales.textContent = State.avatarSeleccionado.valor || '😊';
            avatarIniciales.style.background = 'linear-gradient(135deg, #72d6ff, #ff7fff)';
            break;
            
        case 'iniciales':
        default:
            avatarPreview.style.display = 'none';
            avatarIniciales.style.display = 'flex';
            
            let iniciales = 'U';
            if (nombre) {
                iniciales = nombre.split(' ')
                    .map(n => n[0])
                    .join('')
                    .substring(0, 2)
                    .toUpperCase();
            }
            
            avatarIniciales.textContent = iniciales;
            avatarIniciales.style.background = generarColorAvatar(nombre);
            break;
    }
}

function guardarAvatar() {
    localStorage.setItem('foroAvatar', JSON.stringify(State.avatarSeleccionado));
    actualizarPreviewAvatar();
}

function obtenerAvatarParaEnviar() {
    // ✅ PRIORIDAD 1: Usuario autenticado con avatar
    if (typeof AuthState !== 'undefined' && AuthState.isAuthenticated && AuthState.user) {
        if (AuthState.user.avatar_url) {
            console.log('✅ Usando avatar del usuario autenticado');
            return `<img src="${AuthState.user.avatar_url}" alt="Avatar" class="avatar-imagen">`;
        }
        
        // Usuario autenticado sin avatar -> usar sus iniciales
        const username = AuthState.user.username;
        return generarAvatarIniciales(username);
    }
    
    // PRIORIDAD 2: Avatar seleccionado manualmente
    const nombreInput = document.getElementById('foroNombre');
    const nombre = nombreInput ? nombreInput.value.trim() : '';
    
    switch(State.avatarSeleccionado.tipo) {
        case 'foto':
            if (State.avatarSeleccionado.valor) {
                return `<img src="${State.avatarSeleccionado.valor}" alt="Avatar" class="avatar-imagen">`;
            }
            break;
            
        case 'emoji':
            if (State.avatarSeleccionado.valor) {
                return `<div class="avatar-emoji">${State.avatarSeleccionado.valor}</div>`;
            }
            break;
    }
    
    // PRIORIDAD 3: Generar iniciales por defecto
    return generarAvatarIniciales(nombre);
}

function generarAvatarIniciales(nombre) {
    const iniciales = nombre.trim().split(' ')
        .map(n => n[0])
        .join('')
        .substring(0, 2)
        .toUpperCase() || 'U';
    
    const color = generarColorAvatar(nombre);
    
    return `<div class="avatar" style="background: ${color}">${iniciales}</div>`;
}

function generarColorAvatar(nombre) {
    if (!nombre) return CONFIG.COLORES_AVATAR[0];
    
    const hash = nombre.split('').reduce((acc, char) => {
        return char.charCodeAt(0) + ((acc << 5) - acc);
    }, 0);
    
    return CONFIG.COLORES_AVATAR[Math.abs(hash) % CONFIG.COLORES_AVATAR.length];
}

// ========================================
// BÚSQUEDA MEJORADA
// ========================================
function inicializarBusqueda() {
    const searchInput = document.getElementById('searchMessages');
    if (!searchInput) return;
    
    let searchTimeout;
    
    searchInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            realizarBusqueda(this.value);
        }, 300);
    });
}

function realizarBusqueda(termino) {
    termino = termino.toLowerCase().trim();
    const mensajes = document.querySelectorAll('.mensaje-item');
    let resultados = 0;
    
    if (termino === '') {
        mensajes.forEach(msg => {
            msg.style.display = 'flex';
            msg.classList.remove('highlight-search');
        });
        return;
    }
    
    mensajes.forEach(msg => {
        const texto = msg.textContent.toLowerCase();
        const coincide = texto.includes(termino);
        
        msg.style.display = coincide ? 'flex' : 'none';
        
        if (coincide) {
            resultados++;
            msg.classList.add('highlight-search');
            setTimeout(() => msg.classList.remove('highlight-search'), 2000);
        }
    });
    
    if (resultados === 0) {
        mostrarAlerta('No se encontraron resultados', 'info');
    }
}

// ========================================
// NOTIFICACIONES
// ========================================
function inicializarNotificaciones() {
    if ("Notification" in window && Notification.permission === "default") {
        Notification.requestPermission();
    }
}

async function verificarNuevosMensajes() {
    try {
        const response = await fetch(CONFIG.API_URL + '/mensajes');
        if (!response.ok) return;
        
        const data = await response.json();
        if (!data.mensajes || data.mensajes.length === 0) return;
        
        const mensajeMasReciente = data.mensajes[0];
        
        if (State.ultimoMensajeId && mensajeMasReciente.id !== State.ultimoMensajeId) {
            mostrarNotificacionNuevoMensaje();
            
            if (Notification.permission === "granted") {
                new Notification("Nuevo mensaje en AngulismoTV", {
                    body: `${mensajeMasReciente.nombre}: ${mensajeMasReciente.mensaje.substring(0, 50)}...`,
                    icon: 'assets/logo.png',
                    badge: 'assets/logo.png'
                });
            }
        }
        
        State.ultimoMensajeId = mensajeMasReciente.id;
    } catch (error) {
        console.error('Error verificando mensajes:', error);
    }
}

function mostrarNotificacionNuevoMensaje() {
    const notif = document.createElement('div');
    notif.className = 'new-message-notification';
    notif.innerHTML = `
        <span>💬 Hay mensajes nuevos</span>
        <button onclick="cargarMensajes()">Ver ahora</button>
    `;
    document.body.appendChild(notif);
    
    setTimeout(() => notif.classList.add('show'), 100);
    setTimeout(() => {
        notif.classList.remove('show');
        setTimeout(() => notif.remove(), 300);
    }, 5000);
}

// ========================================
// CARGAR MENSAJES CON MULTIMEDIA
// ========================================
async function cargarMensajes() {
    const lista = document.getElementById('listaMensajes');
    if (!lista) return;
    
    try {
        const response = await fetch(CONFIG.API_URL + '/mensajes');
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        const mensajes = data.mensajes;
        
        if (!mensajes || mensajes.length === 0) {
            lista.innerHTML = '<div class="empty-state">No hay mensajes todavía. ¡Sé el primero en publicar!</div>';
            return;
        }
        
        // Mensajes ya vienen ordenados DESC (más recientes primero)
        // NO invertir el orden
        
        lista.innerHTML = mensajes.map(msg => crearHTMLMensaje(msg)).join('');
        
        mensajes.forEach(msg => cargarReaccionesParaMensaje(msg.id));
        
        if (mensajes.length > 0) {
            State.ultimoMensajeId = mensajes[0].id;
        }
        
        // Scroll al inicio para ver los mensajes más recientes
        setTimeout(() => lista.scrollTop = 0, 100);
        
    } catch (error) {
        console.error('Error cargando mensajes:', error);
        lista.innerHTML = '<div class="empty-state">Error al cargar los mensajes. Por favor, recarga la página.</div>';
    }
}

function crearHTMLMensaje(msg) {
    const avatar = msg.avatar || generarAvatarIniciales(msg.nombre);
    const mensajeFormateado = formatearMensaje(msg.mensaje);
    const editadoBadge = msg.editado ? '<span class="badge-editado">(editado)</span>' : '';
    
    // Verificar si es mensaje propio
    const authToken = localStorage.getItem('authToken');
    let esMensajePropio = false;
    
    if (authToken && msg.usuario_id) {
        try {
            const payload = JSON.parse(atob(authToken.split('.')[1]));
            const userId = payload.userId;
            
            // Comparar directamente con msg.usuario_id
            esMensajePropio = userId === msg.usuario_id;
        } catch (e) {
            console.error('Error verificando mensaje propio:', e);
        }
    }
    
    // Procesar respuesta si existe
    let respuestaHTML = '';
    if (msg.respuesta_a && msg.respuesta_info) {
        const respInfo = msg.respuesta_info;
        const textoAcortado = respInfo.mensaje && respInfo.mensaje.length > 80 
            ? respInfo.mensaje.substring(0, 80) + '...' 
            : (respInfo.mensaje || '');
        
        respuestaHTML = `
            <div class="respuesta-referencia" onclick="scrollToMensaje('${msg.respuesta_a}')">
                <div class="respuesta-icono">↪</div>
                <div class="respuesta-content">
                    <div class="respuesta-autor">En respuesta a <strong>${escapeHTML(respInfo.nombre)}</strong></div>
                    <div class="respuesta-preview">${escapeHTML(textoAcortado)}</div>
                </div>
            </div>
        `;
    }
    
    // Procesar multimedia si existe
    let multimediaHTML = '';
    if (msg.multimedia) {
        try {
            const multimedia = JSON.parse(msg.multimedia);
            multimediaHTML = generarHTMLMultimedia(multimedia);
        } catch (e) {
            console.error('Error parseando multimedia:', e);
        }
    }
    
    return `
<div class="mensaje-item" data-mensaje-id="${msg.id}" id="mensaje-${msg.id}">        
            <div class="mensaje-avatar">${avatar}</div>
            <div class="mensaje-content">
                <div class="mensaje-header">
                    <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                        <span class="mensaje-nombre">${escapeHTML(msg.nombre)}</span>
                        ${editadoBadge}
                        ${msg.usuario_id && !esMensajePropio ? `
                            <button class="btn-mensaje-directo" onclick="iniciarChatCon(${msg.usuario_id}, '${escapeHTML(msg.nombre).replace(/'/g, "\\'")}', '${avatar.replace(/'/g, "\\'")}', event)" title="Enviar mensaje directo">
                                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                                </svg>
                                Mensaje
                            </button>
                        ` : ''}
                    </div>
                    <span class="mensaje-fecha">${formatearFecha(msg.fecha)}</span>
                </div>
                ${respuestaHTML}
                <div class="mensaje-texto">${mensajeFormateado}</div>
                ${multimediaHTML}
                <div class="mensaje-acciones">
                    <button class="btn-responder" onclick="seleccionarMensaje('${msg.id}', '${escapeHTML(msg.nombre)}', '${escapeHTML(msg.mensaje)}', event)">
                        &#8627; Responder
                    </button>
                    <div class="reacciones-container" id="reacciones-${msg.id}"></div>
                    <button class="btn-reaccion" onclick="mostrarMenuReacciones('${msg.id}', event)">
                        Reaccionar
                    </button>
                </div>
            </div>
        </div>
    `;
}
function generarHTMLMultimedia(multimedia) {
    let html = '<div class="mensaje-multimedia">';
    
    multimedia.forEach(item => {
        if (item.tipo === 'imagen') {
            html += `
                <div class="multimedia-item imagen-item">
                    <img src="${item.data}" alt="${item.nombre}" onclick="abrirImagenFullscreen(this.src)">
                </div>
            `;
        } else if (item.tipo === 'video') {
            html += `
                <div class="multimedia-item video-item">
                    <video controls preload="metadata">
                        <source src="${item.data}" type="video/mp4">
                        Tu navegador no soporta el tag de video.
                    </video>
                </div>
            `;
        } else if (item.tipo === 'audio') {
            html += `
                <div class="multimedia-item audio-item">
                    <div class="audio-player">
                        <span class="audio-icon-large">🎵</span>
                        <div class="audio-info">
                            <span class="audio-title">${escapeHTML(item.nombre)}</span>
                            <span class="audio-size">${formatearTamano(item.tamano || 0)}</span>
                        </div>
                    </div>
                    <audio controls preload="metadata" style="width: 100%; margin-top: 8px;">
                        <source src="${item.data}" type="${item.mimeType || 'audio/mpeg'}">
                        Tu navegador no soporta el tag de audio.
                    </audio>
                </div>
            `;
        } else if (item.tipo === 'documento') {
            const icono = obtenerIconoDocumento(item.mimeType, obtenerExtension(item.nombre));
            const extension = obtenerExtension(item.nombre);
            html += `
                <div class="multimedia-item documento-item">
                    <div class="documento-card">
                        <div class="documento-icon-large">${icono}</div>
                        <div class="documento-details">
                            <span class="documento-name">${escapeHTML(item.nombre)}</span>
                            <span class="documento-meta">${extension} • ${formatearTamano(item.tamano || 0)}</span>
                        </div>
                        <a href="${item.data}" download="${item.nombre}" class="btn-descargar" title="Descargar">
                            ⬇️
                        </a>
                    </div>
                </div>
            `;
        } else if (item.tipo === 'video_embed') {
            html += `
                <div class="multimedia-item video-embed-item">
                    <iframe 
                        src="${item.embedURL}" 
                        frameborder="0" 
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                        allowfullscreen>
                    </iframe>
                </div>
            `;
        }
    });
    
    html += '</div>';
    return html;
}

// ========================================
// SCROLL A MENSAJE (para respuestas)
// ========================================
function scrollToMensaje(mensajeId) {
    const elemento = document.getElementById(`mensaje-${mensajeId}`);
    if (elemento) {
        elemento.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // Efecto de resaltado temporal
        elemento.classList.add('mensaje-destacado');
        setTimeout(() => {
            elemento.classList.remove('mensaje-destacado');
        }, 2000);
    } else {
        mostrarAlerta('Mensaje no encontrado en la vista actual', 'info');
    }
}

// ========================================
// VISOR DE IMÁGENES FULLSCREEN
// ========================================
function abrirImagenFullscreen(src) {
    const viewer = document.createElement('div');
    viewer.className = 'image-fullscreen-viewer';
    viewer.innerHTML = `
        <div class="fullscreen-backdrop" onclick="this.parentElement.remove()"></div>
        <div class="fullscreen-content">
            <button class="btn-cerrar-fullscreen" onclick="this.closest('.image-fullscreen-viewer').remove()">&times;</button>
            <img src="${src}" alt="Imagen ampliada">
        </div>
    `;
    
    document.body.appendChild(viewer);
    document.body.style.overflow = 'hidden';
    
    setTimeout(() => viewer.classList.add('show'), 10);
    
    viewer.addEventListener('click', function(e) {
        if (e.target === viewer || e.target.classList.contains('fullscreen-backdrop')) {
            viewer.classList.remove('show');
            setTimeout(() => {
                viewer.remove();
                document.body.style.overflow = 'auto';
            }, 300);
        }
    });
}

// ========================================
// SISTEMA DE RESPUESTAS
// ========================================
function seleccionarMensaje(msgId, nombre, texto, event) {
    event.stopPropagation();
    
    if (State.mensajeSeleccionado === msgId) {
        cancelarRespuesta();
        return;
    }
    
    State.mensajeSeleccionado = msgId;
    State.mensajeSeleccionadoNombre = nombre;
    State.mensajeSeleccionadoTexto = texto;
    
    document.querySelectorAll('.mensaje-item').forEach(item => {
        item.classList.remove('seleccionado');
    });
    
const mensajeItem = document.querySelector(`[data-mensaje-id="${msgId}"]`);
    if (mensajeItem) mensajeItem.classList.add('seleccionado');
    
    mostrarIndicadorRespuesta(nombre, texto);
    
    const foroMensaje = document.getElementById('foroMensaje');
    if (foroMensaje) {
        foroMensaje.focus();
        foroMensaje.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
}

function mostrarIndicadorRespuesta(nombre, texto) {
    ocultarIndicadorRespuesta();
    
    const textoAcortado = texto.length > 100 ? texto.substring(0, 100) + '...' : texto;
    
    const indicador = document.createElement('div');
    indicador.id = 'indicador-respuesta';
    indicador.innerHTML = `
        <div class="indicador-respuesta-content">
            <div class="respuesta-info">
                <div class="respuesta-titulo">Respondiendo a <strong>${escapeHTML(nombre)}</strong></div>
                <div class="respuesta-mensaje">"${escapeHTML(textoAcortado)}"</div>
            </div>
            <button onclick="cancelarRespuesta()" class="btn-cancelar-respuesta">&times; Cancelar</button>
        </div>
    `;
    
    const formulario = document.querySelector('.formulario-integrado');
    if (formulario) formulario.parentNode.insertBefore(indicador, formulario);
}

function ocultarIndicadorRespuesta() {
    const indicador = document.getElementById('indicador-respuesta');
    if (indicador) indicador.remove();
}

function cancelarRespuesta() {
    State.mensajeSeleccionado = null;
    State.mensajeSeleccionadoNombre = '';
    State.mensajeSeleccionadoTexto = '';
    
    document.querySelectorAll('.mensaje-item').forEach(item => {
        item.classList.remove('seleccionado');
    });
    
    ocultarIndicadorRespuesta();
}

// ========================================
// FORMATEO DE MENSAJES
// ========================================
function formatearMensaje(texto) {
    let resultado = escapeHTML(texto);
    
    // @menciones
    resultado = resultado.replace(/@(\w+)/g, '<span class="mencion">@$1</span>');
    
    // #hashtags
    resultado = resultado.replace(/#(\w+)/g, '<span class="hashtag">#$1</span>');
    
    // URLs (pero no las de embed que ya están procesadas)
    resultado = resultado.replace(
        /(https?:\/\/[^\s]+)/g, 
        '<a href="$1" target="_blank" rel="noopener noreferrer" class="mensaje-link">🔗Enlace</a>'
    );
    
    // Emojis grandes si el mensaje solo tiene emojis
    const soloEmojis = /^[\p{Emoji}\s]+$/u.test(texto.trim());
    if (soloEmojis && texto.length < 20) {
        resultado = `<span class="solo-emojis">${resultado}</span>`;
    }
    
    // Saltos de línea
    resultado = resultado.replace(/\n/g, '<br>');
    
    return resultado;
}

function escapeHTML(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

function formatearFecha(fechaString) {
    try {
        let fecha;
        
        if (fechaString && !fechaString.endsWith('Z') && !fechaString.includes('+') && !fechaString.includes('T')) {
            fecha = new Date(fechaString.replace(' ', 'T') + 'Z');
        } else if (fechaString && fechaString.includes('T') && !fechaString.endsWith('Z') && !fechaString.includes('+')) {
            fecha = new Date(fechaString + 'Z');
        } else {
            fecha = new Date(fechaString);
        }
        
        if (isNaN(fecha.getTime())) {
            console.error('Fecha inválida:', fechaString);
            return 'Fecha inválida';
        }
        
        const ahora = new Date();
        const inicioHoy = new Date(ahora.getFullYear(), ahora.getMonth(), ahora.getDate());
        const inicioFecha = new Date(fecha.getFullYear(), fecha.getMonth(), fecha.getDate());
        const dias = Math.floor((inicioHoy - inicioFecha) / (3600000 * 24));
        
        const userLocale = navigator.language || 'es-AR';
        
        const opciones = { 
            hour: '2-digit', 
            minute: '2-digit'
        };
        const hora = fecha.toLocaleTimeString(userLocale, opciones);
        
        if (dias === 0) return `Hoy ${hora}`;
        if (dias === 1) return `Ayer ${hora}`;
        if (dias < 7) {
            const diaSemana = fecha.toLocaleDateString(userLocale, { 
                weekday: 'short'
            });
            return `${diaSemana} ${hora}`;
        }
        
        return fecha.toLocaleDateString(userLocale, {
            day: 'numeric',
            month: 'short',
            hour: '2-digit',
            minute: '2-digit'
        });
        
    } catch (error) {
        console.error('Error formateando fecha:', error, 'Input:', fechaString);
        return 'Error en fecha';
    }
}

// ========================================
// REACCIONES
// ========================================
function mostrarMenuReacciones(msgId, event) {
    event.stopPropagation();
    
    document.querySelectorAll('.reacciones-menu').forEach(m => m.remove());
    
    const menu = document.createElement('div');
    menu.className = 'reacciones-menu';
    menu.innerHTML = `
        <button onclick="agregarReaccion('${msgId}', '❤️')">❤️</button>
        <button onclick="agregarReaccion('${msgId}', '👍')">👍</button>
        <button onclick="agregarReaccion('${msgId}', '😂')">😂</button>
        <button onclick="agregarReaccion('${msgId}', '🔥')">🔥</button>
        <button onclick="agregarReaccion('${msgId}', '👏')">👏</button>
        <button onclick="agregarReaccion('${msgId}', '🎉')">🎉</button>
    `;
    
    event.target.parentElement.appendChild(menu);
    
    setTimeout(() => {
        document.addEventListener('click', function cerrarMenu() {
            menu.remove();
            document.removeEventListener('click', cerrarMenu);
        });
    }, 100);
}

async function agregarReaccion(msgId, emoji) {
    try {
        let userId = localStorage.getItem('userId');
        if (!userId) {
            userId = 'user_' + Math.random().toString(36).substring(7);
            localStorage.setItem('userId', userId);
        }
        
        const response = await fetch(`${CONFIG.API_URL}/mensajes/${msgId}/reacciones`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ emoji, userId })
        });
        
        const resultado = await response.json();
        if (resultado.success) {
            await cargarReaccionesParaMensaje(msgId);
        }
    } catch (error) {
        console.error('Error agregando reacción:', error);
        mostrarAlerta('Error al agregar reacción', 'error');
    }
}

async function cargarReaccionesParaMensaje(msgId) {
    try {
        const response = await fetch(`${CONFIG.API_URL}/mensajes/${msgId}/reacciones`);
        if (!response.ok) return;
        
        const reacciones = await response.json();
        const container = document.getElementById(`reacciones-${msgId}`);
        
        if (container && reacciones.length > 0) {
            container.innerHTML = reacciones
                .map(r => `<span class="reaccion-badge" onclick="agregarReaccion('${msgId}', '${r.emoji}')">${r.emoji} ${r.count}</span>`)
                .join('');
        }
    } catch (error) {
        console.error('Error cargando reacciones:', error);
    }
}

// ========================================
// ENVIAR MENSAJE CON MULTIMEDIA
// ========================================
async function enviarMensaje() {
    const nombreInput = document.getElementById('foroNombre');
    const mensajeInput = document.getElementById('foroMensaje');
    
    if (!nombreInput || !mensajeInput) {
        mostrarAlerta('Error: formulario no encontrado', 'error');
        return;
    }
    
    const nombre = nombreInput.value.trim();
    let mensaje = mensajeInput.value.trim();
    
    // Validaciones
    if (!nombre) {
        mostrarAlerta('Por favor, ingresa tu nombre', 'warning');
        nombreInput.focus();
        return;
    }
    
    if (!mensaje && State.archivosAdjuntos.length === 0) {
        mostrarAlerta('Por favor, escribe un mensaje o adjunta un archivo', 'warning');
        mensajeInput.focus();
        return;
    }
    
    if (nombre.length > CONFIG.MAX_NOMBRE) {
        mostrarAlerta(`El nombre no puede superar ${CONFIG.MAX_NOMBRE} caracteres`, 'warning');
        return;
    }
    
    if (mensaje.length > CONFIG.MAX_MENSAJE) {
        mostrarAlerta(`El mensaje no puede superar ${CONFIG.MAX_MENSAJE} caracteres`, 'warning');
        return;
    }
    
    // Agregar mención si es respuesta
    if (State.mensajeSeleccionado && State.mensajeSeleccionadoNombre) {
        mensaje = `@${State.mensajeSeleccionadoNombre} ${mensaje}`;
    }
    
    const avatarHTML = obtenerAvatarParaEnviar();
    
    // Preparar multimedia
    const multimedia = State.archivosAdjuntos.length > 0 
        ? JSON.stringify(State.archivosAdjuntos) 
        : null;
    
    // Deshabilitar botón
    const btnEnviar = document.querySelector('.btn-foro');
    if (btnEnviar) {
        btnEnviar.disabled = true;
        btnEnviar.textContent = State.archivosAdjuntos.length > 0 ? 'Subiendo...' : 'Enviando...';
    }
    
    try {
        const response = await fetch(CONFIG.API_URL + '/mensajes', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                nombre: nombre,
                mensaje: mensaje,
                avatar: avatarHTML,
                multimedia: multimedia,
                respuesta_a: State.mensajeSeleccionado
            })
        });
        
        const resultado = await response.json();
        
        if (response.ok && resultado.success) {
            mensajeInput.value = '';
            State.archivosAdjuntos = [];
            
            const previewContainer = document.getElementById('archivos-preview');
            if (previewContainer) previewContainer.remove();
            
            mensajeInput.focus();
            cancelarRespuesta();
            actualizarContador();
            
            mostrarAlerta('Mensaje publicado correctamente ✓', 'success');
            await cargarMensajes();
        } else {
            const errorMsg = resultado.error || 'Error al publicar el mensaje';
            mostrarAlerta(errorMsg, 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        mostrarAlerta('Error de conexión. Intenta nuevamente', 'error');
    } finally {
        if (btnEnviar) {
            btnEnviar.disabled = false;
            btnEnviar.textContent = 'Enviar';
        }
    }
}

// ========================================
// ALERTAS
// ========================================
function mostrarAlerta(mensaje, tipo = 'info') {
    const alerta = document.createElement('div');
    alerta.className = `alerta alerta-${tipo}`;
    alerta.textContent = mensaje;
    document.body.appendChild(alerta);
    
    setTimeout(() => alerta.classList.add('show'), 100);
    setTimeout(() => {
        alerta.classList.remove('show');
        setTimeout(() => alerta.remove(), 300);
    }, 3000);
}

// ========================================
// EXPORTAR FUNCIONES GLOBALES
// ========================================
window.enviarMensaje = enviarMensaje;
window.mostrarMenuReacciones = mostrarMenuReacciones;
window.agregarReaccion = agregarReaccion;
window.cargarMensajes = cargarMensajes;
window.seleccionarMensaje = seleccionarMensaje;
window.cancelarRespuesta = cancelarRespuesta;
window.abrirSelectorAvatar = abrirSelectorAvatar;
window.cerrarModalAvatar = cerrarModalAvatar;
window.seleccionarAvatar = seleccionarAvatar;
window.seleccionarEmoji = seleccionarEmoji;
window.confirmarAvatar = confirmarAvatar;
window.usarAvatarIniciales = usarAvatarIniciales;
window.removerArchivo = removerArchivo;
window.agregarEmbedVideo = agregarEmbedVideo;
window.abrirImagenFullscreen = abrirImagenFullscreen;
window.limpiarFormulario = limpiarFormulario;

// ========================================
// FIX: Corregir data-id a data-mensaje-id
// ========================================
(function() {
    const observer = new MutationObserver((mutations) => {
        mutations.forEach(mutation => {
            mutation.addedNodes.forEach(node => {
                if (node.nodeType === 1 && node.classList?.contains('mensaje-item')) {
                    // Si tiene data-id, cambiarlo a data-mensaje-id
                    const dataId = node.getAttribute('data-id');
                    if (dataId) {
                        node.setAttribute('data-mensaje-id', dataId);
                        node.removeAttribute('data-id');
                        console.log(`✅ Corregido: data-id → data-mensaje-id (${dataId})`);
                    }
                }
            });
        });
    });
    
    setTimeout(() => {
        const listaMensajes = document.getElementById('listaMensajes');
        if (listaMensajes) {
            observer.observe(listaMensajes, { childList: true, subtree: true });
            
            // Corregir mensajes existentes
            document.querySelectorAll('.mensaje-item').forEach(msg => {
                const dataId = msg.getAttribute('data-id');
                if (dataId) {
                    msg.setAttribute('data-mensaje-id', dataId);
                    msg.removeAttribute('data-id');
                }
            });
            
            console.log('🔧 Observer instalado para corregir data-id');
        }
    }, 2000);
})();