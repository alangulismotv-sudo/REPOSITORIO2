/* ============================================================
   search-channels.js
   Filtrado en tiempo real de las cards del grid de canales.

   Estructura esperada (la que genera renderChannels en main.js):
     <div class="channel-card">
       <img src="..." alt="nombre">
       <div class="name">Nombre del canal</div>
     </div>

   El script se conecta al grid mediante un MutationObserver,
   así que funciona aunque las cards se cargen de forma async.
   ============================================================ */

(function () {
  'use strict';

  // ---------- DOM refs ----------
  var wrapper  = document.getElementById('channelsSearchWrapper');
  var input    = document.getElementById('channelsSearchInput');
  var clearBtn = document.getElementById('channelsSearchClear');
  var grid     = document.getElementById('channelsGrid');

  // Safe exit si algún elemento no existe
  if (!wrapper || !input || !clearBtn || !grid) return;

  // ---------- Utilidades ----------

  /**
   * Obtiene el texto buscable de una card.
   * Usa .name (div generado por renderChannels) → alt de la img → textContent
   */
  function getCardText(card) {
    var nameEl = card.querySelector('.name');
    if (nameEl && nameEl.textContent.trim()) return nameEl.textContent.trim();

    var img = card.querySelector('img');
    if (img && img.alt && img.alt.trim()) return img.alt.trim();

    return card.textContent || '';
  }

  /**
   * Normaliza: minúsculas + sin acentos
   */
  function normalize(str) {
    return (str || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '');
  }

  // ---------- Filtro principal ----------

  function filterCards() {
    var query   = normalize(input.value.trim());
    var cards   = grid.querySelectorAll('.channel-card');
    var visible = 0;

    cards.forEach(function (card) {
      var text = normalize(getCardText(card));
      var show = (query === '' || text.includes(query));

      card.style.display = show ? '' : 'none';
      if (show) visible++;
    });

    // Controlar mensaje "sin resultados"
    var noResults = document.getElementById('channelsNoResults');
    if (noResults) {
      noResults.style.display = (visible === 0 && query !== '') ? 'block' : 'none';
    }

    // Clase helper para mostrar/ocultar botón ×
    wrapper.classList.toggle('has-value', input.value.length > 0);
  }

  // ---------- Eventos ----------

  input.addEventListener('input', filterCards);

  clearBtn.addEventListener('click', function () {
    input.value = '';
    filterCards();
    input.focus();
  });

  // MutationObserver: cuando main.js mete las cards async, re-ejecuta el filtro
  var mo = new MutationObserver(function () {
    filterCards();
  });
  mo.observe(grid, { childList: true, subtree: true });

})();