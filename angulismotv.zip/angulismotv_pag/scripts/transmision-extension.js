// Detecta si la extensión está instalada
function isExtensionInstalled(installedCallback, notInstalledCallback) {
  const img = document.createElement('img');
  img.src = 'chrome-extension://opmeopcambhfimffbomjgemehjkbbmji/play-on.png';
  img.onload = installedCallback;
  img.onerror = notInstalledCallback;
}

// Envía el mensaje a la extensión para que inserte el reproductor
function usarExtensionConStream(streamUrl) {
  window.postMessage({
    type: 'insert-player',
    url: streamUrl
  }, '*');
}

// Maneja la opción seleccionada desde el JSON
function manejarOpcion(opcion, indice) {
  if (indice === 3) { // Solo para la opción 4 (índice 3)
    const streamUrl = opcion.iframe.split('#')[1]; // Extrae solo la URL del stream
    isExtensionInstalled(
      () => usarExtensionConStream(streamUrl),
      () => alert('La opción 4 requiere tener instalada la extensión del reproductor.')
    );
  } else {
    // Para todas las otras opciones (índices 0, 1, 2, etc.)
    document.getElementById('contenedor').innerHTML = `
      <iframe src="${opcion.iframe}" width="100%" height="100%" allow="autoplay; encrypted-media"></iframe>
    `;
  }
}