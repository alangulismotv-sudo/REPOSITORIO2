/**
 * AngulismoTV - UI Controller & Visual Effects OPTIMIZADO
 * Versión con Chat Funcional y Performance Boost
 */

(function() {
  'use strict';

  // ==================== Configuration ====================
  const CONFIG = {
    defaults: {
      accentColor: '#72d6ff',
      starsEnabled: true,
      starsCount: 40,
      bgOpacity: 70,
      autoChat: true,
      autoReload: false
    },
    starfield: {
      regularRatio: 0.85,
      shootingRatio: 0.05,
      comets: 1,
      planets: 1,
      stardustRatio: 0.2,
      headerStars: 8
    },
    performance: {
      lazyLoadDelay: 1000,
      reducedMotion: window.matchMedia('(prefers-reduced-motion: reduce)').matches,
      lowEndDevice: /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || 
                   (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4)
    }
  };

  // ==================== State Management ====================
  class SettingsManager {
    constructor(defaults) {
      this.defaults = defaults;
      this.current = this.load();
      this.saveTimeout = null;
    }

    load() {
      try {
        const saved = localStorage.getItem('angulismoSettings');
        return saved ? { ...this.defaults, ...JSON.parse(saved) } : { ...this.defaults };
      } catch {
        return { ...this.defaults };
      }
    }

    save() {
      if (this.saveTimeout) clearTimeout(this.saveTimeout);
      this.saveTimeout = setTimeout(() => {
        try {
          localStorage.setItem('angulismoSettings', JSON.stringify(this.current));
        } catch (error) {
          console.warn('Error saving settings:', error);
        }
      }, 500);
    }

    update(key, value) {
      this.current[key] = value;
      this.save();
    }

    reset() {
      this.current = { ...this.defaults };
      this.save();
    }

    get(key) {
      return this.current[key];
    }
  }

  // ==================== Starfield Generator ====================
  class StarfieldGenerator {
    constructor(container, config) {
      this.container = container;
      this.config = config;
      this.stars = [];
      this.rafId = null;
    }

    generate(count) {
      this.clear();
      
      const finalCount = CONFIG.performance.lowEndDevice ? 
                        Math.floor(count * 0.6) : count;
      
      console.log(`🌟 Generando ${finalCount} estrellas (optimizado)`);
      this.generateBatch(finalCount, 0, 15);
    }

    generateBatch(totalCount, currentCount, batchSize) {
      if (currentCount >= totalCount) return;

      const fragment = document.createDocumentFragment();
      const batchCount = Math.min(batchSize, totalCount - currentCount);

      this.createRegularStars(fragment, Math.floor(batchCount * this.config.regularRatio));
      
      if (!CONFIG.performance.lowEndDevice) {
        this.createShootingStars(fragment, Math.ceil(batchCount * this.config.shootingRatio));
        this.createComets(fragment, currentCount === 0 ? this.config.comets : 0);
        this.createPlanets(fragment, currentCount === 0 ? this.config.planets : 0);
        this.createStardust(fragment, Math.floor(batchCount * this.config.stardustRatio));
      }

      this.container.appendChild(fragment);

      this.rafId = requestAnimationFrame(() => {
        this.generateBatch(totalCount, currentCount + batchCount, batchSize);
      });
    }

    clear() {
      if (this.rafId) {
        cancelAnimationFrame(this.rafId);
        this.rafId = null;
      }
      this.container.textContent = '';
      this.stars = [];
    }

    createRegularStars(fragment, count) {
      for (let i = 0; i < count; i++) {
        const star = document.createElement('div');
        star.className = 'star';
        
        const layer = Math.floor(Math.random() * 3) + 1;
        star.classList.add(`layer-${layer}`);
        star.dataset.speed = layer * 0.2;
        
        const size = Math.random() * 2 + 0.5;
        Object.assign(star.style, {
          width: size + 'px',
          height: size + 'px',
          top: Math.random() * 100 + '%',
          left: Math.random() * 100 + '%',
          animationDuration: (Math.random() * 3 + 2) + 's',
          animationDelay: Math.random() * 2 + 's'
        });
        
        fragment.appendChild(star);
        this.stars.push(star);
      }
    }

    createShootingStars(fragment, count) {
      if (CONFIG.performance.reducedMotion) return;

      for (let i = 0; i < count; i++) {
        const star = document.createElement('div');
        star.className = 'shooting-star';
        Object.assign(star.style, {
          top: Math.random() * 50 + '%',
          left: (Math.random() * 50 + 50) + '%',
          animationDelay: (Math.random() * 8 + 4) + 's',
          animationDuration: (Math.random() * 2 + 2) + 's',
          width: (Math.random() * 80 + 40) + 'px'
        });
        fragment.appendChild(star);
        this.stars.push(star);
      }
    }

    createComets(fragment, count) {
      if (CONFIG.performance.reducedMotion) return;

      for (let i = 0; i < count; i++) {
        const comet = document.createElement('div');
        comet.className = 'comet';
        Object.assign(comet.style, {
          top: Math.random() * 30 + '%',
          left: (Math.random() * 30 + 70) + '%',
          animationDelay: (Math.random() * 15 + 10) + 's'
        });
        fragment.appendChild(comet);
        this.stars.push(comet);
      }
    }

    createPlanets(fragment, count) {
      for (let i = 1; i <= count; i++) {
        const planet = document.createElement('div');
        planet.className = `planet planet-${i}`;
        fragment.appendChild(planet);
        this.stars.push(planet);
      }
    }

    createStardust(fragment, count) {
      if (CONFIG.performance.reducedMotion) return;

      for (let i = 0; i < count; i++) {
        const dust = document.createElement('div');
        dust.className = 'stardust';
        Object.assign(dust.style, {
          left: Math.random() * 100 + '%',
          bottom: '0',
          animationDelay: Math.random() * 25 + 's',
          animationDuration: (Math.random() * 8 + 12) + 's'
        });
        fragment.appendChild(dust);
        this.stars.push(dust);
      }
    }

    pauseAnimations() {
      if (this.stars.length > 0) {
        this.stars.forEach(star => {
          if (star.style) star.style.animationPlayState = 'paused';
        });
      }
    }

    resumeAnimations() {
      if (this.stars.length > 0) {
        this.stars.forEach(star => {
          if (star.style) star.style.animationPlayState = 'running';
        });
      }
    }
  }

  // ==================== Parallax Effect ====================
  class ParallaxController {
    constructor() {
      this.scrollY = 0;
      this.rafId = null;
      this.stars = [];
      this.lastUpdate = 0;
      this.updateInterval = 1000 / 30;
      this.init();
    }

    init() {
      setTimeout(() => {
        this.stars = Array.from(document.querySelectorAll('.star[data-speed]'));
      }, 2000);

      window.addEventListener('scroll', () => {
        this.scrollY = window.pageYOffset;
        
        const now = Date.now();
        if (now - this.lastUpdate >= this.updateInterval) {
          this.lastUpdate = now;
          if (!this.rafId) {
            this.rafId = requestAnimationFrame(() => this.update());
          }
        }
      }, { passive: true });
    }

    update() {
      if (this.stars.length === 0) return;

      this.stars.forEach(star => {
        const speed = parseFloat(star.dataset.speed) || 0;
        const translateY = this.scrollY * speed;
        
        if (Math.abs(translateY - (parseFloat(star.dataset.lastY) || 0)) > 0.5) {
          star.style.transform = `translateY(${translateY}px)`;
          star.dataset.lastY = translateY;
        }
      });
      
      this.rafId = null;
    }
  }

  // ==================== Header Stars ====================
  class HeaderStars {
    constructor(header, count) {
      this.header = header;
      this.count = CONFIG.performance.lowEndDevice ? Math.floor(count * 0.5) : count;
      this.generate();
    }

    generate() {
      const fragment = document.createDocumentFragment();
      
  
      
      this.header.appendChild(fragment);
    }
  }

  // ==================== Settings UI Controller ====================
  class SettingsUI {
    constructor(settings, starfield) {
      this.settings = settings;
      this.starfield = starfield;
      this.elements = this.cacheElements();
      this.debounceTimeouts = {};
      this.init();
    }

    cacheElements() {
      return {
        panel: document.getElementById('customizePanel'),
        openBtn: document.getElementById('customizeBtn'),
        closeBtn: document.getElementById('closePanel'),
        colorOptions: document.querySelectorAll('.color-option'),
        starsToggle: document.getElementById('starsToggle'),
        starsIntensity: document.getElementById('starsIntensity'),
        starsValue: document.getElementById('starsValue'),
        bgOpacity: document.getElementById('bgOpacity'),
        opacityValue: document.getElementById('opacityValue'),
        autoChatToggle: document.getElementById('autoChatToggle'),
        autoReloadToggle: document.getElementById('autoReloadToggle'),
        resetBtn: document.getElementById('resetSettings')
      };
    }

    init() {
      this.initializeUI();
      this.bindEvents();
      this.applySettings();
    }

    initializeUI() {
      const { starsToggle, starsIntensity, starsValue, bgOpacity, opacityValue, autoChatToggle, autoReloadToggle, colorOptions } = this.elements;
      
      if (starsToggle) starsToggle.checked = this.settings.get('starsEnabled');
      if (starsIntensity) starsIntensity.value = this.settings.get('starsCount');
      if (starsValue) starsValue.textContent = this.settings.get('starsCount');
      if (bgOpacity) bgOpacity.value = this.settings.get('bgOpacity');
      if (opacityValue) opacityValue.textContent = this.settings.get('bgOpacity') + '%';
      if (autoChatToggle) autoChatToggle.checked = this.settings.get('autoChat');
      if (autoReloadToggle) autoReloadToggle.checked = this.settings.get('autoReload');
      
      const currentColor = this.settings.get('accentColor');
      colorOptions.forEach(option => {
        option.classList.toggle('active', option.dataset.color === currentColor);
      });
    }

    debounce(key, callback, delay = 300) {
      if (this.debounceTimeouts[key]) clearTimeout(this.debounceTimeouts[key]);
      this.debounceTimeouts[key] = setTimeout(callback, delay);
    }

    bindEvents() {
      const { panel, openBtn, closeBtn, colorOptions, starsToggle, starsIntensity, bgOpacity, autoChatToggle, autoReloadToggle, resetBtn } = this.elements;

      if (openBtn) openBtn.addEventListener('click', () => panel?.classList.add('active'));
      if (closeBtn) closeBtn.addEventListener('click', () => panel?.classList.remove('active'));

      document.addEventListener('click', (e) => {
        if (panel?.classList.contains('active') && 
            !panel.contains(e.target) && 
            e.target !== openBtn &&
            !openBtn?.contains(e.target)) {
          panel.classList.remove('active');
        }
      });

      if (colorOptions.length > 0) {
        document.addEventListener('click', (e) => {
          const colorOption = e.target.closest('.color-option');
          if (colorOption) {
            colorOptions.forEach(opt => opt.classList.remove('active'));
            colorOption.classList.add('active');
            this.settings.update('accentColor', colorOption.dataset.color);
            this.applySettings();
          }
        });
      }

      if (starsToggle) {
        starsToggle.addEventListener('change', () => {
          this.settings.update('starsEnabled', starsToggle.checked);
          this.applySettings();
        });
      }

      if (starsIntensity) {
        starsIntensity.addEventListener('input', () => {
          this.debounce('starsIntensity', () => {
            const value = parseInt(starsIntensity.value);
            this.elements.starsValue.textContent = value;
            this.settings.update('starsCount', value);
            this.applySettings();
          }, 500);
        });
      }

      if (bgOpacity) {
        bgOpacity.addEventListener('input', () => {
          this.debounce('bgOpacity', () => {
            const value = parseInt(bgOpacity.value);
            this.elements.opacityValue.textContent = value + '%';
            this.settings.update('bgOpacity', value);
            this.applySettings();
          });
        });
      }

      if (autoChatToggle) {
        autoChatToggle.addEventListener('change', () => {
          this.settings.update('autoChat', autoChatToggle.checked);
        });
      }

      if (autoReloadToggle) {
        autoReloadToggle.addEventListener('change', () => {
          this.settings.update('autoReload', autoReloadToggle.checked);
        });
      }

      if (resetBtn) {
        resetBtn.addEventListener('click', () => {
          if (confirm('¿Estás seguro de que deseas restaurar todos los ajustes?')) {
            this.settings.reset();
            this.initializeUI();
            this.applySettings();
            this.showResetFeedback(resetBtn);
          }
        });
      }
    }

    applySettings() {
      const accentColor = this.settings.get('accentColor');
      const starsEnabled = this.settings.get('starsEnabled');
      const starsCount = this.settings.get('starsCount');
      const bgOpacity = this.settings.get('bgOpacity');

      document.documentElement.style.setProperty('--accent', accentColor);
      document.documentElement.style.setProperty('--accent-glow', `${accentColor}80`);
      
      const starfieldEl = document.getElementById('starfield');
      if (starfieldEl) {
        starfieldEl.style.display = starsEnabled ? 'block' : 'none';
        
        if (starsEnabled) {
          const currentCount = document.querySelectorAll('.star.layer-1, .star.layer-2, .star.layer-3').length;
          if (Math.abs(currentCount - Math.floor(starsCount * 0.85)) > 15) {
            this.starfield.generate(starsCount);
          }
        }
      }
      
      const opacity = bgOpacity / 100;
      document.documentElement.style.setProperty('--bg-card', `rgba(20, 20, 40, ${opacity * 0.7})`);
      document.documentElement.style.setProperty('--bg-card-header', `rgba(40, 40, 70, ${opacity * 0.85})`);
    }

    showResetFeedback(btn) {
      const originalText = btn.textContent;
      const originalBg = btn.style.background;
      
      btn.textContent = '✓ Restaurado';
      btn.style.background = 'linear-gradient(135deg, #4ade80, #22c55e)';
      
      setTimeout(() => {
        btn.textContent = originalText;
        btn.style.background = originalBg;
      }, 2000);
    }
  }

  // ==================== Interactive Stardust ====================
  class InteractiveStardust {
    constructor() {
      if (window.matchMedia('(hover: hover)').matches && !CONFIG.performance.lowEndDevice) {
        this.init();
      }
    }

    init() {
      let lastCreation = 0;
      document.addEventListener('mousemove', (e) => {
        const now = Date.now();
        if (now - lastCreation > 200 && Math.random() < 0.03) {
          this.createDust(e.clientX, e.clientY);
          lastCreation = now;
        }
      }, { passive: true });
    }

    createDust(x, y) {
      const dust = document.createElement('div');
      dust.className = 'stardust';
      Object.assign(dust.style, {
        left: x + 'px',
        top: y + 'px',
        position: 'fixed',
        animation: 'dustFloat 1.5s ease-out forwards',
        zIndex: '999'
      });
      document.body.appendChild(dust);
      setTimeout(() => dust.remove(), 1500);
    }
  }

  // ==================== Chat Controller (FIXED) ====================
  class ChatController {
    constructor() {
      this.toggle = document.getElementById('chatToggle');
      this.card = document.querySelector('.chat-card');
      this.container = document.querySelector('.container');
      this.iframe = document.getElementById('twitchChat');
      this.isHidden = false;
      this.init();
    }

    init() {
      if (!this.toggle || !this.card || !this.iframe || !this.container) {
        console.warn('❌ Elementos del chat no encontrados');
        return;
      }
      
      console.log('💬 ChatController inicializado correctamente');
      this.toggle.addEventListener('click', () => this.toggleChat());
    }

    toggleChat() {
      this.isHidden = !this.isHidden;
      
      if (this.isHidden) {
        this.card.classList.add('hidden');
        this.container.classList.add('chat-hidden');
        this.toggle.classList.add('rotated');
        this.toggle.innerHTML = `
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
            <path d="M8 11h8M8 15h6"/>
            <path d="M12 5v14"/>
          </svg>`;
        this.toggle.setAttribute('aria-label', 'Mostrar chat');
      } else {
        this.card.classList.remove('hidden');
        this.container.classList.remove('chat-hidden');
        this.toggle.classList.remove('rotated');
        this.toggle.innerHTML = `
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
            <path d="M8 11h8M8 15h6"/>
            <path d="M12 19V5"/>
          </svg>`;
        this.toggle.setAttribute('aria-label', 'Ocultar chat');
      }
      
      console.log(`💬 Chat ${this.isHidden ? 'oculto' : 'visible'}`);
    }
  }

  // ==================== Keyboard Shortcuts ====================
  class KeyboardShortcuts {
    constructor() {
      this.enabled = true;
      this.iframeActive = false;
      this.playerFrame = document.getElementById('playerFrame');
      this.wasInFullscreen = false;
      this.focusIndicator = null;
      this.init();
      this.createFocusIndicator();
    }

    init() {
      this.detectIframeFocus();
      
      document.addEventListener('keydown', (e) => {
        if (this.iframeActive) {
          console.log('🎮 Evento ignorado - Juego activo');
          return;
        }
        this.handleKeydown(e);
      }, true);

      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
          const panel = document.getElementById('customizePanel');
          panel?.classList.remove('active');
        }
      });

      document.addEventListener('fullscreenchange', () => {
        if (!document.fullscreenElement && this.wasInFullscreen) {
          console.log('🔄 Salió de fullscreen - Devolviendo foco al iframe');
          this.refocusIframe();
        }
        this.wasInFullscreen = !!document.fullscreenElement;
      });
    }

    detectIframeFocus() {
      if (!this.playerFrame) return;

      this.playerFrame.addEventListener('mouseenter', () => {
        this.iframeActive = true;
        this.refocusIframe();
        console.log('🎮 Iframe activo - Atajos desactivados');
      });

      this.playerFrame.addEventListener('mouseleave', () => {
        this.iframeActive = false;
        console.log('⌨️  Atajos reactivados');
      });

      document.addEventListener('click', (e) => {
        if (this.playerFrame && !this.playerFrame.contains(e.target)) {
          this.iframeActive = false;
          console.log('⌨️  Click fuera - Atajos reactivados');
        } else if (this.playerFrame && this.playerFrame.contains(e.target)) {
          this.iframeActive = true;
          this.refocusIframe();
          console.log('🎮 Click en iframe - Atajos desactivados');
        }
      }, true);

      window.addEventListener('blur', () => {
        setTimeout(() => {
          this.iframeActive = true;
          console.log('🎮 Window blur - Iframe probablemente activo');
        }, 100);
      });

      window.addEventListener('focus', () => {
        const rect = this.playerFrame.getBoundingClientRect();
        const mouseX = window.lastMouseX || 0;
        const mouseY = window.lastMouseY || 0;
        
        const isOverIframe = (
          mouseX >= rect.left &&
          mouseX <= rect.right &&
          mouseY >= rect.top &&
          mouseY <= rect.bottom
        );

        if (!isOverIframe) {
          this.iframeActive = false;
          console.log('⌨️  Window focus - Atajos reactivados');
        } else {
          this.refocusIframe();
        }
      });

      document.addEventListener('mousemove', (e) => {
        window.lastMouseX = e.clientX;
        window.lastMouseY = e.clientY;
      }, { passive: true });
    }

    refocusIframe() {
      if (!this.playerFrame) return;
      
      try {
        this.playerFrame.focus();
        
        try {
          if (this.playerFrame.contentWindow) {
            this.playerFrame.contentWindow.focus();
          }
        } catch (e) {
          console.log('🔒 Cross-origin, no se puede enfocar contentWindow');
        }
        
        console.log('✅ Foco devuelto al iframe');
      } catch (error) {
        console.warn('⚠️  No se pudo devolver foco:', error);
      }
    }

    handleKeydown(e) {
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) {
        return;
      }

      if ((e.key === 'f' || e.key === 'F') && 
          !e.ctrlKey && !e.metaKey && !e.altKey) {
        e.preventDefault();
        e.stopPropagation();
        this.toggleFullscreen();
        return;
      }
      
      if ((e.ctrlKey || e.metaKey) && e.key === 'r') {
        e.preventDefault();
        e.stopPropagation();
        document.getElementById('reloadBtn')?.click();
        return;
      }
      
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        e.stopPropagation();
        const panel = document.getElementById('customizePanel');
        panel?.classList.toggle('active');
        return;
      }
    }

    toggleFullscreen() {
      if (!this.playerFrame) return;

      if (document.fullscreenElement) {
        document.exitFullscreen();
      } else {
        this.playerFrame.requestFullscreen().catch(err => {
          console.log('Fullscreen error:', err);
        });
      }
    }

    createFocusIndicator() {
      // Implementación existente...
    }
  }

  // ==================== Easter Egg ====================
  class EasterEgg {
    constructor() {
      this.clickCount = 0;
      this.resetTimeout = null;
      this.init();
    }

    init() {
      document.addEventListener('click', () => {
        this.clickCount++;
        clearTimeout(this.resetTimeout);
        
        if (this.clickCount === 7) {
          this.activate();
          this.clickCount = 0;
        } else {
          this.resetTimeout = setTimeout(() => {
            this.clickCount = 0;
          }, 2000);
        }
      });
    }

    activate() {
      console.log('🌟 Easter Egg activado!');
      // Implementación existente...
    }
  }

  // ==================== Visibility API ====================
  class VisibilityController {
    constructor(starfield) {
      this.starfield = starfield;
      this.init();
    }

    init() {
      document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
          this.starfield.pauseAnimations();
        } else {
          this.starfield.resumeAnimations();
        }
      });
    }
  }

  // ==================== Touch Controller ====================
  class TouchController {
    constructor() {
      this.lastTouchEnd = 0;
      this.init();
    }

    init() {
      document.addEventListener('touchend', (e) => {
        const now = Date.now();
        if (now - this.lastTouchEnd <= 300) {
          e.preventDefault();
        }
        this.lastTouchEnd = now;
      }, false);
    }
  }

  // ==================== Initialize Everything (FIXED) ====================
  function init() {
    console.log('🚀 AngulismoTV - Inicialización optimizada con Chat Funcional');

    // 🔥 FASE 1: INMEDIATO - Componentes críticos
    const settingsManager = new SettingsManager(CONFIG.defaults);
    const starfieldEl = document.getElementById('starfield');
    const starfield = new StarfieldGenerator(starfieldEl, CONFIG.starfield);
    
    // 🔥 CHAT CONTROLLER INICIALIZADO INMEDIATAMENTE
    const chatController = new ChatController();
    const settingsUI = new SettingsUI(settingsManager, starfield);
    
    // 🔥 FASE 2: RETRASADO - Componentes de medio impacto
    setTimeout(() => {
      new ParallaxController();
      
      const header = document.querySelector('.site-header');
      if (header) new HeaderStars(header, CONFIG.starfield.headerStars);
      
      new KeyboardShortcuts();
      new VisibilityController(starfield);
      new TouchController();
      
      console.log('✅ Componentes de medio impacto inicializados');
    }, 100);
    
    // 🔥 FASE 3: CON INTERACCIÓN - Componentes de bajo impacto
    let interactionInitialized = false;
    const initOnInteraction = () => {
      if (!interactionInitialized) {
        new InteractiveStardust();
        new EasterEgg();
        interactionInitialized = true;
        console.log('✅ Componentes de bajo impacto inicializados');
      }
    };

    document.addEventListener('mousemove', initOnInteraction, { once: true });
    document.addEventListener('click', initOnInteraction, { once: true });

    // 🔥 Generar estrellas iniciales
    if (settingsManager.get('starsEnabled')) {
      const initialStars = CONFIG.performance.lowEndDevice ? 20 : 30;
      starfield.generate(initialStars);
    }

    console.log('🎯 ChatController funcionando correctamente');
    console.log('⚡ Inicialización por fases completada');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  window.AngulismoTV = window.AngulismoTV || {};
  window.AngulismoTV.getSettings = () => {
    const settings = new SettingsManager(CONFIG.defaults);
    return {
      autoChat: settings.get('autoChat'),
      autoReload: settings.get('autoReload')
    };
  };

})();