/* ==================== SISTEMA DE PELÍCULAS - STUDIO GHIBLI ==================== */

/**
 * CONFIGURACIÓN DE LA API
 * Las películas se cargan dinámicamente desde el Worker de Cloudflare
 */

// ==================== CONFIGURACIÓN ====================
const API_URL = 'https://ghibli.alangulismotv.workers.dev';

// ==================== VARIABLES GLOBALES ====================
let allMovies = []; // Se cargará desde la API
let displayedMovies = []; // Películas actualmente mostradas
let isLoading = false;

// ==================== ELEMENTOS DOM ====================
const peliculasGrid = document.querySelector('.peliculas-grid');
const resultsCount = document.querySelector('.results-count');
const sortSelect = document.querySelector('#sort-select');
const noResultsMessage = document.querySelector('.no-results-message');
const clearSearchMsgBtn = document.querySelector('.clear-search-btn');

// Header Search
const searchTrigger = document.querySelector('#search-trigger');
const headerSearchExpanded = document.querySelector('#header-search-expanded');
const headerSearchInput = document.querySelector('#header-search-input');
const headerSearchClear = document.querySelector('#header-search-clear');
const headerSearchDropdown = document.querySelector('#header-search-dropdown');

// ==================== INICIALIZACIÓN ====================
document.addEventListener('DOMContentLoaded', () => {
  console.log('🎬 Iniciando Studio Ghibli Collection...');
  initializeApp();
});

/**
 * Inicializa la aplicación
 */
async function initializeApp() {
  // Cargar películas desde la API
  await loadMoviesFromAPI();
  
  // Configurar eventos
  setupEventListeners();
  
  // Configurar scroll suave
  setupSmoothScroll();
  
  // Actualizar contador
  updateResultsCount();
  
  console.log(`✅ ${allMovies.length} películas cargadas`);
}

/**
 * Carga películas desde la API del Worker
 */
async function loadMoviesFromAPI() {
  showLoading();
  
  try {
    console.log('📡 Cargando películas desde API...');
    const response = await fetch(`${API_URL}/api/movies`);
    
    if (!response.ok) {
      throw new Error(`Error ${response.status}: ${response.statusText}`);
    }
    
    const movies = await response.json();
    allMovies = movies;
    displayedMovies = [...movies];
    
    // Renderizar películas
    renderMovies(displayedMovies);
    
    console.log(`✅ ${movies.length} películas cargadas desde la API`);
    
  } catch (error) {
    console.error('❌ Error al cargar películas:', error);
    
    // Mostrar error al usuario
    peliculasGrid.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 3rem;">
        <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin: 0 auto 1rem; color: #ff4444;">
          <circle cx="12" cy="12" r="10"></circle>
          <line x1="12" y1="8" x2="12" y2="12"></line>
          <line x1="12" y1="16" x2="12.01" y2="16"></line>
        </svg>
        <h3 style="color: #ff4444; margin-bottom: 1rem; font-size: 1.5rem;">Error al cargar películas</h3>
        <p style="color: rgba(255,255,255,0.7); margin-bottom: 1.5rem; line-height: 1.6;">
          ${error.message}<br><br>
          Verifica que tu Worker esté funcionando en:
        </p>
        <code style="background: rgba(255,255,255,0.1); padding: 0.75rem 1rem; border-radius: 4px; display: inline-block; margin-bottom: 1.5rem; font-family: monospace;">
          ${API_URL}/api/movies
        </code>
        <br>
        <button onclick="location.reload()" style="padding: 0.75rem 1.5rem; background: linear-gradient(135deg, var(--accent), var(--accent-purple)); border: none; border-radius: 8px; color: white; cursor: pointer; font-weight: 600; font-size: 1rem; margin-top: 1rem;">
          🔄 Reintentar
        </button>
      </div>
    `;
    
    // Usar datos vacíos
    allMovies = [];
    displayedMovies = [];
  }
}

// ==================== RENDERIZADO ====================

/**
 * Renderiza las películas en el grid
 * @param {Array} movies - Array de películas a renderizar
 */
function renderMovies(movies) {
  // Limpiar grid
  peliculasGrid.innerHTML = '';
  
  // Ocultar mensaje de sin resultados
  if (noResultsMessage) {
    noResultsMessage.style.display = 'none';
  }
  
  // Si no hay películas
  if (movies.length === 0) {
    showNoResults();
    return;
  }
  
  // Crear cards para cada película
  movies.forEach(movie => {
    const card = createMovieCard(movie);
    peliculasGrid.appendChild(card);
  });
  
  // Actualizar contador
  updateResultsCount();
  
  // Animar entrada de cards
  animateCards();
}

/**
 * Crea una tarjeta de película
 * @param {Object} movie - Objeto con datos de la película
 * @returns {HTMLElement} - Elemento de tarjeta
 */
function createMovieCard(movie) {
  const card = document.createElement('article');
  card.className = 'movie-card';
  card.setAttribute('data-movie-id', movie.id);
  card.setAttribute('role', 'button');
  card.setAttribute('tabindex', '0');
  card.setAttribute('aria-label', `Ver detalles de ${movie.title}`);
  
  const durationHTML = movie.duration ? 
    `<span class="movie-duration">${movie.duration} min</span>` : '';
  
  card.innerHTML = `
    <div class="movie-poster-container">
      <img 
        src="${movie.poster}" 
        alt="Poster de ${movie.title}"
        class="movie-poster"
        loading="lazy"
        onerror="this.src='assets/placeholder.jpg'"
      >
      <div class="movie-overlay">
        <p class="movie-year">${movie.year}</p>
        <p class="quick-info">${movie.description}</p>
      </div>
    </div>
    <div class="movie-info">
      <h3 class="movie-title">${movie.title}</h3>
      <p class="movie-year">${movie.year}</p>
      <p class="movie-director">Director: ${movie.director}</p>
      ${durationHTML}
    </div>
  `;
  
  // Event listener para click
  card.addEventListener('click', () => handleMovieClick(movie));
  
  // Event listener para teclado (accesibilidad)
  card.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      handleMovieClick(movie);
    }
  });
  
  return card;
}

/**
 * Maneja el click en una película
 * @param {Object} movie - Datos de la película clickeada
 */
function handleMovieClick(movie) {
  console.log('🎬 Abriendo película:', movie.title);
  
  // Navegar a la página de reproducción
  window.location.href = `watch.html?id=${movie.id}`;
}

/**
 * Muestra mensaje de "sin resultados"
 */
function showNoResults() {
  peliculasGrid.innerHTML = '';
  if (noResultsMessage) {
    noResultsMessage.style.display = 'block';
  }
  updateResultsCount();
}

/**
 * Muestra estado de carga
 */
function showLoading() {
  peliculasGrid.innerHTML = `
    <div class="loading-state">
      <div class="loading-spinner"></div>
      <p>Cargando películas desde la API...</p>
    </div>
  `;
}

/**
 * Anima la entrada de las cards
 */
function animateCards() {
  const cards = document.querySelectorAll('.movie-card');
  cards.forEach((card, index) => {
    card.style.animation = `fadeInUp 0.5s ease forwards ${index * 50}ms`;
  });
}

// ==================== BÚSQUEDA ====================

/**
 * Configura los event listeners
 */
function setupEventListeners() {
  // Abrir búsqueda en header
  if (searchTrigger) {
    searchTrigger.addEventListener('click', toggleHeaderSearch);
  }
  
  // Búsqueda en tiempo real
  if (headerSearchInput) {
    headerSearchInput.addEventListener('input', debounce(handleHeaderSearch, 300));
    headerSearchInput.addEventListener('input', toggleClearButtonHeader);
  }
  
  // Limpiar búsqueda
  if (headerSearchClear) {
    headerSearchClear.addEventListener('click', clearHeaderSearch);
  }
  
  // Cerrar búsqueda con ESC
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && headerSearchExpanded && headerSearchExpanded.classList.contains('active')) {
      closeHeaderSearch();
    }
  });
  
  // Cerrar búsqueda al hacer click fuera
  document.addEventListener('click', (e) => {
    if (headerSearchExpanded && headerSearchExpanded.classList.contains('active')) {
      if (!headerSearchExpanded.contains(e.target) && !searchTrigger.contains(e.target)) {
        closeHeaderSearch();
      }
    }
  });
  
  // Botón de limpiar búsqueda (en mensaje de sin resultados)
  if (clearSearchMsgBtn) {
    clearSearchMsgBtn.addEventListener('click', () => {
      clearHeaderSearch();
      closeHeaderSearch();
    });
  }
  
  // Select de ordenamiento
  if (sortSelect) {
    sortSelect.addEventListener('change', handleSortChange);
  }
}

/**
 * Limpia la búsqueda
 */
function clearSearch() {
  clearHeaderSearch();
}

/**
 * Actualiza el contador de resultados
 */
function updateResultsCount() {
  if (resultsCount) {
    const count = displayedMovies.length;
    const total = allMovies.length;
    
    if (count === 0) {
      resultsCount.textContent = 'Sin resultados';
    } else if (count === total) {
      resultsCount.textContent = `${total} ${total === 1 ? 'película' : 'películas'}`;
    } else {
      resultsCount.textContent = `${count} de ${total} películas`;
    }
  }
}

/**
 * Maneja el cambio en el select de ordenamiento
 */
function handleSortChange() {
  if (!sortSelect) return;
  
  const value = sortSelect.value;
  const [criteria, order] = value.split('-');
  
  sortMovies(criteria, order);
  console.log(`🔄 Ordenado por ${criteria} (${order})`);
}

// ==================== BÚSQUEDA EN HEADER ====================

/**
 * Abre/cierra la búsqueda en el header
 */
function toggleHeaderSearch() {
  if (!headerSearchExpanded) return;
  
  if (headerSearchExpanded.classList.contains('active')) {
    closeHeaderSearch();
  } else {
    openHeaderSearch();
  }
}

/**
 * Abre la búsqueda en el header
 */
function openHeaderSearch() {
  if (!headerSearchExpanded) return;
  
  headerSearchExpanded.classList.add('active');
  setTimeout(() => {
    if (headerSearchInput) headerSearchInput.focus();
  }, 100);
  
  showDropdownHint();
  console.log('🔍 Búsqueda abierta');
}

/**
 * Cierra la búsqueda en el header
 */
function closeHeaderSearch() {
  if (!headerSearchExpanded) return;
  
  headerSearchExpanded.classList.remove('active');
  if (headerSearchDropdown) {
    headerSearchDropdown.classList.remove('active');
  }
  
  console.log('❌ Búsqueda cerrada');
}

/**
 * Muestra hint inicial en dropdown
 */
function showDropdownHint() {
  if (!headerSearchDropdown) return;
  
  headerSearchDropdown.innerHTML = `
    <p class="search-dropdown-hint">Escribe para buscar películas...</p>
  `;
  headerSearchDropdown.classList.remove('active');
}

/**
 * Maneja la búsqueda en el header
 */
function handleHeaderSearch() {
  const query = headerSearchInput ? headerSearchInput.value.trim().toLowerCase() : '';
  
  if (query === '') {
    showDropdownHint();
    return;
  }
  
  // Filtrar películas
  const results = allMovies.filter(movie => {
    return (
      movie.title.toLowerCase().includes(query) ||
      (movie.original_title && movie.original_title.toLowerCase().includes(query)) ||
      movie.director.toLowerCase().includes(query) ||
      movie.description.toLowerCase().includes(query) ||
      movie.year.toString().includes(query)
    );
  });
  
  // Mostrar resultados en dropdown
  showDropdownResults(results, query);
}

/**
 * Muestra los resultados en el dropdown
 */
function showDropdownResults(results, query) {
  if (!headerSearchDropdown) return;
  
  if (results.length === 0) {
    headerSearchDropdown.innerHTML = `
      <p class="search-dropdown-hint">No se encontraron resultados</p>
    `;
    headerSearchDropdown.classList.add('active');
    return;
  }
  
  const maxResults = 5;
  const resultsHTML = `
    <p class="search-dropdown-count">${results.length} ${results.length === 1 ? 'resultado' : 'resultados'}</p>
    ${results.slice(0, maxResults).map(movie => `
      <div class="search-dropdown-item" data-movie-id="${movie.id}" data-query="${query}">
        <img 
          src="${movie.poster}" 
          alt="${movie.title}"
          class="search-dropdown-poster"
          onerror="this.src='assets/placeholder.jpg'"
        >
        <div class="search-dropdown-info">
          <div class="search-dropdown-title">${movie.title}</div>
          <div class="search-dropdown-meta">
            <span class="search-dropdown-year">${movie.year}</span> · ${movie.director}
          </div>
        </div>
      </div>
    `).join('')}
    ${results.length > maxResults ? `<p class="search-dropdown-more">+ ${results.length - maxResults} más</p>` : ''}
  `;
  
  headerSearchDropdown.innerHTML = resultsHTML;
  headerSearchDropdown.classList.add('active');
  
  // Agregar event listeners a los items
  document.querySelectorAll('.search-dropdown-item').forEach(item => {
    item.addEventListener('click', () => {
      const query = item.getAttribute('data-query');
      applySearchFilter(query);
    });
  });
}

/**
 * Aplica el filtro de búsqueda al catálogo
 */
function applySearchFilter(query) {
  // Cerrar dropdown
  closeHeaderSearch();
  
  // Filtrar películas
  displayedMovies = allMovies.filter(movie => {
    return (
      movie.title.toLowerCase().includes(query) ||
      (movie.original_title && movie.original_title.toLowerCase().includes(query)) ||
      movie.director.toLowerCase().includes(query) ||
      movie.description.toLowerCase().includes(query) ||
      movie.year.toString().includes(query)
    );
  });
  
  // Renderizar
  renderMovies(displayedMovies);
  
  // Scroll a películas
  const moviesSection = document.querySelector('#peliculas');
  if (moviesSection) {
    moviesSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  
  console.log(`✅ Filtrado: ${displayedMovies.length} resultados para "${query}"`);
}

/**
 * Limpia la búsqueda del header
 */
function clearHeaderSearch() {
  if (headerSearchInput) {
    headerSearchInput.value = '';
  }
  
  displayedMovies = [...allMovies];
  renderMovies(displayedMovies);
  showDropdownHint();
  toggleClearButtonHeader();
  
  console.log('🧹 Búsqueda limpiada');
}

/**
 * Muestra/oculta el botón de limpiar en header
 */
function toggleClearButtonHeader() {
  if (headerSearchClear && headerSearchInput) {
    headerSearchClear.style.display = headerSearchInput.value ? 'flex' : 'none';
  }
}

// ==================== UTILIDADES ====================

/**
 * Debounce function para optimizar búsqueda
 * @param {Function} func - Función a ejecutar
 * @param {Number} wait - Tiempo de espera en ms
 * @returns {Function}
 */
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

/**
 * Configura scroll suave para los enlaces de navegación
 */
function setupSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });
}

/**
 * Ordena películas por criterio
 * @param {String} criteria - 'year', 'title', 'director'
 * @param {String} order - 'asc' o 'desc'
 */
function sortMovies(criteria = 'year', order = 'desc') {
  displayedMovies.sort((a, b) => {
    let comparison = 0;
    
    if (criteria === 'year') {
      comparison = a.year - b.year;
    } else if (criteria === 'title') {
      comparison = a.title.localeCompare(b.title);
    } else if (criteria === 'director') {
      comparison = a.director.localeCompare(b.director);
    }
    
    return order === 'asc' ? comparison : -comparison;
  });
  
  renderMovies(displayedMovies);
  console.log(`🔄 Películas ordenadas por ${criteria} (${order})`);
}

/**
 * Filtra películas por año
 * @param {Number} year - Año a filtrar
 */
function filterByYear(year) {
  displayedMovies = allMovies.filter(movie => movie.year === year);
  renderMovies(displayedMovies);
  console.log(`📅 Filtrado por año: ${year}`);
}

/**
 * Filtra películas por director
 * @param {String} director - Director a filtrar
 */
function filterByDirector(director) {
  displayedMovies = allMovies.filter(movie => 
    movie.director.toLowerCase().includes(director.toLowerCase())
  );
  renderMovies(displayedMovies);
  console.log(`🎬 Filtrado por director: ${director}`);
}

/**
 * Obtiene película por ID
 * @param {Number} id - ID de la película
 * @returns {Object|null}
 */
function getMovieById(id) {
  return allMovies.find(movie => movie.id === id) || null;
}

/**
 * Recarga películas desde la API
 */
async function reloadMovies() {
  console.log('🔄 Recargando películas...');
  await loadMoviesFromAPI();
}

// ==================== API DE CONSOLA (para testing) ====================
// Exponer funciones útiles en consola para desarrollo
window.GhibliApp = {
  movies: () => allMovies,
  displayed: () => displayedMovies,
  sort: sortMovies,
  filterYear: filterByYear,
  filterDirector: filterByDirector,
  getMovie: getMovieById,
  clear: clearSearch,
  reload: reloadMovies,
  api: API_URL
};

console.log('💡 Tip: Usa GhibliApp en la consola para interactuar con la app');
console.log('Ejemplo: GhibliApp.reload() - Recarga películas desde la API');
console.log(`API URL: ${API_URL}`);

// ==================== FIN DEL SCRIPT ====================