// ========================================
// SISTEMA DE ROLES AUTOMÁTICOS Y MODERACIÓN
// CON SOPORTE DE RESPUESTAS ✅
// ========================================

console.log('🎮 Cargando sistema de roles automáticos y moderación...');

// ========================================
// ESTADO GLOBAL EXTENDIDO
// ========================================

const ModeracionState = {
    miRol: null,
    miIpHash: null,
    esModeradorOMas: false,
    esAdmin: false,
    rangos: []
};

// ========================================
// INICIALIZAR SISTEMA
// ========================================

async function inicializarSistemaRoles() {
    try {
        // Cargar rangos disponibles
        const response = await fetch(`${CONFIG.API_URL}/rangos`);
        if (response.ok) {
            const data = await response.json();
            ModeracionState.rangos = data;
        }
        
        // Detectar rol del usuario actual
        await detectarMiRol();
        
        console.log('✅ Sistema de roles inicializado');
        console.log('Mi rol:', ModeracionState.miRol);
        console.log('Rangos disponibles:', ModeracionState.rangos.length);
    } catch (error) {
        console.error('Error inicializando sistema de roles:', error);
    }
}

async function detectarMiRol() {
    try {
        const response = await fetch(`${CONFIG.API_URL}/mensajes?limit=50`);
        if (!response.ok) return;
        
        const data = await response.json();
        const nombreActual = localStorage.getItem('foroNombre');
        
        // Buscar mis mensajes más recientes
        const misMensajes = data.mensajes.filter(m => m.nombre === nombreActual);
        
        if (misMensajes.length > 0) {
            const ultimoMensaje = misMensajes[0];
            ModeracionState.miRol = ultimoMensaje.rol || 'usuario';
            ModeracionState.miIpHash = ultimoMensaje.usuario_ip_hash;
            ModeracionState.esModeradorOMas = ['moderador', 'admin'].includes(ModeracionState.miRol);
            ModeracionState.esAdmin = ModeracionState.miRol === 'admin';
        }
    } catch (error) {
        console.error('Error detectando rol:', error);
    }
}

// ========================================
// ACTUALIZAR crearHTMLMensaje CON RANGOS + RESPUESTAS ✅
// ========================================

// Guardar función original si no está guardada
if (typeof window.crearHTMLMensajeOriginalRoles === 'undefined') {
    window.crearHTMLMensajeOriginalRoles = crearHTMLMensaje;
}

function crearHTMLMensaje(msg) {
    const fechaFormateada = formatearFecha ? formatearFecha(msg.fecha) : new Date(msg.fecha).toLocaleString();
    
    // ========================================
    // COLORES DISTINTIVOS
    // ========================================
    
    const avatarStyle = msg.color_distintivo 
        ? `style="background: ${msg.color_distintivo}"` 
        : '';
    
    // ========================================
    // BADGE DE ROL MANUAL
    // ========================================
    
    let badgeRol = '';
    if (msg.rol && msg.rol !== 'usuario') {
        const iconoRol = msg.rol === 'admin' ? '👑' : msg.rol === 'moderador' ? '🛡️' : '';
        badgeRol = `<span class="rol-badge rol-${msg.rol}" title="Rol: ${msg.rol}">
             <span class="rol-icon">${iconoRol}</span>
             <span class="rol-text">${msg.rol}</span>
           </span>`;
    }
    
    // ========================================
    // 🔥 BADGE DE RANGO DE ACTIVIDAD
    // ========================================
    
    let badgeRango = '';
    if (msg.rango_actividad) {
        const rango = msg.rango_actividad;
        badgeRango = `<span class="rango-badge" 
                          style="color: ${rango.color}" 
                          title="${rango.descripcion}">
             <span class="rango-icon">${rango.icono}</span>
             <span class="rango-text">${rango.nombre}</span>
           </span>`;
    }
    
    // ========================================
    // BADGES DE LOGROS
    // ========================================
    
    let badgesHTML = '';
    if (msg.badges_count && msg.badges_count > 0) {
        badgesHTML = `<span class="badges-count" title="${msg.badges_count} badges">🎖️${msg.badges_count}</span>`;
    }
    
    // ========================================
    // MENSAJE FIJADO
    // ========================================
    
    const fijadoClass = msg.fijado ? 'mensaje-fijado' : '';
    const fijadoIcon = msg.fijado ? '<span class="icono-fijado" title="Mensaje fijado">📌</span>' : '';
    
    // ========================================
    // BADGE EDITADO
    // ========================================
    
    const editadoBadge = msg.editado ? '<span class="badge-editado">(editado)</span>' : '';
    
    // ========================================
    // GENERAR AVATAR
    // ========================================
    
    let avatarHTML = '';
    if (msg.avatar) {
        try {
            if (typeof msg.avatar === 'string' && msg.avatar.includes('<')) {
                avatarHTML = msg.avatar;
            } else {
                const iniciales = msg.nombre.substring(0, 2).toUpperCase();
                avatarHTML = `<div class="avatar" ${avatarStyle}>${iniciales}</div>`;
            }
        } catch (e) {
            const iniciales = msg.nombre.substring(0, 2).toUpperCase();
            avatarHTML = `<div class="avatar" ${avatarStyle}>${iniciales}</div>`;
        }
    } else {
        const iniciales = msg.nombre.substring(0, 2).toUpperCase();
        avatarHTML = `<div class="avatar" ${avatarStyle}>${iniciales}</div>`;
    }
    
    // ========================================
    // ✅ NUEVO: PROCESAR RESPUESTA SI EXISTE
    // ========================================
    
    let respuestaHTML = '';
    if (msg.respuesta_a && msg.respuesta_info) {
        const respInfo = msg.respuesta_info;
        const textoAcortado = respInfo.mensaje && respInfo.mensaje.length > 80 
            ? respInfo.mensaje.substring(0, 80) + '...' 
            : (respInfo.mensaje || '');
        
        respuestaHTML = `
            <div class="respuesta-referencia" onclick="scrollToMensaje('${msg.respuesta_a}')">
                <div class="respuesta-icono">↪</div>
                <div class="respuesta-content">
                    <div class="respuesta-autor">En respuesta a <strong>${escapeHTML(respInfo.nombre)}</strong></div>
                    <div class="respuesta-preview">${escapeHTML(textoAcortado)}</div>
                </div>
            </div>
        `;
    }
    
    // ========================================
    // FORMATEAR MENSAJE
    // ========================================
    
    const mensajeFormateado = typeof formatearMensaje !== 'undefined' 
        ? formatearMensaje(msg.mensaje) 
        : (typeof escapeHTML !== 'undefined' ? escapeHTML(msg.mensaje) : msg.mensaje);
    
    // ========================================
    // PROCESAR MULTIMEDIA
    // ========================================
    
    let multimediaHTML = '';
    if (msg.multimedia) {
        try {
            const multimedia = JSON.parse(msg.multimedia);
            if (typeof generarHTMLMultimedia !== 'undefined') {
                multimediaHTML = generarHTMLMultimedia(multimedia);
            }
        } catch (e) {
            console.error('Error parseando multimedia:', e);
        }
    }
    
    // ========================================
    // 🔥 BOTONES DE MODERACIÓN
    // ========================================
    
    let botonesModeracion = '';
    
    if (ModeracionState.esModeradorOMas) {
        // Botón de fijar/desfijar
        const textoFijar = msg.fijado ? 'Desfijar' : 'Fijar';
        const iconoFijar = msg.fijado ? '📌❌' : '📌';
        botonesModeracion += `
            <button class="btn-moderacion btn-fijar" onclick="toggleFijarMensaje('${msg.id}', ${msg.fijado ? 'true' : 'false'})" title="${textoFijar} mensaje">
                ${iconoFijar}
            </button>
        `;
        
        // Botón de eliminar (solo si no es su propio mensaje)
        const nombreActual = localStorage.getItem('foroNombre');
        if (msg.nombre !== nombreActual) {
            botonesModeracion += `
                <button class="btn-moderacion btn-eliminar-mod" onclick="eliminarComoModerador('${msg.id}', '${escapeHTML(msg.nombre).replace(/'/g, "\\'")}')">
                    🗑️ Eliminar
                </button>
            `;
        }
    }
    
    // ========================================
    // HTML DEL MENSAJE
    // ========================================
    
    const nombreEscaped = typeof escapeHTML !== 'undefined' ? escapeHTML(msg.nombre) : msg.nombre;
    const mensajeEscaped = typeof escapeHTML !== 'undefined' ? escapeHTML(msg.mensaje) : msg.mensaje;
    
    let html = `
        <div class="mensaje-item ${fijadoClass}" data-id="${msg.id}" id="mensaje-${msg.id}" data-rol="${msg.rol || 'usuario'}" data-respuesta="${msg.respuesta_a || ''}">
            ${fijadoIcon}
            <div class="mensaje-avatar">${avatarHTML}</div>
            <div class="mensaje-content">
                <div class="mensaje-header">
                    <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                        <span class="mensaje-nombre">${nombreEscaped}</span>
                        ${badgeRol}
                        ${badgeRango}
                        ${badgesHTML}
                        ${editadoBadge}
                    </div>
                    <span class="mensaje-fecha">${fechaFormateada}</span>
                </div>
                
                ${respuestaHTML}
                
                <div class="mensaje-texto">${mensajeFormateado}</div>
                
                ${multimediaHTML}
                
                <div class="mensaje-acciones">
                    <button class="btn-responder" onclick="seleccionarMensaje('${msg.id}', '${nombreEscaped.replace(/'/g, "\\'")}', '${mensajeEscaped.replace(/'/g, "\\'")}', event)">
                        &#8627; Responder
                    </button>
                    <div class="reacciones-container" id="reacciones-${msg.id}"></div>
                    <button class="btn-reaccion" onclick="mostrarMenuReacciones('${msg.id}', event)">
                        Reaccionar
                    </button>
                    ${botonesModeracion}
                </div>
            </div>
        </div>
    `;
    
    return html;
}

// ========================================
// 🔥 FUNCIONES DE MODERACIÓN
// ========================================

async function toggleFijarMensaje(mensajeId, estaFijado) {
    if (!ModeracionState.esModeradorOMas) {
        mostrarAlerta('No tienes permisos para fijar mensajes', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${CONFIG.API_URL}/mensajes/${mensajeId}/fijar`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
        
        const resultado = await response.json();
        
        if (response.ok && resultado.success) {
            const accion = resultado.fijado ? 'fijado' : 'desfijado';
            mostrarAlerta(`Mensaje ${accion} correctamente`, 'success');
            await cargarMensajes();
        } else {
            mostrarAlerta(resultado.error || 'Error al fijar mensaje', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        mostrarAlerta('Error de conexión', 'error');
    }
}

async function eliminarComoModerador(mensajeId, nombreUsuario) {
    if (!ModeracionState.esModeradorOMas) {
        mostrarAlerta('No tienes permisos para eliminar mensajes', 'error');
        return;
    }
    
    const confirmacion = confirm(`¿Estás seguro de eliminar el mensaje de ${nombreUsuario}?`);
    if (!confirmacion) return;
    
    const razon = prompt('Razón de la eliminación (opcional):');
    
    try {
        const response = await fetch(`${CONFIG.API_URL}/moderacion/mensajes/${mensajeId}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ razon })
        });
        
        const resultado = await response.json();
        
        if (response.ok && resultado.success) {
            mostrarAlerta('Mensaje eliminado correctamente', 'success');
            await cargarMensajes();
        } else {
            mostrarAlerta(resultado.error || 'Error al eliminar mensaje', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        mostrarAlerta('Error de conexión', 'error');
    }
}

async function banearUsuario(ipHash, nombreUsuario) {
    if (!ModeracionState.esAdmin) {
        mostrarAlerta('Solo administradores pueden banear usuarios', 'error');
        return;
    }
    
    const confirmacion = confirm(`¿Estás seguro de banear a ${nombreUsuario}?`);
    if (!confirmacion) return;
    
    const razon = prompt('Razón del ban:');
    if (!razon) return;
    
    const dias = prompt('Duración en días (deja vacío para permanente):');
    const permanente = !dias || dias.trim() === '';
    
    try {
        const response = await fetch(`${CONFIG.API_URL}/moderacion/ban`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                ip_hash: ipHash,
                razon: razon,
                duracion_dias: permanente ? null : parseInt(dias),
                permanente: permanente
            })
        });
        
        const resultado = await response.json();
        
        if (response.ok && resultado.success) {
            mostrarAlerta('Usuario baneado correctamente', 'success');
        } else {
            mostrarAlerta(resultado.error || 'Error al banear usuario', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        mostrarAlerta('Error de conexión', 'error');
    }
}

// ========================================
// EXPORTAR FUNCIONES
// ========================================

window.toggleFijarMensaje = toggleFijarMensaje;
window.eliminarComoModerador = eliminarComoModerador;
window.banearUsuario = banearUsuario;

// ========================================
// INICIALIZAR AL CARGAR
// ========================================

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', async () => {
        await inicializarSistemaRoles();
    });
} else {
    (async () => {
        await inicializarSistemaRoles();
    })();
}

console.log('✅ Sistema de roles automáticos y moderación cargado (CON RESPUESTAS)');