// ========================================
// SISTEMA DE AUTENTICACIÓN v2.9 - SESIÓN PERMANENTE
// ✅ TODAS LAS SESIONES SON PERMANENTES (sin checkbox)
// ✅ FIX: Token y datos de usuario se guardan en localStorage
// ========================================

console.log('🔐 Sistema de autenticación v2.9 cargando...');

// ========================================
// ESTADO DE AUTENTICACIÓN
// ========================================

const AuthState = {
    token: localStorage.getItem('authToken') || null,
    user: null,
    isAuthenticated: false,
    loading: false,
    rememberMe: true // Siempre true
};

// ========================================
// CONSTANTES
// ========================================

const AUTH_CONFIG = {
    USERNAME_MIN: 3,
    USERNAME_MAX: 20,
    PASSWORD_MIN: 8,
    USERNAME_PATTERN: /^[a-zA-Z0-9_-]+$/,
    EMAIL_PATTERN: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    SESSION_CHECK_INTERVAL: 60000
};

// ========================================
// RATE LIMITER
// ========================================

let sessionCheckInterval = null;

const rateLimiter = {
    attempts: {},
    maxAttempts: 5,
    windowMs: 900000,
    
    canAttempt(action) {
        const now = Date.now();
        const key = action;
        
        if (!this.attempts[key]) {
            this.attempts[key] = [];
        }
        
        this.attempts[key] = this.attempts[key].filter(time => now - time < this.windowMs);
        
        if (this.attempts[key].length >= this.maxAttempts) {
            const oldestAttempt = this.attempts[key][0];
            const waitTime = Math.ceil((this.windowMs - (now - oldestAttempt)) / 1000 / 60);
            return { allowed: false, waitTime };
        }
        
        this.attempts[key].push(now);
        return { allowed: true };
    },
    
    reset(action) {
        delete this.attempts[action];
    }
};

// ========================================
// INICIALIZACIÓN
// ========================================

async function inicializarAuth() {
    cargarSesionGuardada();
    
    if (AuthState.token) {
        AuthState.loading = true;
        const valido = await verificarSesion();
        AuthState.loading = false;
        
        if (valido) {
            mostrarUsuarioLogueado();
            iniciarVerificacionSesion();
            mostrarEstadoConexion(true);
            
            // Sincronizar avatar inmediatamente
            setTimeout(() => sincronizarTodoInmediatamente(AuthState.user), 100);
        } else {
            cerrarSesionLocal();
        }
    } else {
        mostrarBotonesLogin();
    }
    
    window.addEventListener('online', () => {
        mostrarEstadoConexion(true);
        mostrarAlerta('Conexión restablecida ✓', 'success');
    });
    
    window.addEventListener('offline', () => {
        mostrarEstadoConexion(false);
        mostrarAlerta('Sin conexión a internet', 'warning');
    });
}

// ========================================
// FUNCIONES DE SESIÓN
// ========================================

function cargarSesionGuardada() {
    // ✅ SIEMPRE buscar en localStorage (sesión permanente)
    let token = localStorage.getItem('authToken');
    let userStr = localStorage.getItem('user');
    const remember = true; // Siempre true
    
    AuthState.token = token;
    AuthState.rememberMe = remember;
    
    if (userStr) {
        try {
            AuthState.user = JSON.parse(userStr);
            AuthState.isAuthenticated = !!token;
            console.log('✅ Sesión cargada:', AuthState.user.username, '(permanente)');
        } catch (e) {
            console.error('❌ Error parsing user:', e);
            AuthState.user = null;
            AuthState.isAuthenticated = false;
            AuthState.token = null;
        }
    } else {
        AuthState.user = null;
        AuthState.isAuthenticated = false;
    }
}

function guardarSesion(token, user, remember = true) {
    // ✅ SIEMPRE guardar en localStorage (sesión permanente)
    localStorage.setItem('authToken', token);
    localStorage.setItem('user', JSON.stringify(user));
    localStorage.setItem('username', user.username);
    localStorage.setItem('userId', user.id);
    localStorage.setItem('userRole', user.rol);
    localStorage.setItem('rememberMe', 'true');
    
    // Limpiar sessionStorage por si acaso
    sessionStorage.removeItem('authToken');
    sessionStorage.removeItem('user');
    sessionStorage.removeItem('username');
    sessionStorage.removeItem('userId');
    sessionStorage.removeItem('userRole');
    
    AuthState.token = token;
    AuthState.user = user;
    AuthState.isAuthenticated = true;
    AuthState.rememberMe = true;
    
    console.log('💾 Sesión PERMANENTE guardada');
}

function iniciarVerificacionSesion() {
    if (sessionCheckInterval) clearInterval(sessionCheckInterval);
    
    sessionCheckInterval = setInterval(async () => {
        if (AuthState.isAuthenticated && AuthState.token) {
            const valida = await verificarSesion();
            if (!valida) {
                cerrarSesionLocal();
                mostrarAlerta('Tu sesión ha expirado. Por favor, inicia sesión nuevamente.', 'warning');
            }
        }
    }, AUTH_CONFIG.SESSION_CHECK_INTERVAL);
}

async function verificarSesion() {
    try {
        const response = await fetch(`${CONFIG.API_URL}/auth/me`, {
            headers: {
                'Authorization': `Bearer ${AuthState.token}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            AuthState.user = data.user;
            AuthState.isAuthenticated = true;
            
            // ✅ SIEMPRE usar localStorage
            localStorage.setItem('user', JSON.stringify(data.user));
            
            return true;
        }
        
        return false;
    } catch (error) {
        console.error('Error verificando sesión:', error);
        return false;
    }
}

// ========================================
// UI - CONEXIÓN Y UTILIDADES
// ========================================

function mostrarEstadoConexion(conectado) {
    let indicator = document.getElementById('connection-indicator');
    
    if (!indicator) {
        indicator = document.createElement('div');
        indicator.id = 'connection-indicator';
        indicator.className = 'connection-indicator';
        indicator.title = conectado ? 'Conectado' : 'Sin conexión';
        document.body.appendChild(indicator);
    }
    
    if (conectado) {
        indicator.className = 'connection-indicator online';
        indicator.title = 'Conectado';
    } else {
        indicator.className = 'connection-indicator offline';
        indicator.title = 'Sin conexión';
    }
}

function togglePasswordVisibility(inputId) {
    const input = document.getElementById(inputId);
    if (!input) return;
    
    const btn = input.parentElement.querySelector('.btn-toggle-password');
    
    if (input.type === 'password') {
        input.type = 'text';
        if (btn) btn.textContent = '🙈';
    } else {
        input.type = 'password';
        if (btn) btn.textContent = '👁️';
    }
}

function cerrarModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.remove();
        document.body.style.overflow = 'auto';
    }
}

function escapeHTML(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

function generarAvatarURL(username) {
    const encoded = encodeURIComponent(username);
    return `https://ui-avatars.com/api/?name=${encoded}&background=random&size=128&bold=true`;
}

// ========================================
// UI - MOSTRAR BOTONES DE LOGIN
// ========================================

function mostrarBotonesLogin() {
    const container = document.getElementById('auth-container');
    if (!container) return;
    
    container.innerHTML = `
        <button class="btn-auth btn-login" onclick="abrirModalLogin()" aria-label="Iniciar sesión">
            <span class="btn-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24">
  <rect x="5" y="11" width="14" height="11" rx="2" ry="2"/>
  <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
</svg></span>
            <span class="btn-text">Iniciar Sesión</span>
        </button>
        <button class="btn-auth btn-register" onclick="abrirModalRegistro()" aria-label="Registrarse">
            <span class="btn-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24">
  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
  <polyline points="14 2 14 8 20 8"/>
  <line x1="16" y1="13" x2="8" y2="13"/>
  <line x1="16" y1="17" x2="8" y2="17"/>
  <polyline points="10 9 9 9 8 9"/>
</svg></span>
            <span class="btn-text">Registrarse</span>
        </button>
    `;
}

// ========================================
// UI - MOSTRAR USUARIO LOGUEADO
// ========================================

function mostrarUsuarioLogueado() {
    const container = document.getElementById('auth-container');
    if (!container || !AuthState.user) return;
    
    const avatar = AuthState.user.avatar_url || generarAvatarURL(AuthState.user.username);
    const username = escapeHTML(AuthState.user.username);
    
    container.innerHTML = `
        <div class="user-logged" onclick="toggleProfileMenu()" style="cursor: pointer;" aria-label="Abrir menú de perfil" title="Abrir menú de perfil">
            <img src="${avatar}" 
                 class="user-avatar" 
                 alt="Avatar de ${username}"
                 onerror="this.src='${generarAvatarURL(username)}'">
            <span class="user-username">@${username}</span>
        </div>
    `;
}

// ========================================
// MODAL DE LOGIN
// ========================================

function abrirModalLogin() {
    const modal = document.createElement('div');
    modal.className = 'modal-auth';
    modal.id = 'modal-login';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-labelledby', 'modal-login-title');
    modal.setAttribute('aria-modal', 'true');
    
    modal.innerHTML = `
        <div class="modal-auth-content">
            <button class="btn-cerrar-modal" 
                    onclick="cerrarModal('modal-login')" 
                    aria-label="Cerrar modal">
                &times;
            </button>
            <h2 id="modal-login-title">Iniciar Sesión</h2>
            <form id="form-login" onsubmit="handleLoginSubmit(event)" novalidate>
                <div class="form-group">
                    <label for="login-email">📧 Email</label>
                    <input type="email" 
                           id="login-email" 
                           required 
                           placeholder="tu@email.com"
                           autocomplete="email"
                           aria-required="true">
                    <span class="field-error" role="alert"></span>
                </div>
                <div class="form-group">
                    <label for="login-password">🔒 Contraseña</label>
                    <div class="password-input-wrapper">
                        <input type="password" 
                               id="login-password" 
                               required 
                               placeholder="••••••••"
                               autocomplete="current-password"
                               aria-required="true">
                        <button type="button" class="btn-toggle-password" onclick="togglePasswordVisibility('login-password')" aria-label="Mostrar contraseña">
                            👁️
                        </button>
                    </div>
                    <span class="field-error" role="alert"></span>
                </div>
                <div id="login-error" class="error-message" role="alert" aria-live="polite"></div>
                <button type="submit" class="btn-submit">
                    Entrar
                </button>
            </form>
            <p class="modal-footer" style="margin-top: 12px;">
                <a href="#" onclick="cerrarModal('modal-login'); abrirModalRecuperacion(); return false;">
                    ¿Olvidaste tu contraseña?
                </a>
            </p>
            <p class="modal-footer">
                ¿No tenés cuenta? 
                <a href="#" onclick="cerrarModal('modal-login'); abrirModalRegistro(); return false;">
                    Regístrate acá
                </a>
            </p>
        </div>
    `;
    
    document.body.appendChild(modal);
    document.body.style.overflow = 'hidden';
    
    setTimeout(() => {
        const emailInput = document.getElementById('login-email');
        if (emailInput) emailInput.focus();
    }, 150);
    
    modal.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') cerrarModal('modal-login');
    });
}

async function handleLoginSubmit(event) {
    event.preventDefault();
    
    const rateLimitCheck = rateLimiter.canAttempt('login');
    if (!rateLimitCheck.allowed) {
        const errorDiv = document.getElementById('login-error');
        errorDiv.textContent = `Demasiados intentos. Espera ${rateLimitCheck.waitTime} minutos.`;
        return;
    }
    
    const form = event.target;
    const emailInput = document.getElementById('login-email');
    const passwordInput = document.getElementById('login-password');
    const errorDiv = document.getElementById('login-error');
    const submitBtn = form.querySelector('button[type="submit"]');
    
    const email = emailInput.value.trim();
    const password = passwordInput.value;
    // ✅ SIEMPRE mantener sesión iniciada
    const remember = true;
    
    errorDiv.textContent = '';
    emailInput.classList.remove('invalid');
    passwordInput.classList.remove('invalid');
    
    if (!AUTH_CONFIG.EMAIL_PATTERN.test(email)) {
        errorDiv.textContent = 'Email inválido';
        emailInput.classList.add('invalid');
        emailInput.focus();
        return;
    }
    
    if (password.length < AUTH_CONFIG.PASSWORD_MIN) {
        errorDiv.textContent = 'Contraseña muy corta';
        passwordInput.classList.add('invalid');
        passwordInput.focus();
        return;
    }
    
    submitBtn.disabled = true;
    submitBtn.classList.add('loading');
    submitBtn.textContent = 'Iniciando...';
    
    try {
        mostrarEstadoConexion(true);
        
        const response = await fetch(`${CONFIG.API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        
        if (response.ok && data.success) {
            rateLimiter.reset('login');
            guardarSesion(data.token, data.user, remember);
            iniciarVerificacionSesion();
            cerrarModal('modal-login');
            mostrarUsuarioLogueado();
            
            // ✅ SINCRONIZACIÓN INSTANTÁNEA
            sincronizarTodoInmediatamente(data.user);
            
            mostrarAlerta('¡Bienvenido de nuevo! 👋', 'success');
            
            // ✅ FIX: Aumentar timeout a 1500ms
            if (typeof cargarMensajes === 'function') {
                setTimeout(() => cargarMensajes(), 1500);
            }
        } else {
            errorDiv.textContent = data.error || 'Error al iniciar sesión';
            if (data.field === 'email') {
                emailInput.classList.add('invalid');
            } else if (data.field === 'password') {
                passwordInput.classList.add('invalid');
            }
        }
    } catch (error) {
        console.error('Error en login:', error);
        errorDiv.textContent = 'Error de conexión. Intenta nuevamente.';
        mostrarEstadoConexion(false);
    } finally {
        submitBtn.disabled = false;
        submitBtn.classList.remove('loading');
        submitBtn.textContent = 'Entrar';
    }
}

// ========================================
// MODAL DE REGISTRO
// ========================================

function abrirModalRegistro() {
    const modal = document.createElement('div');
    modal.className = 'modal-auth';
    modal.id = 'modal-registro';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-labelledby', 'modal-registro-title');
    modal.setAttribute('aria-modal', 'true');
    
    modal.innerHTML = `
        <div class="modal-auth-content">
            <button class="btn-cerrar-modal" 
                    onclick="cerrarModal('modal-registro')" 
                    aria-label="Cerrar modal">
                &times;
            </button>
            <h2 id="modal-registro-title">Crear Cuenta</h2>
            <form id="form-registro" onsubmit="handleRegistroSubmit(event)" novalidate>
                <div class="form-group">
                    <label for="reg-username">👤 Nombre de usuario</label>
                    <input type="text" 
                           id="reg-username" 
                           required 
                           placeholder="usuario123" 
                           autocomplete="username"
                           minlength="${AUTH_CONFIG.USERNAME_MIN}"
                           maxlength="${AUTH_CONFIG.USERNAME_MAX}"
                           aria-required="true">
                    <small>3-20 caracteres, solo letras, números, - y _</small>
                    <span class="field-error" role="alert"></span>
                </div>
                <div class="form-group">
                    <label for="reg-email">📧 Email</label>
                    <input type="email" 
                           id="reg-email" 
                           required 
                           placeholder="tu@email.com"
                           autocomplete="email"
                           aria-required="true">
                    <span class="field-error" role="alert"></span>
                </div>
                <div class="form-group">
                    <label for="reg-password">🔒 Contraseña</label>
                    <input type="password" 
                           id="reg-password" 
                           required 
                           placeholder="••••••••" 
                           autocomplete="new-password"
                           minlength="${AUTH_CONFIG.PASSWORD_MIN}"
                           oninput="validarFortalezaPassword(this.value)"
                           aria-required="true">
                    <small>Mínimo 8 caracteres</small>
                    <div class="password-strength">
                        <div class="password-strength-bar" id="password-strength-bar"></div>
                    </div>
                    <p class="password-strength-text" id="password-strength-text"></p>
                    <span class="field-error" role="alert"></span>
                </div>
                <div class="form-group">
                    <label for="reg-password-confirm">🔒 Confirmar contraseña</label>
                    <input type="password" 
                           id="reg-password-confirm" 
                           required 
                           placeholder="••••••••"
                           autocomplete="new-password"
                           aria-required="true">
                    <span class="field-error" role="alert"></span>
                </div>
                <div id="registro-error" class="error-message" role="alert" aria-live="polite"></div>
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" id="reg-terms" required aria-required="true">
                        Acepto los <a href="terminos.html" target="_blank" rel="noopener">Términos y Condiciones</a>
                    </label>
                </div>
                <button type="submit" class="btn-submit">
                    Crear Cuenta
                </button>
            </form>
            <p class="modal-footer">
                ¿Ya tenés cuenta? 
                <a href="#" onclick="cerrarModal('modal-registro'); abrirModalLogin(); return false;">
                    Inicia sesión acá
                </a>
            </p>
        </div>
    `;
    
    document.body.appendChild(modal);
    document.body.style.overflow = 'hidden';
    
    setTimeout(() => {
        const usernameInput = document.getElementById('reg-username');
        if (usernameInput) usernameInput.focus();
    }, 150);
    
    modal.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') cerrarModal('modal-registro');
    });
}

function validarFortalezaPassword(password) {
    const bar = document.getElementById('password-strength-bar');
    const text = document.getElementById('password-strength-text');
    
    if (!bar || !text) return;
    
    let fortaleza = 0;
    
    if (password.length >= 8) fortaleza++;
    if (password.length >= 12) fortaleza++;
    if (/[a-z]/.test(password) && /[A-Z]/.test(password)) fortaleza++;
    if (/\d/.test(password)) fortaleza++;
    if (/[^a-zA-Z0-9]/.test(password)) fortaleza++;
    
    bar.className = 'password-strength-bar';
    
    if (fortaleza <= 2) {
        bar.classList.add('weak');
        text.textContent = 'Contraseña débil';
        text.style.color = '#ff6b6b';
    } else if (fortaleza <= 3) {
        bar.classList.add('medium');
        text.textContent = 'Contraseña media';
        text.style.color = '#f59e0b';
    } else {
        bar.classList.add('strong');
        text.textContent = 'Contraseña fuerte';
        text.style.color = '#10b981';
    }
}

async function handleRegistroSubmit(event) {
    event.preventDefault();
    
    const form = event.target;
    const usernameInput = document.getElementById('reg-username');
    const emailInput = document.getElementById('reg-email');
    const passwordInput = document.getElementById('reg-password');
    const passwordConfirmInput = document.getElementById('reg-password-confirm');
    const termsInput = document.getElementById('reg-terms');
    const errorDiv = document.getElementById('registro-error');
    const submitBtn = form.querySelector('button[type="submit"]');
    
    const username = usernameInput.value.trim();
    const email = emailInput.value.trim();
    const password = passwordInput.value;
    const passwordConfirm = passwordConfirmInput.value;
    
    errorDiv.textContent = '';
    [usernameInput, emailInput, passwordInput, passwordConfirmInput].forEach(input => {
        input.classList.remove('invalid');
    });
    
    if (!AUTH_CONFIG.USERNAME_PATTERN.test(username)) {
        errorDiv.textContent = 'Nombre de usuario inválido';
        usernameInput.classList.add('invalid');
        usernameInput.focus();
        return;
    }
    
    if (username.length < AUTH_CONFIG.USERNAME_MIN || username.length > AUTH_CONFIG.USERNAME_MAX) {
        errorDiv.textContent = `El username debe tener entre ${AUTH_CONFIG.USERNAME_MIN} y ${AUTH_CONFIG.USERNAME_MAX} caracteres`;
        usernameInput.classList.add('invalid');
        usernameInput.focus();
        return;
    }
    
    if (!AUTH_CONFIG.EMAIL_PATTERN.test(email)) {
        errorDiv.textContent = 'Email inválido';
        emailInput.classList.add('invalid');
        emailInput.focus();
        return;
    }
    
    if (password.length < AUTH_CONFIG.PASSWORD_MIN) {
        errorDiv.textContent = `La contraseña debe tener al menos ${AUTH_CONFIG.PASSWORD_MIN} caracteres`;
        passwordInput.classList.add('invalid');
        passwordInput.focus();
        return;
    }
    
    if (password !== passwordConfirm) {
        errorDiv.textContent = 'Las contraseñas no coinciden';
        passwordConfirmInput.classList.add('invalid');
        passwordConfirmInput.focus();
        return;
    }
    
    if (!termsInput.checked) {
        errorDiv.textContent = 'Debes aceptar los términos y condiciones';
        termsInput.focus();
        return;
    }
    
    submitBtn.disabled = true;
    submitBtn.classList.add('loading');
    submitBtn.textContent = 'Creando cuenta...';
    
    try {
        const response = await fetch(`${CONFIG.API_URL}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password })
        });
        
        const data = await response.json();
        
        if (response.ok && data.success) {
            guardarSesion(data.token, data.user, true);
            iniciarVerificacionSesion();
            cerrarModal('modal-registro');
            mostrarUsuarioLogueado();
            
            // ✅ SINCRONIZACIÓN INSTANTÁNEA
            sincronizarTodoInmediatamente(data.user);
            
            mostrarAlerta('¡Cuenta creada exitosamente! Bienvenido 🎉', 'success');
            
            // ✅ FIX: Aumentar timeout a 1500ms
            if (typeof cargarMensajes === 'function') {
                setTimeout(() => cargarMensajes(), 1500);
            }
        } else {
            errorDiv.textContent = data.error || 'Error al crear la cuenta';
            
            if (data.field === 'username') {
                usernameInput.classList.add('invalid');
            } else if (data.field === 'email') {
                emailInput.classList.add('invalid');
            }
        }
    } catch (error) {
        console.error('Error en registro:', error);
        errorDiv.textContent = 'Error de conexión. Intenta nuevamente.';
    } finally {
        submitBtn.disabled = false;
        submitBtn.classList.remove('loading');
        submitBtn.textContent = 'Crear Cuenta';
    }
}

// ========================================
// MODAL DE RECUPERACIÓN
// ========================================

function abrirModalRecuperacion() {
    const modal = document.createElement('div');
    modal.className = 'modal-auth';
    modal.id = 'modal-recuperacion';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    
    modal.innerHTML = `
        <div class="modal-auth-content">
            <button class="btn-cerrar-modal" onclick="cerrarModal('modal-recuperacion')" aria-label="Cerrar modal">&times;</button>
            <h2>🔑 Recuperar Contraseña</h2>
            <p style="color: rgba(255,255,255,0.7); margin-bottom: 20px; text-align: center; font-size: 14px;">
                Contactame por Twitter para ayudarte a recuperar la contraseña. @AngulismoTV.
            </p>
            <p class="modal-footer">
                <a href="#" onclick="cerrarModal('modal-recuperacion'); abrirModalLogin(); return false;">
                    Volver al login
                </a>
            </p>
        </div>
    `;
    
    document.body.appendChild(modal);
    document.body.style.overflow = 'hidden';
    
    modal.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') cerrarModal('modal-recuperacion');
    });
}

// ========================================
// CERRAR SESIÓN
// ========================================

async function cerrarSesion() {
    const confirmacion = confirm('¿Seguro que quieres cerrar sesión?');
    if (!confirmacion) return;
    
    try {
        if (AuthState.token) {
            await fetch(`${CONFIG.API_URL}/auth/logout`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${AuthState.token}`
                }
            });
        }
    } catch (error) {
        console.error('Error cerrando sesión en servidor:', error);
    }
    
    cerrarSesionLocal();
    mostrarAlerta('Sesión cerrada correctamente 👋', 'info');
}

// ✅ FUNCIÓN MEJORADA DE CERRAR SESIÓN
function cerrarSesionLocal() {
    console.log('🚪 Cerrando sesión local...');
    
    // ✅ PASO 1: Limpiar TODOS los datos de AMBOS storages
    const keysToRemove = [
        'authToken', 'user', 'username', 'userId', 'userRole', 'rememberMe', 
        'foroAvatar', 'foroNombre'
    ];
    
    keysToRemove.forEach(key => {
        localStorage.removeItem(key);
        sessionStorage.removeItem(key);
    });
    
    // ✅ PASO 2: Resetear estado global
    AuthState.token = null;
    AuthState.user = null;
    AuthState.isAuthenticated = false;
    AuthState.rememberMe = false;
    
    // ✅ PASO 3: Detener verificación de sesión
    if (sessionCheckInterval) {
        clearInterval(sessionCheckInterval);
        sessionCheckInterval = null;
    }
    
    console.log('✅ Sesión limpiada - Recargando página...');
    
    // ✅ PASO 4: RECARGAR PÁGINA (CRÍTICO)
    setTimeout(() => {
        location.reload(true);
    }, 200);
}

// ========================================
// SINCRONIZACIÓN COMPLETA E INSTANTÁNEA
// ========================================

function sincronizarTodoInmediatamente(user) {
    // ✅ VERIFICAR ESTADO ANTES DE SINCRONIZAR
    if (!AuthState.isAuthenticated || !AuthState.token) {
        console.log('⚠️ No hay sesión activa - sincronización cancelada');
        return;
    }
    
    if (!user) {
        console.warn('⚠️ No hay usuario para sincronizar');
        return;
    }
    
    console.log('⚡ SINCRONIZACIÓN INSTANTÁNEA:', user.username);
    
    // 1. Actualizar nombre
    const nombreInput = document.getElementById('foroNombre');
    if (nombreInput) {
        nombreInput.value = user.username;
        nombreInput.disabled = true;
        console.log('✅ Nombre sincronizado');
    }
    
    // 2. Sincronizar avatar
    if (user.avatar_url && typeof State !== 'undefined') {
        State.avatarSeleccionado = {
            tipo: 'foto',
            valor: user.avatar_url
        };
        localStorage.setItem('foroAvatar', JSON.stringify(State.avatarSeleccionado));
        
        if (typeof actualizarPreviewAvatar === 'function') {
            actualizarPreviewAvatar();
        }
        console.log('✅ Avatar sincronizado');
    }
    
    // 3. Disparar evento para otros módulos
    window.dispatchEvent(new CustomEvent('userLoggedIn', {
        detail: { user: user }
    }));
    
    console.log('⚡ Sincronización completada');
}

// ========================================
// INTEGRACIÓN CON ENVÍO DE MENSAJES
// ========================================

if (typeof enviarMensaje === 'function' && !window.enviarMensajeOriginal) {
    window.enviarMensajeOriginal = enviarMensaje;
}

if (typeof enviarMensaje === 'function') {
    window.enviarMensaje = async function() {
        const nombreInput = document.getElementById('foroNombre');
        const mensajeInput = document.getElementById('foroMensaje');
        
        if (!nombreInput || !mensajeInput) {
            mostrarAlerta('Error: formulario no encontrado', 'error');
            return;
        }
        
        let nombre = nombreInput.value.trim();
        const mensaje = mensajeInput.value.trim();
        
        if (AuthState.isAuthenticated && AuthState.user) {
            nombre = AuthState.user.username;
            nombreInput.value = nombre;
            nombreInput.disabled = true;
        }
        
        if (!nombre) {
            mostrarAlerta('Por favor, ingresa tu nombre', 'warning');
            nombreInput.focus();
            return;
        }
        
        if (!mensaje && (!State || State.archivosAdjuntos.length === 0)) {
            mostrarAlerta('Por favor, escribe un mensaje o adjunta un archivo', 'warning');
            mensajeInput.focus();
            return;
        }
        
        const headers = { 'Content-Type': 'application/json' };
        if (AuthState.token) {
            headers['Authorization'] = `Bearer ${AuthState.token}`;
        }
        
        const avatarHTML = typeof obtenerAvatarParaEnviar === 'function' 
            ? obtenerAvatarParaEnviar() 
            : null;
        
        const multimedia = (State && State.archivosAdjuntos && State.archivosAdjuntos.length > 0)
            ? JSON.stringify(State.archivosAdjuntos) 
            : null;
        
        const btnEnviar = document.querySelector('.btn-foro');
        if (btnEnviar) {
            btnEnviar.disabled = true;
            btnEnviar.textContent = 'Enviando...';
        }
        
        try {
            const response = await fetch(`${CONFIG.API_URL}/mensajes`, {
                method: 'POST',
                headers: headers,
                body: JSON.stringify({
                    nombre: nombre,
                    mensaje: mensaje,
                    avatar: avatarHTML,
                    multimedia: multimedia,
                    respuesta_a: State?.mensajeSeleccionado || null
                })
            });
            
            const resultado = await response.json();
            
            if (response.ok && resultado.success) {
                mensajeInput.value = '';
                
                if (State) {
                    State.archivosAdjuntos = [];
                }
                
                const previewContainer = document.getElementById('archivos-preview');
                if (previewContainer) previewContainer.remove();
                
                mensajeInput.focus();
                
                if (typeof cancelarRespuesta === 'function') {
                    cancelarRespuesta();
                }
                
                if (typeof actualizarContador === 'function') {
                    actualizarContador();
                }
                
                mostrarAlerta('Mensaje publicado correctamente ✓', 'success');
                
                if (typeof cargarMensajes === 'function') {
                    await cargarMensajes();
                }
            } else {
                mostrarAlerta(resultado.error || 'Error al publicar el mensaje', 'error');
            }
        } catch (error) {
            console.error('Error publicando mensaje:', error);
            mostrarAlerta('Error de conexión. Intenta nuevamente', 'error');
        } finally {
            if (btnEnviar) {
                btnEnviar.disabled = false;
                btnEnviar.textContent = 'Enviar';
            }
        }
    };
}

// ========================================
// EXPORTAR FUNCIONES GLOBALES
// ========================================

window.AuthState = AuthState;
window.abrirModalLogin = abrirModalLogin;
window.abrirModalRegistro = abrirModalRegistro;
window.abrirModalRecuperacion = abrirModalRecuperacion;
window.cerrarSesion = cerrarSesion;
window.cerrarModal = cerrarModal;
window.togglePasswordVisibility = togglePasswordVisibility;
window.handleLoginSubmit = handleLoginSubmit;
window.handleRegistroSubmit = handleRegistroSubmit;
window.validarFortalezaPassword = validarFortalezaPassword;
window.sincronizarTodoInmediatamente = sincronizarTodoInmediatamente;

// ========================================
// AUTO-INICIALIZACIÓN
// ========================================

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', inicializarAuth);
} else {
    inicializarAuth();
}

console.log('✅ Sistema de autenticación v2.9 completo listo (SESIÓN PERMANENTE)');