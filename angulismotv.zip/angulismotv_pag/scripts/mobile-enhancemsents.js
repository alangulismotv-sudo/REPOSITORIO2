// ========================================
// MEJORAS MÓVIL - AngulismoTV Foro
// Gestos táctiles y optimizaciones
// ========================================

console.log('📱 Cargando mejoras móviles...');

// ========================================
// DETECTAR DISPOSITIVO MÓVIL
// ========================================

const isMobile = () => {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) 
        || window.innerWidth <= 768;
};

// ========================================
// RESPUESTAS COLAPSABLES (MÓVIL)
// ========================================

function inicializarRespuestasColapsables() {
    if (!isMobile()) return;
    
    document.addEventListener('click', function(e) {
        const respuesta = e.target.closest('.respuesta-referencia');
        if (respuesta && !respuesta.classList.contains('expandida')) {
            e.stopPropagation();
            e.preventDefault();
            
            // Colapsar otras
            document.querySelectorAll('.respuesta-referencia.expandida').forEach(r => {
                if (r !== respuesta) r.classList.remove('expandida');
            });
            
            // Expandir esta
            respuesta.classList.toggle('expandida');
        }
    });
}

// ========================================
// HEADER COLAPSABLE AL SCROLL
// ========================================

function inicializarHeaderColapsable() {
    if (!isMobile()) return;
    
    let lastScroll = 0;
    const header = document.querySelector('.foro-header');
    const search = document.querySelector('.search-container');
    
    if (!header) return;
    
    const mensajesContainer = document.getElementById('listaMensajes');
    if (!mensajesContainer) return;
    
    mensajesContainer.addEventListener('scroll', function() {
        const currentScroll = this.scrollTop;
        
        if (currentScroll > lastScroll && currentScroll > 50) {
            // Scrolling down
            header.style.transform = 'translateY(-100%)';
            header.style.transition = 'transform 0.3s ease';
            if (search) search.style.top = '0px';
        } else {
            // Scrolling up
            header.style.transform = 'translateY(0)';
            if (search) search.style.top = '80px';
        }
        
        lastScroll = currentScroll;
    });
}

// ========================================
// SWIPE GESTURES PARA ACCIONES
// ========================================

function inicializarSwipeGestures() {
    if (!isMobile()) return;
    
    let touchStartX = 0;
    let touchStartY = 0;
    let currentElement = null;
    
    document.addEventListener('touchstart', function(e) {
        const mensajeItem = e.target.closest('.mensaje-item');
        if (!mensajeItem) return;
        
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
        currentElement = mensajeItem;
    }, { passive: true });
    
    document.addEventListener('touchmove', function(e) {
        if (!currentElement) return;
        
        const touchX = e.touches[0].clientX;
        const touchY = e.touches[0].clientY;
        
        const deltaX = touchX - touchStartX;
        const deltaY = touchY - touchStartY;
        
        // Solo si el swipe es más horizontal que vertical
        if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 50) {
            e.preventDefault();
            
            // Swipe left (mostrar acciones)
            if (deltaX < -50) {
                currentElement.style.transform = `translateX(${Math.max(deltaX, -100)}px)`;
                currentElement.style.transition = 'none';
                mostrarAccionesRapidas(currentElement);
            }
            
            // Swipe right (responder)
            if (deltaX > 50) {
                currentElement.style.transform = `translateX(${Math.min(deltaX, 100)}px)`;
                currentElement.style.transition = 'none';
            }
        }
    });
    
    document.addEventListener('touchend', function(e) {
        if (!currentElement) return;
        
        const transform = currentElement.style.transform;
        const translateX = parseInt(transform.replace(/[^\-\d.]/g, '')) || 0;
        
        currentElement.style.transition = 'transform 0.3s ease';
        
        // Si se deslizó suficiente a la izquierda
        if (translateX < -50) {
            mostrarAccionesRapidas(currentElement);
            currentElement.style.transform = 'translateX(-80px)';
        }
        // Si se deslizó suficiente a la derecha
        else if (translateX > 50) {
            const msgId = currentElement.dataset.mensajeId;
            const nombre = currentElement.querySelector('.mensaje-nombre')?.textContent || '';
            const texto = currentElement.querySelector('.mensaje-texto')?.textContent || '';
            
            if (typeof seleccionarMensaje === 'function') {
                seleccionarMensaje(msgId, nombre, texto, e);
            }
            
            currentElement.style.transform = 'translateX(0)';
            mostrarAlerta('Respondiendo mensaje...', 'info');
        }
        // Volver a posición normal
        else {
            currentElement.style.transform = 'translateX(0)';
        }
        
        setTimeout(() => {
            if (currentElement) {
                currentElement.style.transition = '';
            }
        }, 300);
        
        currentElement = null;
    }, { passive: true });
    
    // Cerrar acciones al tocar fuera
    document.addEventListener('touchstart', function(e) {
        const mensajeItem = e.target.closest('.mensaje-item');
        
        document.querySelectorAll('.mensaje-item').forEach(item => {
            if (item !== mensajeItem && item.style.transform === 'translateX(-80px)') {
                item.style.transition = 'transform 0.3s ease';
                item.style.transform = 'translateX(0)';
                ocultarAccionesRapidas(item);
            }
        });
    }, { passive: true });
}

function mostrarAccionesRapidas(mensajeItem) {
    // Remover acciones anteriores
    const anteriorAcciones = mensajeItem.querySelector('.acciones-rapidas');
    if (anteriorAcciones) return;
    
    const acciones = document.createElement('div');
    acciones.className = 'acciones-rapidas';
    acciones.innerHTML = `
        <button class="btn-accion-rapida btn-responder-rapido" title="Responder">
            ↩️
        </button>
        <button class="btn-accion-rapida btn-reaccion-rapido" title="Reaccionar">
            ❤️
        </button>
    `;
    
    mensajeItem.appendChild(acciones);
    
    // Eventos
    const btnResponder = acciones.querySelector('.btn-responder-rapido');
    const btnReaccion = acciones.querySelector('.btn-reaccion-rapido');
    
    btnResponder.addEventListener('click', function(e) {
        e.stopPropagation();
        const msgId = mensajeItem.dataset.mensajeId;
        const nombre = mensajeItem.querySelector('.mensaje-nombre')?.textContent || '';
        const texto = mensajeItem.querySelector('.mensaje-texto')?.textContent || '';
        
        if (typeof seleccionarMensaje === 'function') {
            seleccionarMensaje(msgId, nombre, texto, e);
        }
        
        mensajeItem.style.transform = 'translateX(0)';
        ocultarAccionesRapidas(mensajeItem);
    });
    
    btnReaccion.addEventListener('click', function(e) {
        e.stopPropagation();
        const msgId = mensajeItem.dataset.mensajeId;
        
        if (typeof agregarReaccion === 'function') {
            agregarReaccion(msgId, '❤️');
        }
        
        mensajeItem.style.transform = 'translateX(0)';
        ocultarAccionesRapidas(mensajeItem);
    });
}

function ocultarAccionesRapidas(mensajeItem) {
    const acciones = mensajeItem.querySelector('.acciones-rapidas');
    if (acciones) {
        acciones.remove();
    }
}

// ========================================
// LONG PRESS PARA OPCIONES
// ========================================

function inicializarLongPress() {
    if (!isMobile()) return;
    
    let longPressTimer;
    let currentElement;
    
    document.addEventListener('touchstart', function(e) {
        const mensajeItem = e.target.closest('.mensaje-item');
        if (!mensajeItem) return;
        
        currentElement = mensajeItem;
        
        longPressTimer = setTimeout(() => {
            mostrarMenuContextual(mensajeItem, e.touches[0]);
            navigator.vibrate?.(50); // Vibración suave
        }, 500);
    }, { passive: true });
    
    document.addEventListener('touchend', function() {
        clearTimeout(longPressTimer);
    }, { passive: true });
    
    document.addEventListener('touchmove', function() {
        clearTimeout(longPressTimer);
    }, { passive: true });
}

function mostrarMenuContextual(mensajeItem, touch) {
    // Remover menús anteriores
    document.querySelectorAll('.menu-contextual').forEach(m => m.remove());
    
    const menu = document.createElement('div');
    menu.className = 'menu-contextual';
    
    const msgId = mensajeItem.dataset.mensajeId;
    const nombre = mensajeItem.querySelector('.mensaje-nombre')?.textContent || '';
    const texto = mensajeItem.querySelector('.mensaje-texto')?.textContent || '';
    
    menu.innerHTML = `
        <button onclick="responderMensaje('${msgId}', '${nombre}', '${texto}')">
            ↩️ Responder
        </button>
        <button onclick="copiarMensaje('${msgId}')">
            📋 Copiar
        </button>
        <button onclick="reportarMensaje('${msgId}')">
            🚩 Reportar
        </button>
        <button onclick="cerrarMenuContextual()">
            ❌ Cancelar
        </button>
    `;
    
    // Posicionar el menú
    menu.style.position = 'fixed';
    menu.style.left = '50%';
    menu.style.top = '50%';
    menu.style.transform = 'translate(-50%, -50%)';
    menu.style.zIndex = '10000';
    
    document.body.appendChild(menu);
    
    // Crear backdrop
    const backdrop = document.createElement('div');
    backdrop.className = 'menu-contextual-backdrop';
    backdrop.onclick = cerrarMenuContextual;
    document.body.appendChild(backdrop);
    
    setTimeout(() => {
        menu.classList.add('show');
        backdrop.classList.add('show');
    }, 10);
}

function cerrarMenuContextual() {
    document.querySelectorAll('.menu-contextual, .menu-contextual-backdrop').forEach(el => {
        el.classList.remove('show');
        setTimeout(() => el.remove(), 300);
    });
}

function responderMensaje(msgId, nombre, texto) {
    cerrarMenuContextual();
    if (typeof seleccionarMensaje === 'function') {
        seleccionarMensaje(msgId, nombre, texto, { stopPropagation: () => {} });
    }
}

function copiarMensaje(msgId) {
    const mensaje = document.querySelector(`[data-mensaje-id="${msgId}"]`);
    const texto = mensaje?.querySelector('.mensaje-texto')?.textContent || '';
    
    navigator.clipboard.writeText(texto).then(() => {
        mostrarAlerta('Mensaje copiado al portapapeles', 'success');
    }).catch(() => {
        mostrarAlerta('No se pudo copiar', 'error');
    });
    
    cerrarMenuContextual();
}

function reportarMensaje(msgId) {
    cerrarMenuContextual();
    mostrarAlerta('Función de reporte en desarrollo', 'info');
}

// ========================================
// PULL TO REFRESH
// ========================================

function inicializarPullToRefresh() {
    if (!isMobile()) return;
    
    const mensajesContainer = document.getElementById('listaMensajes');
    if (!mensajesContainer) return;
    
    let startY = 0;
    let isPulling = false;
    
    const refreshIndicator = document.createElement('div');
    refreshIndicator.className = 'refresh-indicator';
    refreshIndicator.innerHTML = '⟳ Desliza para actualizar';
    refreshIndicator.style.display = 'none';
    mensajesContainer.parentNode.insertBefore(refreshIndicator, mensajesContainer);
    
    mensajesContainer.addEventListener('touchstart', function(e) {
        if (this.scrollTop === 0) {
            startY = e.touches[0].pageY;
            isPulling = true;
        }
    }, { passive: true });
    
    mensajesContainer.addEventListener('touchmove', function(e) {
        if (!isPulling) return;
        
        const currentY = e.touches[0].pageY;
        const diff = currentY - startY;
        
        if (diff > 0 && this.scrollTop === 0) {
            e.preventDefault();
            refreshIndicator.style.display = 'block';
            refreshIndicator.style.height = Math.min(diff, 60) + 'px';
            refreshIndicator.style.opacity = Math.min(diff / 60, 1);
            
            if (diff > 60) {
                refreshIndicator.innerHTML = '⟳ Suelta para actualizar';
                refreshIndicator.classList.add('ready');
            } else {
                refreshIndicator.innerHTML = '⟳ Desliza para actualizar';
                refreshIndicator.classList.remove('ready');
            }
        }
    });
    
    mensajesContainer.addEventListener('touchend', function() {
        if (isPulling && refreshIndicator.classList.contains('ready')) {
            refreshIndicator.innerHTML = '⟳ Actualizando...';
            
            // Actualizar mensajes
            if (typeof cargarMensajes === 'function') {
                cargarMensajes().then(() => {
                    setTimeout(() => {
                        refreshIndicator.style.display = 'none';
                        refreshIndicator.style.height = '0';
                        mostrarAlerta('Mensajes actualizados', 'success');
                    }, 500);
                });
            } else {
                setTimeout(() => {
                    refreshIndicator.style.display = 'none';
                    refreshIndicator.style.height = '0';
                }, 500);
            }
        } else {
            refreshIndicator.style.display = 'none';
            refreshIndicator.style.height = '0';
        }
        
        isPulling = false;
        refreshIndicator.classList.remove('ready');
    }, { passive: true });
}

// ========================================
// OPTIMIZACIÓN DE PERFORMANCE
// ========================================

function optimizarPerformance() {
    if (!isMobile()) return;
    
    // Lazy loading de imágenes
    const images = document.querySelectorAll('.mensaje-multimedia img');
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                        imageObserver.unobserve(img);
                    }
                }
            });
        });
        
        images.forEach(img => imageObserver.observe(img));
    }
    
    // Reducir animaciones en dispositivos lentos
    if (navigator.hardwareConcurrency && navigator.hardwareConcurrency < 4) {
        document.documentElement.classList.add('reduce-motion');
    }
}

// ========================================
// TECLADO VIRTUAL MANAGEMENT
// ========================================

function gestionarTecladoVirtual() {
    if (!isMobile()) return;
    
    const foroMensaje = document.getElementById('foroMensaje');
    if (!foroMensaje) return;
    
    let originalHeight = window.innerHeight;
    
    // Detectar apertura de teclado
    window.visualViewport?.addEventListener('resize', () => {
        const currentHeight = window.visualViewport.height;
        
        if (currentHeight < originalHeight * 0.75) {
            // Teclado abierto
            document.body.classList.add('keyboard-open');
            
            // Scroll al input
            setTimeout(() => {
                foroMensaje.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 100);
        } else {
            // Teclado cerrado
            document.body.classList.remove('keyboard-open');
        }
    });
}

// ========================================
// ESTILOS CSS PARA MEJORAS MÓVIL
// ========================================

function agregarEstilosMejoras() {
    const style = document.createElement('style');
    style.textContent = `
        /* Acciones rápidas de swipe */
        .acciones-rapidas {
            position: absolute;
            right: 0;
            top: 0;
            height: 100%;
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 0 12px;
            background: linear-gradient(90deg, transparent, rgba(0,0,0,0.5));
        }
        
        .btn-accion-rapida {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: none;
            background: rgba(114, 214, 255, 0.2);
            font-size: 18px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .btn-accion-rapida:active {
            background: rgba(114, 214, 255, 0.4);
        }
        
        /* Menú contextual */
        .menu-contextual {
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 8px;
            min-width: 200px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.5);
            opacity: 0;
            transform: scale(0.9);
            transition: all 0.2s ease;
        }
        
        .menu-contextual.show {
            opacity: 1;
            transform: scale(1);
        }
        
        .menu-contextual button {
            width: 100%;
            padding: 12px;
            background: transparent;
            border: none;
            color: var(--color-text);
            font-size: 14px;
            text-align: left;
            cursor: pointer;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 4px;
        }
        
        .menu-contextual button:active {
            background: var(--bg-tertiary);
        }
        
        .menu-contextual button:last-child {
            color: var(--color-error);
        }
        
        .menu-contextual-backdrop {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 9999;
            opacity: 0;
            transition: opacity 0.2s ease;
        }
        
        .menu-contextual-backdrop.show {
            opacity: 1;
        }
        
        /* Refresh indicator */
        .refresh-indicator {
            text-align: center;
            padding: 12px;
            font-size: 14px;
            color: var(--color-primary);
            background: var(--bg-secondary);
            overflow: hidden;
            transition: all 0.2s ease;
        }
        
        .refresh-indicator.ready {
            background: var(--color-primary);
            color: var(--bg-primary);
        }
        
        /* Keyboard open adjustments */
        body.keyboard-open .formulario-integrado {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            margin: 0;
        }
        
        /* Reduce motion */
        .reduce-motion * {
            animation-duration: 0.01ms !important;
            transition-duration: 0.01ms !important;
        }
    `;
    
    document.head.appendChild(style);
}

// ========================================
// EXPORTAR FUNCIONES
// ========================================

window.responderMensaje = responderMensaje;
window.copiarMensaje = copiarMensaje;
window.reportarMensaje = reportarMensaje;
window.cerrarMenuContextual = cerrarMenuContextual;

// ========================================
// AUTO-INICIALIZACIÓN
// ========================================

function inicializarMejorasMovil() {
    if (!isMobile()) {
        console.log('📱 No es móvil, saltando mejoras táctiles');
        return;
    }
    
    console.log('📱 Inicializando mejoras móviles...');
    
    agregarEstilosMejoras();
    inicializarRespuestasColapsables();
    inicializarHeaderColapsable();
    inicializarSwipeGestures();
    inicializarLongPress();
    inicializarPullToRefresh();
    optimizarPerformance();
    gestionarTecladoVirtual();
    
    console.log('✅ Mejoras móviles activadas');
}

// Iniciar cuando el DOM esté listo
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', inicializarMejorasMovil);
} else {
    inicializarMejorasMovil();
}

console.log('✅ Script de mejoras móviles cargado');