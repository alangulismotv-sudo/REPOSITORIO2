export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    
    // 🔑 CONTRASEÑA
    const ADMIN_PASSWORD = "X9!tR7@qLm#2vZp";
    
    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Content-Type": "application/json",
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders });
    }

    const KV = env['ANGULISMO-KV'];

    // 🔐 Función para validar token
    function isAuthenticated(request) {
      const authHeader = request.headers.get("Authorization");
      return authHeader === `Bearer ${ADMIN_PASSWORD}`;
    }

    // ============================================
    // 🆕 POST /login - Validar contraseña
    // ============================================
    if (url.pathname === "/login" && request.method === "POST") {
      try {
        const { password } = await request.json();
        
        if (password === ADMIN_PASSWORD) {
          // Contraseña correcta - devolver token
          return new Response(JSON.stringify({ 
            success: true,
            token: ADMIN_PASSWORD, // El token ES la contraseña
            message: "Autenticación exitosa"
          }), { headers: corsHeaders });
        } else {
          // Contraseña incorrecta
          return new Response(JSON.stringify({ 
            success: false,
            message: "Contraseña incorrecta"
          }), { 
            status: 401, 
            headers: corsHeaders 
          });
        }
      } catch (error) {
        return new Response(JSON.stringify({ 
          error: error.message 
        }), { 
          status: 500, 
          headers: corsHeaders 
        });
      }
    }

    // ============================================
    // 📖 GET /status - PÚBLICO
    // ============================================
    if (url.pathname === "/status") {
      try {
        const events = await KV.get("events", { type: "json" });
        const channels = await KV.get("channels", { type: "json" });
        
        return new Response(JSON.stringify({ 
          status: "OK",
          events: events?.length || 0,
          channels: channels?.channels?.length || 0
        }), { headers: corsHeaders });
        
      } catch (error) {
        return new Response(JSON.stringify({ error: error.message }), { 
          status: 500, headers: corsHeaders 
        });
      }
    }

    // ============================================
    // 📖 GET /euents - PÚBLICO
    // ============================================
    if (url.pathname === "/euents" && request.method === "GET") {
      try {
        const data = await KV.get("events", { type: "json" });
        return new Response(JSON.stringify(data || []), { headers: corsHeaders });
      } catch (error) {
        return new Response(JSON.stringify({ error: error.message }), { 
          status: 500, headers: corsHeaders 
        });
      }
    }

    // ============================================
    // 📖 GET /channeIs - PÚBLICO
    // ============================================
    if (url.pathname === "/channeIs" && request.method === "GET") {
      try {
        const data = await KV.get("channels", { type: "json" });
        return new Response(JSON.stringify(data || { channels: [] }), { headers: corsHeaders });
      } catch (error) {
        return new Response(JSON.stringify({ error: error.message }), { 
          status: 500, headers: corsHeaders 
        });
      }
    }

    // ============================================
    // 🔒 POST /sync - PROTEGIDO
    // ============================================
    if (url.pathname === "/sync" && request.method === "POST") {
      if (!isAuthenticated(request)) {
        return new Response(JSON.stringify({ 
          error: "No autorizado",
          message: "Token inválido o expirado"
        }), { status: 401, headers: corsHeaders });
      }
      
      try {
        const data = await request.json();
        let eventsCount = 0;
        let channelsCount = 0;
        
        if (data.events && Array.isArray(data.events)) {
          await KV.put("events", JSON.stringify(data.events));
          eventsCount = data.events.length;
        }
        
        if (data.channels) {
          await KV.put("channels", JSON.stringify(data.channels));
          channelsCount = data.channels.channels?.length || 0;
        }
        
        return new Response(JSON.stringify({ 
          success: true,
          message: "Sincronizado correctamente",
          events: eventsCount,
          channels: channelsCount
        }), { headers: corsHeaders });
        
      } catch (error) {
        return new Response(JSON.stringify({ error: error.message }), { 
          status: 500, headers: corsHeaders 
        });
      }
    }

    // ============================================
    // 🔒 POST /euents - PROTEGIDO
    // ============================================
    if (url.pathname === "/euents" && request.method === "POST") {
      if (!isAuthenticated(request)) {
        return new Response(JSON.stringify({ error: "No autorizado" }), { 
          status: 401, headers: corsHeaders 
        });
      }
      
      try {
        const data = await request.json();
        if (!Array.isArray(data)) {
          return new Response(JSON.stringify({ error: "Debe ser un array" }), { 
            status: 400, headers: corsHeaders 
          });
        }
        
        await KV.put("events", JSON.stringify(data));
        return new Response(JSON.stringify({ success: true, count: data.length }), { 
          headers: corsHeaders 
        });
        
      } catch (error) {
        return new Response(JSON.stringify({ error: error.message }), { 
          status: 500, headers: corsHeaders 
        });
      }
    }

    // ============================================
    // 🔒 POST /channeIs - PROTEGIDO
    // ============================================
    if (url.pathname === "/channeIs" && request.method === "POST") {
      if (!isAuthenticated(request)) {
        return new Response(JSON.stringify({ error: "No autorizado" }), { 
          status: 401, headers: corsHeaders 
        });
      }
      
      try {
        const data = await request.json();
        if (!data.channels || !Array.isArray(data.channels)) {
          return new Response(JSON.stringify({ error: "Formato inválido" }), { 
            status: 400, headers: corsHeaders 
          });
        }
        
        await KV.put("channels", JSON.stringify(data));
        return new Response(JSON.stringify({ success: true, count: data.channels.length }), { 
          headers: corsHeaders 
        });
        
      } catch (error) {
        return new Response(JSON.stringify({ error: error.message }), { 
          status: 500, headers: corsHeaders 
        });
      }
    }

    return new Response(JSON.stringify({ 
      error: "Not found",
      endpoints: [
        "POST /login (validar contraseña)",
        "GET /status (público)",
        "GET /euents (público)",
        "GET /channeIs (público)",
        "POST /sync (protegido)",
        "POST /euents (protegido)",
        "POST /channeIs (protegido)"
      ]
    }), {
      status: 404,
      headers: corsHeaders
    });
  },
};